# Guia de replicação — iBlocker (painel cPanel + daemon Linux)

Oct 17, 2026 · @Ivan Loforte

## Visão geral da arquitetura

&#91;embedded content: arquitetura · 2 máquinas, 1 base de dados\]

O painel PHP (cPanel) e o daemon Python (VPS Linux) ligam-se à mesma base de dados MySQL no cPanel — o painel localmente, o daemon por MySQL remoto na porta 3306. Os dispositivos apontam o DNS para a VPS, que serve o bloqueio DNS, o portal cativo e o DoH; o perfil instala-se a partir de `https://<DOMINIO>/install`.

## Pré-requisitos

Este guia usa os valores da instalação real como exemplo. Substitua os marcadores pelos seus:

| Marcador | Exemplo desta instalação | O que é |
| --- | --- | --- |
| `<DOMINIO>` | `ivblocker.site` | Domínio do painel, DNS na Namecheap |
| `<IP_CPANEL>` | `153.56.168.242` | IP do servidor cPanel/WHM |
| `<CONTA>` | `ivblocker` | Conta cPanel do painel |
| `<IP_VPS>` | `186.240.154.217` | IP público da VPS Linux (fixo, vai nos perfis DNS) |
| `<BD>` | `ivblocker_db` | Base de dados MySQL |
| `<BD_USER>` | `ivblocker_user` | Utilizador da base de dados |
| `<DOH>` | `dns.ivblocker.site` | Subdomínio do DoH, aponta para a VPS |

Precisa de: um domínio na Namecheap; um servidor cPanel/WHM com acesso root; uma VPS Linux limpa (Ubuntu 24.04 LTS, 2 vCPU / 4 GB / 20 GB, 1 IPv4 fixo); e os dois ficheiros do pack, `iblocker.dev.zip` (painel PHP) e `python.zip` (daemon). O IP da VPS **não pode mudar** depois, porque fica embutido nos perfis DNS instalados nos dispositivos.

## 1. Painel PHP no cPanel

1. No WHM, crie a conta `<CONTA>` com o domínio `<DOMINIO>`. Confirme o IP ligado à conta com `cat /etc/userdatadomains | grep <DOMINIO>`.
2. No File Manager, envie `iblocker.dev.zip` para `/home/<CONTA>/public_html/` e extraia-o **em cima** (sem pasta aninhada). Os ficheiros `index.php`, `.htaccess` e `includes/` têm de ficar na raiz.
3. Garanta o dono correto, porque extrair como root deixa os ficheiros como `root` e o PHP-FPM não os lê:

```
chown -R <CONTA>:<CONTA> /home/<CONTA>/public_html/*
```

4. Edite `includes/db.php` com as credenciais da base de dados (criada na secção 3):

```php
define('DB_HOST', '127.0.0.1');   // localhost do PHP no cPanel
define('DB_USER', '<BD_USER>');
define('DB_PASS', 'A_SUA_PASSWORD');
define('DB_NAME', '<BD>');
```

5. **Armadilha conhecida:** se outra conta no mesmo servidor tiver um include com `ServerAlias *` (um "catch-all"), ela rouba os pedidos do seu domínio e serve a pasta errada (aparece um "Index of /" vazio ou um 404 no `index.php`). Verifique com `apachectl -S 2>&1 | grep "wild alias \*$"`. Se existir, remova esse alias ou a conta que o tem, depois `rebuildhttpdconf && apachectl -t && /scripts/restartsrv_httpd`.
6. Em produção, ponha `display_errors = 0` no `includes/db.php` e bloqueie ou apague `install.php`, `install_admin.php` e `test.php` depois de o painel instalar.

## 2. DNS na Namecheap

Em Domain List » `<DOMINIO>` » Advanced DNS, crie três registos A:

| Type | Host | Value | Aponta para |
| --- | --- | --- | --- |
| A Record | `@` | `<IP_CPANEL>` | cPanel (painel) |
| A Record | `www` | `<IP_CPANEL>` | cPanel (painel) |
| A Record | `dns` | `<IP_VPS>` | VPS (DoH) |

O registo `dns` aponta para a **VPS**, não para o cPanel, porque é a VPS que termina o TLS do DoH. Confirme a propagação consultando diretamente o servidor da Namecheap, que responde logo:

```
dig +short <DOMINIO> @dns1.registrar-servers.com
dig +short www.<DOMINIO> @dns1.registrar-servers.com
dig +short <DOH> @dns1.registrar-servers.com
```

Remova quaisquer registos A antigos a apontar para outros IPs. Um registo duplicado faz parte dos pedidos cair no sítio errado e mostrar a página padrão do cPanel.

## 3. SSL do painel (AutoSSL)

Com o DNS de `@` e `www` já a apontar para o cPanel:

1. Confirme que os domínios não estão excluídos do AutoSSL e inclua-os:

```
uapi --user=<CONTA> SSL get_autossl_excluded_domains
uapi --user=<CONTA> SSL remove_autossl_excluded_domains domains=<DOMINIO>,www.<DOMINIO>
```

2. Emita o certificado:

```
/usr/local/cpanel/bin/autossl_check --user=<CONTA>
```

3. Valide (sem `-k`, tem de ser confiável):

```
echo | openssl s_client -connect <IP_CPANEL>:443 -servername <DOMINIO> 2>/dev/null | openssl x509 -noout -issuer -subject -ext subjectAltName
curl -sS -D - -o /dev/null https://<DOMINIO>/
```

Esperado: emissor Let's Encrypt, SAN com os dois domínios, `302 → login.php`.

4. Em cPanel » Domains, ative **Force HTTPS Redirect**. Confirme: `curl -sS -D - -o /dev/null http://<DOMINIO>/ | grep -iE "^HTTP|^Location"` deve dar `301` para `https://`.

O AutoSSL renova sozinho; não é preciso mais nada.

## 4. Base de dados e acesso remoto MySQL

A VPS e o painel usam a **mesma** base de dados no cPanel. A VPS liga-se por MySQL remoto.

1. Em cPanel » MySQL Databases, crie a BD `<BD>` e o utilizador `<BD_USER>` com password forte e **ALL PRIVILEGES**. Se o pack trouxer o `.sql`, importe-o via phpMyAdmin; se o painel já criou as tabelas, não é preciso.
2. **No servidor cPanel**, ponha o MariaDB a escutar em todos os IPs (por omissão só escuta em `127.0.0.1`):

```
cp -a /etc/mysql/mariadb.conf.d/50-server.cnf /root/50-server.cnf.bak
sed -i 's/^bind-address.*=.*127.0.0.1/bind-address = 0.0.0.0/' /etc/mysql/mariadb.conf.d/50-server.cnf
/scripts/restartsrv_mysql
ss -ltnp | grep 3306        # tem de mostrar 0.0.0.0:3306
```

3. Autorize o IP da VPS em **dois** sítios — este é o erro mais comum:
   - WHM » **Manage Database Access Hosts**: adicione `<IP_VPS>` (ou `whmapi1 add_remote_mysql_host host=<IP_VPS>`).
   - cPanel da conta `<CONTA>` » **Remote MySQL**: adicione também `<IP_VPS>`. É este que cria a permissão `<BD_USER>@<IP_VPS>`.
4. **A partir da VPS**, teste a ligação:

```
apt install -y mariadb-client
mysql -h <IP_CPANEL> -u <BD_USER> -p <BD> -e "SHOW TABLES;"
```

Tem de listar `devices`, `codes`, `settings`, `device_events`, etc. Se der `ERROR 2003`, falta o bind ou a firewall bloqueia a 3306. Se der `ERROR 1045`, falta o Remote MySQL da conta ou a password está errada.

## 5. Preparar a VPS Linux

Use Ubuntu 24.04 LTS, **sem painel de controlo nem servidor web** (o daemon precisa das portas 53, 80, 443 e 8080 só para ele).

1. Liberte a porta 53, que o `systemd-resolved` ocupa por omissão:

```
mkdir -p /etc/systemd/resolved.conf.d
printf "[Resolve]\nDNSStubListener=no\n" > /etc/systemd/resolved.conf.d/no-stub.conf
ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf
systemctl restart systemd-resolved
ss -lntup | grep ':53\b'    # deve ficar vazio
getent hosts google.com     # a VPS ainda tem de resolver nomes
```

2. Instale o Python num ambiente virtual (o Ubuntu 24.04 não deixa instalar com pip no Python do sistema):

```
apt update && apt -y upgrade
apt install -y python3-venv unzip
mkdir -p /opt/iblocker
python3 -m venv /opt/iblocker/venv
/opt/iblocker/venv/bin/pip install --upgrade pip
/opt/iblocker/venv/bin/pip install rich pymysql requests cryptography
```

Se o `upgrade` perguntar sobre `sshd_config`, escolha **manter a versão local**, para não perder o acesso SSH. Se avisar de um kernel novo, reinicie a VPS num momento calmo.

## 6. Enviar e configurar o daemon

1. Envie `python.zip` para a VPS. Pelo painel SFTP do próprio cliente SSH, ou pelo File Manager do cPanel + `wget` (apague o zip público logo a seguir):

```
cd /opt/iblocker
unzip python.zip        # os .py ficam em /opt/iblocker/, ao lado do venv
```

2. Confirme que não há código preso ao Windows. Os comandos `netsh`/`netstat` do `daemon.py` estão dentro de `if sys.platform == 'win32'`, por isso são ignorados em Linux. Verifique com:

```
grep -rnE "msvcrt|winreg|windll" --include=*.py /opt/iblocker/*.py
```

Não deve devolver nada (ignore o que estiver dentro de `venv/`).

3. Edite `config.py` — é o único ficheiro a mudar:

```python
SITES = [{
    'id': 'iBlockv', 'name': 'iBlockv',
    'panel_url': 'https://<DOMINIO>',
    'db': {'host': '<IP_CPANEL>', 'user': '<BD_USER>',
           'password': 'A_SUA_PASSWORD', 'database': '<BD>'},
}]
VPS_IP = "<IP_VPS>"
DOH_PUBLIC_URL = "https://<DOH>/dns-query"
DOH_TLS_CERT = "/etc/letsencrypt/live/<DOH>/fullchain.pem"
DOH_TLS_KEY  = "/etc/letsencrypt/live/<DOH>/privkey.pem"
```

O `VPS_IP` tem de ser igual ao `vps_ip` nas Settings do painel, ou os códigos de ativação falham. A password e o utilizador têm de ser os mesmos do `includes/db.php`.

## 7. Certificado DoH (certbot)

O `<DOH>` já resolve para a VPS, por isso pode emitir o certificado. Faça-o **antes** de arrancar o daemon, porque o certbot precisa da porta 80 livre:

```
apt install -y certbot
certbot certonly --standalone -d <DOH>
ls -l /etc/letsencrypt/live/<DOH>/   # fullchain.pem e privkey.pem
```

Os ficheiros ficam exatamente no caminho que o `config.py` já aponta. O certbot cria um timer de renovação automática — mas essa renovação volta a precisar da porta 80, que o daemon vai ocupar. A secção 10 trata disso com um hook.

## 8. Testar o daemon

1. Teste seguro, que só lê a base de dados e sai sem ocupar portas:

```
cd /opt/iblocker
/opt/iblocker/venv/bin/python daemon.py -d
```

Deve imprimir o nome do site (`iBlockv`) sem tracebacks. Se faltar um módulo (`ModuleNotFoundError`), instale-o no venv.

2. Arranque real em primeiro plano, com limite de tempo para não prender o terminal:

```
ss -lntup | grep -E ':(53|80|443|8080)\b'   # deve estar vazio antes
timeout 25 /opt/iblocker/venv/bin/python daemon.py
```

Confirme no arranque: DNS blocker na `:53`, captive na `:80`, DoH na `:443` a carregar o certificado de `<DOH>` sem erro, dashboard na `:8080`. Se tudo subir, pare e passe ao serviço.

## 9. Manter o daemon sempre a correr (systemd)

Em primeiro plano, o daemon morre quando fecha o SSH. Um serviço systemd mantém-no a correr e reinicia-o no arranque da VPS. O `AmbientCapabilities` permite abrir as portas 53/80/443 sem depender só de ser root.

Crie `/etc/systemd/system/iblocker.service`:

```
[Unit]
Description=iBlocker daemon
After=network-online.target
Wants=network-online.target

[Service]
WorkingDirectory=/opt/iblocker
ExecStart=/opt/iblocker/venv/bin/python /opt/iblocker/daemon.py
Restart=always
RestartSec=5
AmbientCapabilities=CAP_NET_BIND_SERVICE
StandardOutput=append:/var/log/iblocker.log
StandardError=append:/var/log/iblocker.err.log

[Install]
WantedBy=multi-user.target
```

Ative e arranque:

```
systemctl daemon-reload
systemctl enable --now iblocker
systemctl status iblocker          # tem de estar active (running)
tail -f /var/log/iblocker.log      # acompanhar o arranque
```

O daemon lê a tabela `device_events` a cada segundo, por isso qualquer mudança no painel é aplicada quase de imediato. Comandos úteis: `systemctl restart iblocker` depois de mudar o `config.py`, `journalctl -u iblocker -n 50` para ver os últimos registos.

## 10. Renovação do certificado DoH

O certbot renova o certificado com `--standalone`, que precisa da porta 80. Como o daemon a ocupa, a renovação falharia. Resolve-se parando o daemon durante a renovação e voltando a arrancá-lo, com hooks.

Crie `/etc/letsencrypt/renewal-hooks/pre/stop-iblocker.sh`:

```
#!/bin/sh
systemctl stop iblocker
```

E `/etc/letsencrypt/renewal-hooks/post/start-iblocker.sh`:

```
#!/bin/sh
systemctl start iblocker
```

Dê permissão de execução e teste a renovação a seco:

```
chmod +x /etc/letsencrypt/renewal-hooks/pre/stop-iblocker.sh
chmod +x /etc/letsencrypt/renewal-hooks/post/start-iblocker.sh
certbot renew --dry-run
```

A paragem dura poucos segundos, uma vez a cada dois ou três meses.

## 11. Firewall (passo final)

Só depois de tudo funcionar. Até aqui a porta 3306 do cPanel fica visível na Internet; feche-a.

**No servidor cPanel**, restrinja a 3306 ao próprio servidor e à VPS:

```
iptables -I INPUT -p tcp --dport 3306 -j DROP
iptables -I INPUT -i lo -p tcp --dport 3306 -j ACCEPT
iptables -I INPUT -p tcp -s <IP_VPS> --dport 3306 -j ACCEPT
apt install -y iptables-persistent && netfilter-persistent save
```

Confirme a partir de um PC qualquer que a 3306 está fechada: `Test-NetConnection <IP_CPANEL> -Port 3306` deve dar `False`; da VPS deve dar `True`.

**Na VPS**, abra só o que o daemon usa (a 3306 é de saída, não precisa de regra de entrada):

```
apt install -y ufw
ufw allow 22/tcp
ufw allow 53
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow from SEU_IP to any port 8080 proto tcp
ufw enable
```

Na Hostinger, confirme também em **Security » Firewall** que estas portas estão permitidas na firewall da rede.

## 12. Verificação e problemas comuns

Verificação ponto a ponto, no fim:

- [ ] `https://<DOMINIO>` abre o login com cadeado válido
- [ ] Da VPS, `mysql -h <IP_CPANEL> -u <BD_USER> -p <BD> -e "SHOW TABLES;"` lista as tabelas
- [ ] `systemctl status iblocker` está `active (running)`
- [ ] `<DOH>` resolve para `<IP_VPS>` e o certificado carrega sem erro
- [ ] Num telemóvel com o DNS apontado à VPS, aparece o portal e um código de ativação

| Sintoma | Causa provável | Onde corrigir |
| --- | --- | --- |
| Painel mostra "Index of /" ou 404 | Outra conta com `ServerAlias *` rouba o domínio | Remover o catch-all (secção 1, passo 5) |
| Página padrão do cPanel no browser | DNS em cache ou registo A antigo | Deixar só `<IP_CPANEL>`, `ipconfig /flushdns` |
| `Primary script unknown` | Ficheiros com dono `root`, FPM não lê | `chown -R <CONTA>:<CONTA>` em `public_html` |
| `ERROR 2003` da VPS | bind em 127.0.0.1 ou firewall bloqueia 3306 | Secção 4 passo 2; Hostinger Firewall |
| `ERROR 1045` da VPS | Falta Remote MySQL da conta, ou password | cPanel » Remote MySQL; `includes/db.php` |
| Porta 53 não liga na VPS | `systemd-resolved` ocupa a 53 | Secção 5 passo 1 |
| DoH instala mas não funciona | Certificado não bate com `<DOH>` | Reemitir com certbot (secção 7) |
| Daemon morre ao fechar o SSH | A correr em primeiro plano | Usar o serviço systemd (secção 9) |
