-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 17, 2026 at 05:56 PM
-- Server version: 10.11.19-MariaDB-ubu2404
-- PHP Version: 8.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ivblocker_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `blocked_domains`
--

CREATE TABLE `blocked_domains` (
  `id` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `blocked_domains`
--

INSERT INTO `blocked_domains` (`id`, `domain`, `category`, `description`, `active`) VALUES
(1, 'fmipmobile.icloud.com', 'apple_findmy', '', 1),
(2, 'fmip.icloud.com', 'apple_findmy', '', 1),
(3, 'findmy.apple.com', 'apple_findmy', '', 1),
(4, 'fmfmobile.icloud.com', 'apple_findmy', '', 1),
(5, 'fmip.fe2.apple-dns.net', 'apple_findmy', '', 1),
(6, 'fmf.fe2.apple-dns.net', 'apple_findmy', '', 1),
(7, 'gs-loc.apple.com', 'apple_findmy', '', 1),
(8, 'gsp-ssl.ls.apple.com', 'apple_findmy', '', 1),
(9, 'gsp10-ssl.ls.apple.com', 'apple_findmy', '', 1),
(10, 'gsp57-ssl-locus.ls.apple.com', 'apple_findmy', '', 1),
(11, 'gsp64-ssl.ls.apple.com', 'apple_findmy', '', 1),
(12, 'gsp85-ssl.ls.apple.com', 'apple_findmy', '', 1),
(13, 'ckdatabasews.icloud.com', 'apple_findmy', '', 1),
(14, 'keyvalueservice.icloud.com', 'apple_findmy', '', 0),
(15, 'push.apple.com', 'apple_findmy', '', 1),
(16, 'courier.push.apple.com', 'apple_findmy', '', 1),
(17, 'courier.sandbox.push.apple.com', 'apple_findmy', '', 1),
(18, 'init.push.apple.com', 'apple_findmy', '', 1),
(19, 'init-p01st.push.apple.com', 'apple_findmy', '', 1),
(20, 'init-p02st.push.apple.com', 'apple_findmy', '', 1),
(21, 'init-p03st.push.apple.com', 'apple_findmy', '', 1),
(22, 'p01-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(23, 'p02-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(24, 'p03-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(25, 'p04-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(26, 'p05-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(27, 'p06-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(28, 'p07-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(29, 'p08-fmipmobile.icloud.com', 'apple_findmy', '', 1),
(30, 'p01-fmip.icloud.com', 'apple_findmy', '', 1),
(31, 'p01-ckdatabasews.icloud.com', 'apple_findmy', '', 1),
(32, 'p01-keyvalueservice.icloud.com', 'apple_findmy', '', 0),
(33, 'p01-content.icloud.com', 'apple_findmy', '', 1),
(34, 'p02-content.icloud.com', 'apple_findmy', '', 1),
(35, 'p03-content.icloud.com', 'apple_findmy', '', 1),
(36, 'cl1-cdn.origin-apple.com.akadns.net', 'apple_findmy', '', 1),
(37, 'ls.apple.com', 'apple_findmy', '', 1),
(38, 'content.icloud.com', 'apple_findmy', '', 1),
(39, 'albert.apple.com', 'apple_activation', '', 1),
(40, 'deviceenrollment.apple.com', 'apple_activation', '', 1),
(41, 'setup.icloud.com', 'apple_activation', '', 1),
(42, 'identity.apple.com', 'apple_activation', '', 1),
(43, 'appleid.apple.com', 'apple_activation', '', 1),
(44, 'escrowproxy.icloud.com', 'apple_activation', '', 1),
(45, 'mdmenrollment.apple.com', 'apple_activation', '', 1),
(46, 'deviceservices-external.apple.com', 'apple_activation', '', 1),
(47, 'gdmf.apple.com', 'apple_activation', '', 1),
(48, 'gs.apple.com', 'apple_activation', '', 1),
(49, 'tbsc.apple.com', 'apple_activation', '', 1),
(50, 'static.ips.apple.com', 'apple_activation', '', 1),
(52, 'icloud-content.com', 'apple_icloud', '', 1),
(53, 'p01-icloud.icloud.com', 'apple_icloud', '', 1),
(54, 'p02-icloud.icloud.com', 'apple_icloud', '', 1),
(55, 'p03-icloud.icloud.com', 'apple_icloud', '', 1),
(56, 'configuration.ls.apple.com', 'apple_icloud', '', 1),
(57, 'bag.itunes.apple.com', 'apple_icloud', '', 1),
(58, 'inappcheck.itunes.apple.com', 'apple_icloud', '', 1),
(59, 'apple-dns.net', 'apple_icloud', '', 1),
(60, 'aaplimg.com', 'apple_icloud', '', 1),
(61, 'caldav.icloud.com', 'apple_icloud', '', 1),
(62, 'carddav.icloud.com', 'apple_icloud', '', 1),
(63, 'quota.icloud.com', 'apple_icloud', '', 1),
(64, 'ckdevice.icloud.com', 'apple_icloud', '', 1),
(65, 'apple.com', 'apple_full', '', 1),
(66, 'sequoia.cdn-apple.com', 'apple_full', '', 1),
(67, 'swscan.apple.com', 'apple_full', '', 1),
(68, 'swdist.apple.com', 'apple_full', '', 1),
(69, 'swcdn.apple.com', 'apple_full', '', 1),
(70, 'mesu.apple.com', 'apple_full', '', 1),
(71, 'osrecovery.apple.com', 'apple_full', '', 1),
(72, 'appldnld.apple.com', 'apple_full', '', 1),
(73, 'updates-http.cdn-apple.com', 'apple_full', '', 1),
(74, 'mzstatic.com', 'apple_full', '', 1),
(75, 'token.safebrowsing.apple', 'apple_full', '', 1),
(76, 'weather-data.apple.com', 'apple_full', '', 1),
(77, 'news-client.apple.com', 'apple_full', '', 1),
(78, 'stocks-data-service.apple.com', 'apple_full', '', 1),
(79, 'smp-device-content.apple.com', 'apple_full', '', 1),
(80, 'findmymobile.samsung.com', 'samsung_find', '', 1),
(81, 'samsungfind.samsung.com', 'samsung_find', '', 1),
(82, 'fmm.samsung.com', 'samsung_find', '', 1),
(83, 'fmmcore.samsung.com', 'samsung_find', '', 1),
(84, 'gslb-findmymobile.samsung.com', 'samsung_find', '', 1),
(85, 'api-findmymobile.samsung.com', 'samsung_find', '', 1),
(86, 'fmmretry.samsung.com', 'samsung_find', '', 1),
(87, 'push.samsungosp.com', 'samsung_find', '', 1),
(88, 'pushapi.samsungosp.com', 'samsung_find', '', 1),
(89, 'eu-auth2.samsungosp.com', 'samsung_find', '', 1),
(90, 'us-auth2.samsungosp.com', 'samsung_find', '', 1),
(91, 'vas.samsungapps.com', 'samsung_lock', '', 1),
(92, 'odc.samsungcloud.com', 'samsung_lock', '', 1),
(93, 'samsungcloud.com', 'samsung_lock', '', 1),
(94, 'api.samsungcloud.com', 'samsung_lock', '', 1),
(95, 'find.xiaomi.com', 'xiaomi_find', '', 1),
(96, 'i.mi.com', 'xiaomi_find', '', 1),
(97, 'tracking.miui.com', 'xiaomi_find', '', 1),
(98, 'lbs.xiaomi.com', 'xiaomi_find', '', 1),
(99, 'api.find.xiaomi.com', 'xiaomi_find', '', 1),
(100, 'globalapi.find.xiaomi.com', 'xiaomi_find', '', 1),
(101, 'sdkconfig.ad.xiaomi.com', 'xiaomi_find', '', 1),
(102, 'resolver.msg.xiaomi.net', 'xiaomi_find', '', 1),
(103, 'register.xmpush.xiaomi.com', 'xiaomi_find', '', 1),
(104, 'id.xiaomi.com', 'xiaomi_lock', '', 1),
(105, 'passport.xiaomi.com', 'xiaomi_lock', '', 1),
(106, 'micloud.xiaomi.net', 'xiaomi_lock', '', 1),
(107, 'api.account.xiaomi.com', 'xiaomi_lock', '', 1),
(108, 'unlock.update.miui.com', 'xiaomi_lock', '', 1),
(109, 'android.googleapis.com', 'google_find', '', 1),
(110, 'www.googleapis.com', 'google_find', '', 1),
(111, 'android.clients.google.com', 'google_find', '', 1),
(112, 'play.googleapis.com', 'google_find', '', 1),
(113, 'firebaseinstallations.googleapis.com', 'google_find', '', 1),
(114, 'fcm.googleapis.com', 'google_find', '', 1),
(115, 'mtalk.google.com', 'google_find', '', 1),
(116, 'alt1-mtalk.google.com', 'google_find', '', 1),
(117, 'alt2-mtalk.google.com', 'google_find', '', 1),
(118, 'alt3-mtalk.google.com', 'google_find', '', 1),
(119, 'alt4-mtalk.google.com', 'google_find', '', 1),
(120, 'findphone.hicloud.com', 'huawei_find', '', 1),
(121, 'cloud.huawei.com', 'huawei_find', '', 1),
(122, 'findmyphone.hicloud.com', 'huawei_find', '', 1),
(123, 'hicloud.com', 'huawei_find', '', 1),
(124, 'push.hicloud.com', 'huawei_find', '', 1),
(125, 'login.cloud.huawei.com', 'huawei_find', '', 1),
(126, 'api.hicloud.com', 'huawei_find', '', 1),
(127, 'facebook.com', 'social', '', 1),
(128, 'instagram.com', 'social', '', 1),
(129, 'tiktok.com', 'social', '', 1),
(130, 'twitter.com', 'social', '', 1),
(131, 'x.com', 'social', '', 1),
(132, 'snapchat.com', 'social', '', 1),
(133, 'reddit.com', 'social', '', 1),
(134, 'threads.net', 'social', '', 1),
(135, 'whatsapp.com', 'social', '', 1),
(136, 'telegram.org', 'social', '', 1),
(137, 'pornhub.com', 'adult', '', 1),
(138, 'xvideos.com', 'adult', '', 1),
(139, 'xnxx.com', 'adult', '', 1),
(140, 'xhamster.com', 'adult', '', 1),
(141, 'redtube.com', 'adult', '', 1),
(142, 'youporn.com', 'adult', '', 1),
(143, 'spankbang.com', 'adult', '', 1),
(144, 'store.steampowered.com', 'gaming', '', 1),
(145, 'epicgames.com', 'gaming', '', 1),
(146, 'roblox.com', 'gaming', '', 1),
(147, 'freefire.garena.com', 'gaming', '', 1),
(148, 'pubgmobile.com', 'gaming', '', 1),
(149, 'cl3.apple.com', 'apple_findmy', '', 0),
(150, 'cl.apple.com', 'apple_findmy', 'Apple Cloud Delivery (clN.apple.com)', 0),
(151, 'captive.apple.com', 'custom', '', 1),
(154, 'fmipmobile.fe2.apple-dns.net', 'apple_findmy', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `codes`
--

CREATE TABLE `codes` (
  `id` int(11) NOT NULL,
  `code` varchar(16) NOT NULL,
  `label` varchar(100) DEFAULT NULL COMMENT 'Friendly name',
  `plan_id` int(11) DEFAULT NULL COMMENT 'FK device_pricing.id',
  `blocked_categories` text DEFAULT NULL COMMENT 'CSV of category names',
  `duration_hours` int(11) NOT NULL DEFAULT 0 COMMENT '0 = permanent',
  `max_devices` int(11) NOT NULL DEFAULT 1 COMMENT 'concurrent uses',
  `used_count` int(11) NOT NULL DEFAULT 0,
  `status` enum('active','paused','revoked','expired') NOT NULL DEFAULT 'active',
  `owner_id` int(11) DEFAULT NULL COMMENT 'users.id who created',
  `assigned_to` int(11) DEFAULT NULL COMMENT 'users.id end user (optional)',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `first_used_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `codes`
--

INSERT INTO `codes` (`id`, `code`, `label`, `plan_id`, `blocked_categories`, `duration_hours`, `max_devices`, `used_count`, `status`, `owner_id`, `assigned_to`, `created_at`, `first_used_at`, `expires_at`, `notes`) VALUES
(48, 'Q9PWGC', NULL, NULL, 'apple_activation', 24, 1, 0, 'active', 1, NULL, '2026-10-17 17:08:24', '2026-10-17 17:15:52', NULL, NULL),
(49, 'HG5W49', NULL, NULL, 'apple_findmy', 24, 1, 1, 'active', 1, NULL, '2026-10-17 17:17:59', '2026-10-17 17:20:50', NULL, NULL),
(50, '88G55E', NULL, NULL, 'apple_findmy', 6, 1, 1, 'active', 1, NULL, '2026-10-17 17:29:08', '2026-10-17 17:29:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `credit_history`
--

CREATE TABLE `credit_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL COMMENT 'Positive=add, Negative=deduct',
  `balance_after` decimal(10,2) NOT NULL DEFAULT 0.00,
  `reason` varchar(255) NOT NULL DEFAULT '',
  `related_device_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `daemon_status`
--

CREATE TABLE `daemon_status` (
  `id` int(11) NOT NULL,
  `vps_ip` varchar(45) NOT NULL,
  `status` enum('online','offline') DEFAULT 'offline',
  `devices_active` int(11) DEFAULT 0,
  `dns_running` tinyint(1) DEFAULT 0,
  `uptime_seconds` int(11) DEFAULT 0,
  `last_heartbeat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `daemon_status`
--

INSERT INTO `daemon_status` (`id`, `vps_ip`, `status`, `devices_active`, `dns_running`, `uptime_seconds`, `last_heartbeat`) VALUES
(2, '92.60.70.7', 'online', 0, 1, 13497, '2026-06-24 01:22:12'),
(3, '186.240.154.217', 'online', 2, 1, 777, '2026-10-17 14:56:56');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(11) NOT NULL,
  `code_id` int(11) DEFAULT NULL,
  `code` varchar(6) NOT NULL COMMENT '6-char activation code (e.g. A3K9F2)',
  `ip` varchar(45) DEFAULT NULL COMMENT 'Device IP, set by captive portal visit',
  `device_name` varchar(100) DEFAULT '' COMMENT 'Friendly name',
  `device_type` varchar(100) DEFAULT 'Unknown' COMMENT 'Detected device type',
  `status` enum('pending','active','expired','suspended') NOT NULL DEFAULT 'pending',
  `blocked_categories` text DEFAULT NULL COMMENT 'Comma-separated category names',
  `blocked_domains_custom` text DEFAULT NULL COMMENT 'Extra domains to block',
  `allowed_domains` text DEFAULT NULL COMMENT 'If set, ONLY these domains work',
  `active` tinyint(1) DEFAULT 1,
  `expires_at` datetime DEFAULT NULL COMMENT 'NULL = permanent/no expiry',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL COMMENT 'Reseller who owns this device',
  `assigned_to` int(11) DEFAULT NULL COMMENT 'Standard user assignment',
  `credit_cost` decimal(10,2) NOT NULL DEFAULT 0.00,
  `activated_at` datetime DEFAULT NULL,
  `logged_in_at` datetime DEFAULT NULL,
  `logged_out_at` datetime DEFAULT NULL,
  `last_seen` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `device_ua` text DEFAULT NULL COMMENT 'Raw User-Agent string',
  `device_brand` varchar(50) DEFAULT NULL COMMENT 'Apple / Samsung / Xiaomi / Huawei / Windows',
  `device_model` varchar(100) DEFAULT NULL COMMENT 'iPhone / iPad / SM-G998B / Redmi Note 12',
  `device_os` varchar(50) DEFAULT NULL COMMENT 'iOS 17.0 / Android 14 / macOS 14.2',
  `device_country` varchar(100) DEFAULT NULL COMMENT 'Colombia / Mexico / etc (from IP geolocation)',
  `device_region` varchar(100) DEFAULT NULL COMMENT 'Bogota D.C. / Jalisco / etc',
  `device_city` varchar(100) DEFAULT NULL COMMENT 'Bogota / Guadalajara / etc',
  `device_language` varchar(20) DEFAULT NULL COMMENT 'es-419 / en / pt-br (from Accept-Language)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `code_id`, `code`, `ip`, `device_name`, `device_type`, `status`, `blocked_categories`, `blocked_domains_custom`, `allowed_domains`, `active`, `expires_at`, `notes`, `created_by`, `owner_id`, `assigned_to`, `credit_cost`, `activated_at`, `logged_in_at`, `logged_out_at`, `last_seen`, `created_at`, `updated_at`, `device_ua`, `device_brand`, `device_model`, `device_os`, `device_country`, `device_region`, `device_city`, `device_language`) VALUES
(28, 49, 'HG5W49', '216.234.211.78', '', 'Unknown', 'active', 'apple_findmy', NULL, NULL, 1, '2026-10-18 17:20:50', NULL, NULL, NULL, NULL, 0.00, '2026-10-17 17:20:50', '2026-10-17 17:20:50', NULL, '2026-10-17 17:46:34', '2026-10-17 14:20:50', '2026-10-17 14:46:34', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148', 'Apple', 'iPhone', 'iOS 18.7', NULL, NULL, NULL, NULL),
(29, 50, '88G55E', '41.220.42.131', '', 'Unknown', 'active', 'apple_findmy', NULL, NULL, 1, '2026-10-17 23:29:33', NULL, NULL, NULL, NULL, 0.00, '2026-10-17 17:29:33', '2026-10-17 17:29:33', NULL, '2026-10-17 17:35:28', '2026-10-17 14:29:33', '2026-10-17 14:35:28', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148', 'Apple', 'iPhone', 'iOS 18.7', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `device_events`
--

CREATE TABLE `device_events` (
  `id` int(11) NOT NULL,
  `action` enum('sync','reload','device_created','device_deleted','device_edited','device_renewed','device_activated','device_suspended','settings_changed','cleanup') NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `processed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `processed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `device_events`
--

INSERT INTO `device_events` (`id`, `action`, `data`, `processed`, `created_at`, `processed_at`) VALUES
(570, 'device_suspended', '{\"code_id\":41,\"reason\":\"code_paused\"}', 1, '2026-10-17 13:03:50', '2026-10-17 17:07:19'),
(571, 'device_suspended', '{\"code_id\":39,\"reason\":\"code_paused\"}', 1, '2026-10-17 13:04:00', '2026-10-17 17:07:19'),
(572, 'device_suspended', '{\"single\":\"delete_device\",\"device_id\":24}', 1, '2026-10-17 13:05:14', '2026-10-17 17:07:19'),
(573, 'device_suspended', '{\"single\":\"delete_device\",\"device_id\":23}', 1, '2026-10-17 13:05:18', '2026-10-17 17:07:19'),
(574, 'device_activated', '{\"device_id\":27,\"code\":\"Q9PWGC\",\"ip\":\"216.234.211.78\"}', 1, '2026-10-17 14:15:52', '2026-10-17 17:15:52'),
(575, 'device_suspended', '{\"single\":\"delete_device\",\"device_id\":27}', 1, '2026-10-17 14:19:20', '2026-10-17 17:19:21'),
(576, 'device_activated', '{\"device_id\":28,\"code\":\"HG5W49\",\"ip\":\"216.234.211.78\"}', 1, '2026-10-17 14:20:50', '2026-10-17 17:20:52'),
(577, 'device_activated', '{\"device_id\":29,\"code\":\"88G55E\",\"ip\":\"41.220.42.131\"}', 1, '2026-10-17 14:29:33', '2026-10-17 17:29:34');

-- --------------------------------------------------------

--
-- Table structure for table `device_live_stats`
--

CREATE TABLE `device_live_stats` (
  `id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `connected_ips` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `active_connections` int(11) DEFAULT 0,
  `total_connections` int(11) DEFAULT 0,
  `total_bytes` bigint(20) DEFAULT 0,
  `dns_queries` int(11) DEFAULT 0,
  `dns_blocked` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `device_live_stats`
--

INSERT INTO `device_live_stats` (`id`, `device_id`, `connected_ips`, `active_connections`, `total_connections`, `total_bytes`, `dns_queries`, `dns_blocked`, `updated_at`) VALUES
(25073, 28, '[\"216.234.211.78\"]', 0, 0, 65280, 162, 0, '2026-10-17 14:46:34'),
(25107, 29, '[\"41.220.42.131\"]', 0, 0, 71928, 194, 0, '2026-10-17 14:35:28');

-- --------------------------------------------------------

--
-- Table structure for table `device_logs`
--

CREATE TABLE `device_logs` (
  `id` int(11) NOT NULL,
  `device_id` int(11) DEFAULT NULL,
  `action` enum('created','deleted','renewed','expired','activated','deactivated','edited','suspended','unsuspended') DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `device_pricing`
--

CREATE TABLE `device_pricing` (
  `id` int(11) NOT NULL,
  `plan_name` varchar(100) NOT NULL DEFAULT 'DNS Access',
  `duration_hours` int(11) NOT NULL,
  `duration_label` varchar(50) NOT NULL,
  `credits` decimal(10,2) NOT NULL,
  `default_categories` varchar(500) NOT NULL DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `device_pricing`
--

INSERT INTO `device_pricing` (`id`, `plan_name`, `duration_hours`, `duration_label`, `credits`, `default_categories`, `active`, `sort_order`) VALUES
(1, 'DNS - Apple Find My', 1, '1 Hour', 1.00, 'apple_findmy', 1, 1),
(2, 'DNS - Apple Find My', 6, '6 Hours', 3.00, 'apple_findmy', 1, 2),
(3, 'DNS - Apple Find My', 12, '12 Hours', 5.00, 'apple_findmy', 1, 3),
(4, 'DNS - Apple Find My', 24, '1 Day', 8.00, 'apple_findmy', 1, 4),
(5, 'DNS - Apple Find My', 72, '3 Days', 15.00, 'apple_findmy', 1, 5),
(6, 'DNS - Apple Find My', 168, '7 Days', 30.00, 'apple_findmy', 1, 6),
(7, 'DNS - Apple Find My', 360, '15 Days', 50.00, 'apple_findmy', 1, 7),
(8, 'DNS - Apple Find My', 720, '30 Days', 80.00, 'apple_findmy', 1, 8),
(9, 'DNS - Apple Find My', 0, 'Permanent', 150.00, 'apple_findmy', 1, 9),
(10, 'DNS - Apple Activation', 24, '1 Day', 8.00, 'apple_activation', 1, 10),
(11, 'DNS - Apple Activation', 168, '7 Days', 30.00, 'apple_activation', 1, 11),
(12, 'DNS - Apple Activation', 720, '30 Days', 80.00, 'apple_activation', 1, 12),
(13, 'DNS - Apple Activation', 0, 'Permanent', 150.00, 'apple_activation', 1, 13),
(14, 'DNS - Apple iCloud', 24, '1 Day', 8.00, 'apple_icloud', 1, 14),
(15, 'DNS - Apple iCloud', 168, '7 Days', 30.00, 'apple_icloud', 1, 15),
(16, 'DNS - Apple iCloud', 720, '30 Days', 80.00, 'apple_icloud', 1, 16),
(17, 'DNS - Apple iCloud', 0, 'Permanent', 150.00, 'apple_icloud', 1, 17),
(18, 'DNS - Apple Full', 24, '1 Day', 12.00, 'apple_findmy,apple_activation,apple_icloud,apple_full', 1, 18),
(19, 'DNS - Apple Full', 168, '7 Days', 40.00, 'apple_findmy,apple_activation,apple_icloud,apple_full', 1, 19),
(20, 'DNS - Apple Full', 720, '30 Days', 100.00, 'apple_findmy,apple_activation,apple_icloud,apple_full', 1, 20),
(21, 'DNS - Apple Full', 0, 'Permanent', 180.00, 'apple_findmy,apple_activation,apple_icloud,apple_full', 1, 21),
(22, 'DNS - Samsung Find', 24, '1 Day', 8.00, 'samsung_find', 1, 22),
(23, 'DNS - Samsung Find', 168, '7 Days', 30.00, 'samsung_find', 1, 23),
(24, 'DNS - Samsung Find', 720, '30 Days', 80.00, 'samsung_find', 1, 24),
(25, 'DNS - Samsung Find', 0, 'Permanent', 150.00, 'samsung_find', 1, 25),
(26, 'DNS - Samsung Knox', 24, '1 Day', 8.00, 'samsung_lock', 1, 26),
(27, 'DNS - Samsung Knox', 168, '7 Days', 30.00, 'samsung_lock', 1, 27),
(28, 'DNS - Samsung Knox', 720, '30 Days', 80.00, 'samsung_lock', 1, 28),
(29, 'DNS - Samsung Knox', 0, 'Permanent', 150.00, 'samsung_lock', 1, 29),
(30, 'DNS - Xiaomi Find', 24, '1 Day', 8.00, 'xiaomi_find', 1, 30),
(31, 'DNS - Xiaomi Find', 168, '7 Days', 30.00, 'xiaomi_find', 1, 31),
(32, 'DNS - Xiaomi Find', 720, '30 Days', 80.00, 'xiaomi_find', 1, 32),
(33, 'DNS - Xiaomi Find', 0, 'Permanent', 150.00, 'xiaomi_find', 1, 33),
(34, 'DNS - Xiaomi Account', 24, '1 Day', 8.00, 'xiaomi_lock', 1, 34),
(35, 'DNS - Xiaomi Account', 168, '7 Days', 30.00, 'xiaomi_lock', 1, 35),
(36, 'DNS - Xiaomi Account', 720, '30 Days', 80.00, 'xiaomi_lock', 1, 36),
(37, 'DNS - Xiaomi Account', 0, 'Permanent', 150.00, 'xiaomi_lock', 1, 37),
(38, 'DNS - Google Find', 24, '1 Day', 8.00, 'google_find', 1, 38),
(39, 'DNS - Google Find', 168, '7 Days', 30.00, 'google_find', 1, 39),
(40, 'DNS - Google Find', 720, '30 Days', 80.00, 'google_find', 1, 40),
(41, 'DNS - Google Find', 0, 'Permanent', 150.00, 'google_find', 1, 41),
(42, 'DNS - Huawei Find', 24, '1 Day', 8.00, 'huawei_find', 1, 42),
(43, 'DNS - Huawei Find', 168, '7 Days', 30.00, 'huawei_find', 1, 43),
(44, 'DNS - Huawei Find', 720, '30 Days', 80.00, 'huawei_find', 1, 44),
(45, 'DNS - Huawei Find', 0, 'Permanent', 150.00, 'huawei_find', 1, 45),
(46, 'Test Plan', 24, '1 Day', 5.00, 'apple_findmy', 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `dhru_api_keys`
--

CREATE TABLE `dhru_api_keys` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `api_username` varchar(64) NOT NULL,
  `api_key` varchar(128) NOT NULL,
  `label` varchar(100) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `last_used_at` datetime DEFAULT NULL,
  `requests_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `dhru_api_keys`
--

INSERT INTO `dhru_api_keys` (`id`, `user_id`, `api_username`, `api_key`, `label`, `active`, `last_used_at`, `requests_count`, `created_at`) VALUES
(1, 1, 'rc_1_19e575', '1f4900836393e6f12262c62160d5cb2a898161163c726286', 'Dhru link', 1, NULL, 0, '2026-04-17 19:07:32');

-- --------------------------------------------------------

--
-- Table structure for table `dhru_orders`
--

CREATE TABLE `dhru_orders` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_name` varchar(150) NOT NULL,
  `device_ref` varchar(100) NOT NULL COMMENT 'IMEI or device identifier',
  `device_id` int(11) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','active','refunded') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `dns_log`
--

CREATE TABLE `dns_log` (
  `id` int(11) NOT NULL,
  `device_id` int(11) DEFAULT NULL,
  `code_id` int(11) DEFAULT NULL,
  `client_ip` varchar(45) NOT NULL,
  `domain` varchar(255) DEFAULT '',
  `qtype` varchar(8) DEFAULT NULL,
  `status` enum('blocked','safe','forwarded','captive','always_blocked','safe_override','doh_block','infra_safe','unauthorized_blocked') NOT NULL,
  `reason` varchar(32) DEFAULT NULL,
  `latency_ms` int(11) DEFAULT NULL,
  `device_type` varchar(50) DEFAULT 'Unknown',
  `bytes_transferred` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `dns_log`
--

INSERT INTO `dns_log` (`id`, `device_id`, `code_id`, `client_ip`, `domain`, `qtype`, `status`, `reason`, `latency_ms`, `device_type`, `bytes_transferred`, `created_at`) VALUES
(206429, 27, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:16:49'),
(206430, 27, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:16:49'),
(206431, 27, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:16:49'),
(206432, 27, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:16:49'),
(206433, 27, NULL, '216.234.211.78', '1-courier2.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:17:03'),
(206434, 27, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:17:03'),
(206435, 27, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:17:03'),
(206436, 27, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:17:05'),
(206437, 27, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:17:05'),
(206438, 27, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:17:07'),
(206439, 27, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:17:07'),
(206440, 27, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:17:07'),
(206441, 27, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:17:07'),
(206442, 27, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:17:10'),
(206443, 27, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:17:10'),
(206444, 27, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:17:11'),
(206445, 27, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:17:11'),
(206446, 27, NULL, '216.234.211.78', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:17:12'),
(206447, 27, NULL, '216.234.211.78', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:17:12'),
(206448, 27, NULL, '216.234.211.78', 'e6858.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:17:12'),
(206449, 27, NULL, '216.234.211.78', 'securemetrics.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:15'),
(206450, 27, NULL, '216.234.211.78', 'securemetrics.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:15'),
(206451, 27, NULL, '216.234.211.78', 'itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:17:15'),
(206452, 27, NULL, '216.234.211.78', 'itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:17:15'),
(206453, 27, NULL, '216.234.211.78', 'securemetrics.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:17:15'),
(206454, 27, NULL, '216.234.211.78', 'e673.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:17:15'),
(206455, 27, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:17:17'),
(206456, 27, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:17:17'),
(206457, 27, NULL, '216.234.211.78', 'ifreeicloud.co.uk', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:17:17'),
(206458, 27, NULL, '216.234.211.78', 'clients.l.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:17:17'),
(206459, 27, NULL, '216.234.211.78', 'ifreeicloud.co.uk', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:17:17'),
(206460, 27, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:17:18'),
(206461, 27, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:17:18'),
(206462, 27, NULL, '216.234.211.78', 'a1317.dscb.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:17:18'),
(206463, 27, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:17:22'),
(206464, 27, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:17:22'),
(206465, 27, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:17:22'),
(206466, 27, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:17:22'),
(206467, 27, NULL, '216.234.211.78', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:22'),
(206468, 27, NULL, '216.234.211.78', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:22'),
(206469, 27, NULL, '216.234.211.78', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:22'),
(206470, 27, NULL, '216.234.211.78', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:22'),
(206471, 27, NULL, '216.234.211.78', 'cvws.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:17:22'),
(206472, 27, NULL, '216.234.211.78', 'setup.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:17:22'),
(206473, 27, NULL, '216.234.211.78', 'appleid.cdn-apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:17:24'),
(206474, 27, NULL, '216.234.211.78', 'appleid.cdn-apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:17:24'),
(206475, 27, NULL, '216.234.211.78', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:17:29'),
(206476, 27, NULL, '216.234.211.78', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:17:29'),
(206477, 27, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:18:03'),
(206478, 27, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:18:08'),
(206479, 27, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:18:08'),
(206480, NULL, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:19:42'),
(206481, NULL, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:19:42'),
(206482, NULL, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:42'),
(206483, NULL, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:42'),
(206484, NULL, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:42'),
(206485, NULL, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:42'),
(206486, NULL, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:19:42'),
(206487, NULL, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:19:42'),
(206488, NULL, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:43'),
(206489, NULL, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:19:43'),
(206490, NULL, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:19:43'),
(206491, NULL, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:19:43'),
(206492, NULL, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:19:43'),
(206493, NULL, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:19:43'),
(206494, NULL, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:19:43'),
(206495, NULL, NULL, '216.234.211.78', '39-courier2.push.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 44, '2026-10-17 14:19:43'),
(206496, NULL, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:19:45'),
(206497, NULL, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:19:45'),
(206498, NULL, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:19:46'),
(206499, NULL, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:20:02'),
(206500, NULL, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:20:51'),
(206501, 28, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:20:55'),
(206502, 28, NULL, '216.234.211.78', 'probe-gp35vy3d.iblocker.test', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:20:55'),
(206503, 28, NULL, '216.234.211.78', 'probe-gp35vy3d.iblocker.test', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:20:55'),
(206504, 28, NULL, '216.234.211.78', 'euc1-wps-prod.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:20:56'),
(206505, 28, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:02'),
(206506, 28, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:02'),
(206507, 28, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:02'),
(206508, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:02'),
(206509, 28, NULL, '216.234.211.78', 'euc1-wps-prod.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:03'),
(206510, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:21:03'),
(206511, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:21:03'),
(206512, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:21:04'),
(206513, 28, NULL, '216.234.211.78', 'euc1-wps-prod.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:04'),
(206514, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:21:04'),
(206515, 28, NULL, '216.234.211.78', 'web.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:05'),
(206516, 28, NULL, '216.234.211.78', 'gateway.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:05'),
(206517, 28, NULL, '216.234.211.78', 'web.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:05'),
(206518, 28, NULL, '216.234.211.78', 'edge-mqtt.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:05'),
(206519, 28, NULL, '216.234.211.78', 'dit.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:05'),
(206520, 28, NULL, '216.234.211.78', 'dit.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:05'),
(206521, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:21:05'),
(206522, 28, NULL, '216.234.211.78', 'apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 27, '2026-10-17 14:21:05'),
(206523, 28, NULL, '216.234.211.78', 'graph.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:05'),
(206524, 28, NULL, '216.234.211.78', 'star.c10r.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:05'),
(206525, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:05'),
(206526, 28, NULL, '216.234.211.78', 'g.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:21:05'),
(206527, 28, NULL, '216.234.211.78', 'api.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:05'),
(206528, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:21:05'),
(206529, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:05'),
(206530, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:05'),
(206531, 28, NULL, '216.234.211.78', 'web.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:07'),
(206532, 28, NULL, '216.234.211.78', 'media-jnb2-1.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:08'),
(206533, 28, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:21:09'),
(206534, 28, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:21:09'),
(206535, 28, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:10'),
(206536, 28, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:10'),
(206537, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:21:11'),
(206538, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:21:11'),
(206539, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:21:11'),
(206540, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:20'),
(206541, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:20'),
(206542, 28, NULL, '216.234.211.78', 'clients.l.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:21'),
(206543, 28, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:21:21'),
(206544, 28, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:21:21'),
(206545, 28, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:21'),
(206546, 28, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:21:21'),
(206547, 28, NULL, '216.234.211.78', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:21'),
(206548, 28, NULL, '216.234.211.78', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:21'),
(206549, 28, NULL, '216.234.211.78', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:21'),
(206550, 28, NULL, '216.234.211.78', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:21'),
(206551, 28, NULL, '216.234.211.78', 'a1317.dscb.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:21'),
(206552, 28, NULL, '216.234.211.78', 'cvws.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:21'),
(206553, 28, NULL, '216.234.211.78', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:22'),
(206554, 28, NULL, '216.234.211.78', 'appleid.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:22'),
(206555, 28, NULL, '216.234.211.78', 'appleid.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:22'),
(206556, 28, NULL, '216.234.211.78', 'a642.dscd.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:22'),
(206557, 28, NULL, '216.234.211.78', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:26'),
(206558, 28, NULL, '216.234.211.78', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:26'),
(206559, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:21:26'),
(206560, 28, NULL, '216.234.211.78', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:29'),
(206561, 28, NULL, '216.234.211.78', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:29'),
(206562, 28, NULL, '216.234.211.78', 'gsa.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:29'),
(206563, 28, NULL, '216.234.211.78', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:32'),
(206564, 28, NULL, '216.234.211.78', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:32'),
(206565, 28, NULL, '216.234.211.78', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:32'),
(206566, 28, NULL, '216.234.211.78', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:32'),
(206567, 28, NULL, '216.234.211.78', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:32'),
(206568, 28, NULL, '216.234.211.78', 'pd.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:34'),
(206569, 28, NULL, '216.234.211.78', 'pd.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:34'),
(206570, 28, NULL, '216.234.211.78', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:21:34'),
(206571, 28, NULL, '216.234.211.78', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:21:34'),
(206572, 28, NULL, '216.234.211.78', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:34'),
(206573, 28, NULL, '216.234.211.78', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:34'),
(206574, 28, NULL, '216.234.211.78', 'amp-api-search-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:21:34'),
(206575, 28, NULL, '216.234.211.78', 'amp-api-search-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:21:34'),
(206576, 28, NULL, '216.234.211.78', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:34'),
(206577, 28, NULL, '216.234.211.78', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:34'),
(206578, 28, NULL, '216.234.211.78', 'e673.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:21:34'),
(206579, 28, NULL, '216.234.211.78', 'entitlements-itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:21:35'),
(206580, 28, NULL, '216.234.211.78', 'idmsa.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:38'),
(206581, 28, NULL, '216.234.211.78', 'idmsa.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:21:38'),
(206582, 28, NULL, '216.234.211.78', 'idmsa.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:21:38'),
(206583, 28, NULL, '216.234.211.78', 'ocsp.digicert.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:21:39'),
(206584, 28, NULL, '216.234.211.78', 'ocsp.digicert.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:21:39'),
(206585, 28, NULL, '216.234.211.78', 'eip-terr-eu.cdp1.digicert.com.akahost.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 59, '2026-10-17 14:21:39'),
(206586, 28, NULL, '216.234.211.78', 'p197-setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:43'),
(206587, 28, NULL, '216.234.211.78', 'p197-contactsws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:43'),
(206588, 28, NULL, '216.234.211.78', 'p197-contactsws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:43'),
(206589, 28, NULL, '216.234.211.78', 'p197-setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:43'),
(206590, 28, NULL, '216.234.211.78', 'p197-remindersws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:21:43'),
(206591, 28, NULL, '216.234.211.78', 'p197-remindersws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:21:43'),
(206592, 28, NULL, '216.234.211.78', 'websocket.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:21:43'),
(206593, 28, NULL, '216.234.211.78', 'websocket.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:21:43'),
(206594, 28, NULL, '216.234.211.78', 'cdn.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:44'),
(206595, 28, NULL, '216.234.211.78', 'cdn.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:44'),
(206596, 28, NULL, '216.234.211.78', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:44'),
(206597, 28, NULL, '216.234.211.78', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:21:44'),
(206598, 28, NULL, '216.234.211.78', 'p197-docws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:44'),
(206599, 28, NULL, '216.234.211.78', 'p197-docws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:21:44'),
(206600, 28, NULL, '216.234.211.78', 'e3811.e9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:44'),
(206601, 28, NULL, '216.234.211.78', 'e6858.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:44'),
(206602, 28, NULL, '216.234.211.78', 'p197-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:21:46'),
(206603, 28, NULL, '216.234.211.78', 'p197-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:21:46'),
(206604, 28, NULL, '216.234.211.78', 'p197-fmipweb.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:48'),
(206605, 28, NULL, '216.234.211.78', 'p197-fmipweb.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:48'),
(206606, 28, NULL, '216.234.211.78', 'p197-keyvalueservice.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 49, '2026-10-17 14:21:49'),
(206607, 28, NULL, '216.234.211.78', 'p197-keyvalueservice.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 49, '2026-10-17 14:21:49'),
(206608, 28, NULL, '216.234.211.78', 'statici.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:49'),
(206609, 28, NULL, '216.234.211.78', 'statici.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:21:49'),
(206610, 28, NULL, '216.234.211.78', 'api.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:49'),
(206611, 28, NULL, '216.234.211.78', 'api.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:49'),
(206612, 28, NULL, '216.234.211.78', 'p197-mccgateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:49'),
(206613, 28, NULL, '216.234.211.78', 'p197-mccgateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:49'),
(206614, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:50'),
(206615, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:21:50'),
(206616, 28, NULL, '216.234.211.78', 'mwp6-eun1.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:50'),
(206617, 28, NULL, '216.234.211.78', 'e10489.a.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:21:50'),
(206618, 28, NULL, '216.234.211.78', 'mccgateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:21:50'),
(206619, 28, NULL, '216.234.211.78', 'p197-calendarws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:50'),
(206620, 28, NULL, '216.234.211.78', 'p197-calendarws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:21:50'),
(206621, 28, NULL, '216.234.211.78', 'p197-mcc.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:50'),
(206622, 28, NULL, '216.234.211.78', 'p197-mcc.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:21:50'),
(206623, 28, NULL, '216.234.211.78', 'gsp10.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:57'),
(206624, 28, NULL, '216.234.211.78', 'gsp10.apple-mapkit.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:21:57'),
(206625, 28, NULL, '216.234.211.78', 'gsp10-ssl.ls-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:21:57'),
(206626, 28, NULL, '216.234.211.78', 'nc-pod10-smp-device.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:59'),
(206627, 28, NULL, '216.234.211.78', 'nc-pod10-smp-device.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:21:59'),
(206628, 28, NULL, '216.234.211.78', 'nc-pod10-smp-device.gcsis-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 64, '2026-10-17 14:22:00'),
(206629, 28, NULL, '216.234.211.78', 'vntsnotificationservice.visa.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 50, '2026-10-17 14:22:05'),
(206630, 28, NULL, '216.234.211.78', 'vntsnotificationservice.visa.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 50, '2026-10-17 14:22:05'),
(206631, 28, NULL, '216.234.211.78', 'vntsnotificationservice.visa.com.cdn.cloudflare.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 69, '2026-10-17 14:22:05'),
(206632, 28, NULL, '216.234.211.78', 'h3.apis.apple.map.fastly.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:22:06'),
(206633, 28, NULL, '216.234.211.78', 'h3.apis.apple.map.fastly.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:22:06'),
(206634, 28, NULL, '216.234.211.78', 'graph.whatsapp.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:22:13'),
(206635, 28, NULL, '216.234.211.78', 'graph.whatsapp.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:22:13'),
(206636, 28, NULL, '216.234.211.78', 'whatsapp.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 30, '2026-10-17 14:22:15'),
(206637, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:22:56'),
(206638, 28, NULL, '216.234.211.78', 'feedbackws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:23:06'),
(206639, 28, NULL, '216.234.211.78', 'feedbackws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:23:06'),
(206640, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:23:15'),
(206641, 28, NULL, '216.234.211.78', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:23:47'),
(206642, 28, NULL, '216.234.211.78', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:23:47'),
(206643, 28, NULL, '216.234.211.78', 'iphone-ld.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:23:48'),
(206644, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:24:30'),
(206645, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:24:36'),
(206646, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:24:36'),
(206647, 28, NULL, '216.234.211.78', 'bag-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 56, '2026-10-17 14:24:39'),
(206648, 28, NULL, '216.234.211.78', 'bag-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 56, '2026-10-17 14:24:39'),
(206649, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:25:07'),
(206650, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:25:07'),
(206651, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:25:07'),
(206652, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:25:08'),
(206653, 28, NULL, '216.234.211.78', 'apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 27, '2026-10-17 14:25:08'),
(206654, 28, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:08'),
(206655, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:08'),
(206656, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:25:08'),
(206657, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:25:08'),
(206658, 28, NULL, '216.234.211.78', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:08'),
(206659, 28, NULL, '216.234.211.78', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:08'),
(206660, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:25:08'),
(206661, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:25:08'),
(206662, 28, NULL, '216.234.211.78', 'mesu.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:25:08'),
(206663, 28, NULL, '216.234.211.78', 'mesu.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:25:08'),
(206664, 28, NULL, '216.234.211.78', 'mesu.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:09'),
(206665, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:25:09'),
(206666, 28, NULL, '216.234.211.78', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:10'),
(206667, 28, NULL, '216.234.211.78', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:10'),
(206668, 28, NULL, '216.234.211.78', 'graph.whatsapp.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:25:10'),
(206669, 28, NULL, '216.234.211.78', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:10'),
(206670, 28, NULL, '216.234.211.78', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:10'),
(206671, 28, NULL, '216.234.211.78', 'init.ess.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:25:10'),
(206672, 28, NULL, '216.234.211.78', 'a1051.dscg4.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:25:10'),
(206673, 28, NULL, '216.234.211.78', 'mmg.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:25:11'),
(206674, 28, NULL, '216.234.211.78', 'mmg.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:25:11'),
(206675, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:25:11'),
(206676, 28, NULL, '216.234.211.78', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:25:12'),
(206677, 28, NULL, '216.234.211.78', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:25:12'),
(206678, 28, NULL, '216.234.211.78', 'g.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:25:18'),
(206679, 28, NULL, '216.234.211.78', 'api.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:25:18'),
(206680, 28, NULL, '216.234.211.78', 'api.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:25:18'),
(206681, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:43'),
(206682, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:25:43'),
(206683, 28, NULL, '216.234.211.78', 'dit.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:27:38'),
(206684, 28, NULL, '216.234.211.78', 'dit.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:27:38'),
(206685, 28, NULL, '216.234.211.78', 'media-jnb2-1.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:28:01'),
(206686, NULL, NULL, '41.220.42.131', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206687, NULL, NULL, '41.220.42.131', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206688, NULL, NULL, '41.220.42.131', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206689, NULL, NULL, '41.220.42.131', 'configuration-carry.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 50, '2026-10-17 14:28:51'),
(206690, NULL, NULL, '41.220.42.131', 'configuration-carry.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 50, '2026-10-17 14:28:51'),
(206691, NULL, NULL, '41.220.42.131', 'gsp85-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206692, NULL, NULL, '41.220.42.131', 'gsp85-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206693, NULL, NULL, '41.220.42.131', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206694, NULL, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206695, NULL, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206696, NULL, NULL, '41.220.42.131', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:28:51'),
(206697, NULL, NULL, '41.220.42.131', 'time.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:28:51'),
(206698, NULL, NULL, '41.220.42.131', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:28:51'),
(206699, NULL, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206700, NULL, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206701, NULL, NULL, '41.220.42.131', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206702, NULL, NULL, '41.220.42.131', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:28:51'),
(206703, NULL, NULL, '41.220.42.131', 'cl1.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206704, NULL, NULL, '41.220.42.131', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206705, NULL, NULL, '41.220.42.131', 'gspe35-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206706, NULL, NULL, '41.220.42.131', 'p189-acsegateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:28:51'),
(206707, NULL, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206708, NULL, NULL, '41.220.42.131', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206709, NULL, NULL, '41.220.42.131', 'cl1.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206710, NULL, NULL, '41.220.42.131', 'p189-acsegateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:28:51'),
(206711, NULL, NULL, '41.220.42.131', 'pds-init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206712, NULL, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206713, NULL, NULL, '41.220.42.131', 'pds-init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206714, NULL, NULL, '41.220.42.131', 'gspe35-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206715, NULL, NULL, '41.220.42.131', 'p189-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:28:51'),
(206716, NULL, NULL, '41.220.42.131', 'p189-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:28:51'),
(206717, NULL, NULL, '41.220.42.131', 'api.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206718, NULL, NULL, '41.220.42.131', 'api.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206719, NULL, NULL, '41.220.42.131', 'mesu.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:28:51'),
(206720, NULL, NULL, '41.220.42.131', 'p38-imap.mail.me.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206721, NULL, NULL, '41.220.42.131', 'app-site-association.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:28:51'),
(206722, NULL, NULL, '41.220.42.131', 'app-site-association.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:28:51'),
(206723, NULL, NULL, '41.220.42.131', 'guzzoni.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206724, NULL, NULL, '41.220.42.131', 'init.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206725, NULL, NULL, '41.220.42.131', 'guzzoni.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206726, NULL, NULL, '41.220.42.131', 'init.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206727, NULL, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:28:51'),
(206728, NULL, NULL, '41.220.42.131', 'configuration.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206729, NULL, NULL, '41.220.42.131', 'configuration.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206730, NULL, NULL, '41.220.42.131', 'cl3.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206731, NULL, NULL, '41.220.42.131', 'cl3.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:28:51'),
(206732, NULL, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:28:51'),
(206733, NULL, NULL, '41.220.42.131', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206734, NULL, NULL, '41.220.42.131', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:28:51'),
(206735, NULL, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206736, NULL, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206737, NULL, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206738, NULL, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206739, NULL, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:28:51'),
(206740, NULL, NULL, '41.220.42.131', 'p189-caldav.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206741, NULL, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:28:51'),
(206742, NULL, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:28:51'),
(206743, NULL, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:28:51'),
(206744, NULL, NULL, '41.220.42.131', 'p189-caldav.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:28:51'),
(206745, NULL, NULL, '41.220.42.131', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206746, NULL, NULL, '41.220.42.131', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:28:51'),
(206747, NULL, NULL, '41.220.42.131', 'push.apple.com', NULL, 'blocked', NULL, NULL, 'iPhone', 32, '2026-10-17 14:28:51'),
(206748, NULL, NULL, '41.220.42.131', 'gsa.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:28:51'),
(206749, NULL, NULL, '41.220.42.131', 'e14868.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:28:51'),
(206750, NULL, NULL, '41.220.42.131', 'e14868.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:28:51'),
(206751, NULL, NULL, '41.220.42.131', 'doh.dns.apple.com', NULL, 'doh_block', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206752, NULL, NULL, '41.220.42.131', 'doh.dns.apple.com', NULL, 'doh_block', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206753, NULL, NULL, '41.220.42.131', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:28:51'),
(206754, NULL, NULL, '41.220.42.131', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:28:51'),
(206755, NULL, NULL, '41.220.42.131', 'iphone-ld.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:28:51'),
(206756, NULL, NULL, '41.220.42.131', 'configuration.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:28:51'),
(206757, NULL, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:28:51'),
(206758, NULL, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:28:51'),
(206759, NULL, NULL, '41.220.42.131', 'tether.edge.apple', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206760, NULL, NULL, '41.220.42.131', 'tether.edge.apple', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:28:51'),
(206761, NULL, NULL, '41.220.42.131', 'entitlements-itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:28:51'),
(206762, NULL, NULL, '41.220.42.131', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:33'),
(206763, 29, NULL, '41.220.42.131', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:29:49'),
(206764, 29, NULL, '41.220.42.131', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:29:49'),
(206765, 29, NULL, '41.220.42.131', 'cl1.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206766, 29, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206767, 29, NULL, '41.220.42.131', 'static.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206768, 29, NULL, '41.220.42.131', 'time.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:49'),
(206769, 29, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206770, 29, NULL, '41.220.42.131', 'p189-acsegateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:29:49'),
(206771, 29, NULL, '41.220.42.131', 'cl1.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206772, 29, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:49'),
(206773, 29, NULL, '41.220.42.131', 'static.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206774, 29, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:49'),
(206775, 29, NULL, '41.220.42.131', 'p189-acsegateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:29:49'),
(206776, 29, NULL, '41.220.42.131', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206777, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206778, 29, NULL, '41.220.42.131', 'cl3.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206779, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206780, 29, NULL, '41.220.42.131', 'iphone-ld.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206781, 29, NULL, '41.220.42.131', 'configuration.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206782, 29, NULL, '41.220.42.131', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:49'),
(206783, 29, NULL, '41.220.42.131', 'configuration.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206784, 29, NULL, '41.220.42.131', 'cl3.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:49'),
(206785, 29, NULL, '41.220.42.131', 'gspe35-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206786, 29, NULL, '41.220.42.131', 'gspe35-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206787, 29, NULL, '41.220.42.131', 'api.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206788, 29, NULL, '41.220.42.131', 'app-site-association.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:29:49'),
(206789, 29, NULL, '41.220.42.131', 'api.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206790, 29, NULL, '41.220.42.131', 'p38-imap.mail.me.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:49'),
(206791, 29, NULL, '41.220.42.131', 'app-site-association.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:29:49'),
(206792, 29, NULL, '41.220.42.131', 'guzzoni.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206793, 29, NULL, '41.220.42.131', 'guzzoni.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206794, 29, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206795, 29, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206796, 29, NULL, '41.220.42.131', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:49'),
(206797, 29, NULL, '41.220.42.131', 'bag.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:49'),
(206798, 29, NULL, '41.220.42.131', 'p189-caldav.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:49'),
(206799, 29, NULL, '41.220.42.131', 'p189-caldav.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:49'),
(206800, 29, NULL, '41.220.42.131', 'gsa.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:29:49'),
(206801, 29, NULL, '41.220.42.131', 'cl1.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206802, 29, NULL, '41.220.42.131', 'iphone-ld.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206803, 29, NULL, '41.220.42.131', 'push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:49'),
(206804, 29, NULL, '41.220.42.131', 'cl3.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206805, 29, NULL, '41.220.42.131', 'configuration.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:29:49'),
(206806, 29, NULL, '41.220.42.131', 'bag-smoot.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:49'),
(206807, 29, NULL, '41.220.42.131', 'doh.dns.apple.com', NULL, 'doh_block', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206808, 29, NULL, '41.220.42.131', 'guzzoni-apple-com.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:29:49'),
(206809, 29, NULL, '41.220.42.131', 'doh.dns.apple.com', NULL, 'doh_block', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49');
INSERT INTO `dns_log` (`id`, `device_id`, `code_id`, `client_ip`, `domain`, `qtype`, `status`, `reason`, `latency_ms`, `device_type`, `bytes_transferred`, `created_at`) VALUES
(206810, 29, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:29:49'),
(206811, 29, NULL, '41.220.42.131', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:29:49'),
(206812, 29, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:49'),
(206813, 29, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:49'),
(206814, 29, NULL, '41.220.42.131', 'ocsp.digicert.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206815, 29, NULL, '41.220.42.131', 'ocsp.digicert.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206816, 29, NULL, '41.220.42.131', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:49'),
(206817, 29, NULL, '41.220.42.131', 'profile.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:49'),
(206818, 29, NULL, '41.220.42.131', 'profile.gc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:49'),
(206819, 29, NULL, '41.220.42.131', 'eip-terr-eu.cdp1.digicert.com.akahost.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 59, '2026-10-17 14:29:49'),
(206820, 29, NULL, '41.220.42.131', 'ocsp.comodoca.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206821, 29, NULL, '41.220.42.131', 'ocsp.comodoca.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:49'),
(206822, 29, NULL, '41.220.42.131', 'profile.gc.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:29:49'),
(206823, 29, NULL, '41.220.42.131', 'api2.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:51'),
(206824, 29, NULL, '41.220.42.131', 'api2.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:51'),
(206825, 29, NULL, '41.220.42.131', 'smoot-searchv2.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:29:51'),
(206826, 29, NULL, '41.220.42.131', 'lcdn-locator.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:52'),
(206827, 29, NULL, '41.220.42.131', 'lcdn-locator.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:52'),
(206828, 29, NULL, '41.220.42.131', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:52'),
(206829, 29, NULL, '41.220.42.131', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:52'),
(206830, 29, NULL, '41.220.42.131', 'profile.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:52'),
(206831, 29, NULL, '41.220.42.131', 'profile.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:52'),
(206832, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:52'),
(206833, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:52'),
(206834, 29, NULL, '41.220.42.131', 'lcdn-locator-usuqo.apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 57, '2026-10-17 14:29:52'),
(206835, 29, NULL, '41.220.42.131', 'init.ess.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:52'),
(206836, 29, NULL, '41.220.42.131', 'profile-ess.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:29:52'),
(206837, 29, NULL, '41.220.42.131', 'aidc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:52'),
(206838, 29, NULL, '41.220.42.131', 'aidc.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:52'),
(206839, 29, NULL, '41.220.42.131', 'gsas.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:52'),
(206840, 29, NULL, '41.220.42.131', 'gsas.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:52'),
(206841, 29, NULL, '41.220.42.131', 'gsa-gpk.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:52'),
(206842, 29, NULL, '41.220.42.131', 'gsa-gpk.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:52'),
(206843, 29, NULL, '41.220.42.131', 'aidc.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:52'),
(206844, 29, NULL, '41.220.42.131', 'gsas.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 48, '2026-10-17 14:29:52'),
(206845, 29, NULL, '41.220.42.131', 'apps.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:53'),
(206846, 29, NULL, '41.220.42.131', 'apps.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:53'),
(206847, 29, NULL, '41.220.42.131', 'identity.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:53'),
(206848, 29, NULL, '41.220.42.131', 'identity.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:53'),
(206849, 29, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:53'),
(206850, 29, NULL, '41.220.42.131', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:53'),
(206851, 29, NULL, '41.220.42.131', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:53'),
(206852, 29, NULL, '41.220.42.131', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:53'),
(206853, 29, NULL, '41.220.42.131', 'apps.mzstatic.com.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:29:53'),
(206854, 29, NULL, '41.220.42.131', 'identity-ess.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:29:53'),
(206855, 29, NULL, '41.220.42.131', 'xp.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 30, '2026-10-17 14:29:53'),
(206856, 29, NULL, '41.220.42.131', 'xp.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 30, '2026-10-17 14:29:53'),
(206857, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:53'),
(206858, 29, NULL, '41.220.42.131', 'xp.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:29:53'),
(206859, 29, NULL, '41.220.42.131', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:54'),
(206860, 29, NULL, '41.220.42.131', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:54'),
(206861, 29, NULL, '41.220.42.131', 'static.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:54'),
(206862, 29, NULL, '41.220.42.131', 'static.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:54'),
(206863, 29, NULL, '41.220.42.131', 'staticess.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:55'),
(206864, 29, NULL, '41.220.42.131', 'pancake.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:55'),
(206865, 29, NULL, '41.220.42.131', 'pancake.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:55'),
(206866, 29, NULL, '41.220.42.131', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:55'),
(206867, 29, NULL, '41.220.42.131', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:55'),
(206868, 29, NULL, '41.220.42.131', 'pancake.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:55'),
(206869, 29, NULL, '41.220.42.131', 'configuration-carry.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 50, '2026-10-17 14:29:55'),
(206870, 29, NULL, '41.220.42.131', 'configuration-carry.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 50, '2026-10-17 14:29:55'),
(206871, 29, NULL, '41.220.42.131', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:55'),
(206872, 29, NULL, '41.220.42.131', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:55'),
(206873, 29, NULL, '41.220.42.131', 'euc1-wps-prod.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:55'),
(206874, 29, NULL, '41.220.42.131', 'mesu.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:55'),
(206875, 29, NULL, '41.220.42.131', 'mesu.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:55'),
(206876, 29, NULL, '41.220.42.131', 'mesu.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:29:56'),
(206877, 29, NULL, '41.220.42.131', 'token.safebrowsing.apple', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:29:56'),
(206878, 29, NULL, '41.220.42.131', 'token.safebrowsing.apple', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:29:56'),
(206879, 29, NULL, '41.220.42.131', 'apple-safebrowsing.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:29:56'),
(206880, 29, NULL, '41.220.42.131', 'apple-safebrowsing.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:29:56'),
(206881, 29, NULL, '41.220.42.131', 'ssl.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206882, 29, NULL, '41.220.42.131', 'ssl.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206883, 29, NULL, '41.220.42.131', 'www.xvideos.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206884, 29, NULL, '41.220.42.131', 'www.xvideos.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206885, 29, NULL, '41.220.42.131', 'www.videoxx.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206886, 29, NULL, '41.220.42.131', 'www.videoxx.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:29:56'),
(206887, 29, NULL, '41.220.42.131', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:56'),
(206888, 29, NULL, '41.220.42.131', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:29:56'),
(206889, 29, NULL, '41.220.42.131', 'support.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:56'),
(206890, 29, NULL, '41.220.42.131', 'support.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:29:56'),
(206891, 29, NULL, '41.220.42.131', 'videoxx.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 29, '2026-10-17 14:29:56'),
(206892, 29, NULL, '41.220.42.131', 'xvideos.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 29, '2026-10-17 14:29:56'),
(206893, 29, NULL, '41.220.42.131', 'sequoia.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:56'),
(206894, 29, NULL, '41.220.42.131', 'sequoia.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:56'),
(206895, 29, NULL, '41.220.42.131', 'world-gen.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:29:56'),
(206896, 29, NULL, '41.220.42.131', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:57'),
(206897, 29, NULL, '41.220.42.131', 'init-p01md.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:29:57'),
(206898, 29, NULL, '41.220.42.131', 'p189-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:57'),
(206899, 29, NULL, '41.220.42.131', 'p189-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:29:57'),
(206900, 29, NULL, '41.220.42.131', 'a1051.dscg4.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:29:57'),
(206901, 29, NULL, '41.220.42.131', 'thumb-cdn77.xvideos-cdn.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:29:57'),
(206902, 29, NULL, '41.220.42.131', 'assets-cdn77.xvideos-cdn.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:29:57'),
(206903, 29, NULL, '41.220.42.131', 'thumb-cdn77.xvideos-cdn.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:29:57'),
(206904, 29, NULL, '41.220.42.131', 'assets-cdn77.xvideos-cdn.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:29:57'),
(206905, 29, NULL, '41.220.42.131', '1315223342.rsc.cdn77.org', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:29:57'),
(206906, 29, NULL, '41.220.42.131', '1211639301.rsc.cdn77.org', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:29:57'),
(206907, 29, NULL, '41.220.42.131', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:58'),
(206908, 29, NULL, '41.220.42.131', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:58'),
(206909, 29, NULL, '41.220.42.131', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:58'),
(206910, 29, NULL, '41.220.42.131', 'www.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:29:58'),
(206911, 29, NULL, '41.220.42.131', 'cdsassets.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:58'),
(206912, 29, NULL, '41.220.42.131', 'cdsassets.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:29:58'),
(206913, 29, NULL, '41.220.42.131', 'publicassets.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:29:58'),
(206914, 29, NULL, '41.220.42.131', 'publicassets.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:29:58'),
(206915, 29, NULL, '41.220.42.131', 'e6858.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:29:59'),
(206916, 29, NULL, '41.220.42.131', 'cdsassets-apple-com.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:29:59'),
(206917, 29, NULL, '41.220.42.131', 'publicassets.cdn-apple.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 54, '2026-10-17 14:29:59'),
(206918, 29, NULL, '41.220.42.131', 'supportmetrics.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:30:02'),
(206919, 29, NULL, '41.220.42.131', 'supportmetrics.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:30:02'),
(206920, 29, NULL, '41.220.42.131', 'supportmetrics.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:02'),
(206921, 29, NULL, '41.220.42.131', 'icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:30:05'),
(206922, 29, NULL, '41.220.42.131', 'icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:30:05'),
(206923, 29, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:05'),
(206924, 29, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:05'),
(206925, 29, NULL, '41.220.42.131', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:05'),
(206926, 29, NULL, '41.220.42.131', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:05'),
(206927, 29, NULL, '41.220.42.131', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:06'),
(206928, 29, NULL, '41.220.42.131', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:08'),
(206929, 29, NULL, '41.220.42.131', 'ckdatabasews.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:08'),
(206930, 29, NULL, '41.220.42.131', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:08'),
(206931, 29, NULL, '41.220.42.131', 'cvws.icloud-content.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:08'),
(206932, 29, NULL, '41.220.42.131', 'appleid.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:08'),
(206933, 29, NULL, '41.220.42.131', 'appleid.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:08'),
(206934, 29, NULL, '41.220.42.131', 'a642.dscd.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:30:09'),
(206935, 29, NULL, '41.220.42.131', 'cp10.cloudflare.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:09'),
(206936, 29, NULL, '41.220.42.131', 'cp10.cloudflare.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:09'),
(206937, 29, NULL, '41.220.42.131', 'h3.apis.apple.map.fastly.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:11'),
(206938, 29, NULL, '41.220.42.131', 's.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:11'),
(206939, 29, NULL, '41.220.42.131', 's.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:30:11'),
(206940, 29, NULL, '41.220.42.131', 's.mzstatic.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:30:11'),
(206941, 29, NULL, '41.220.42.131', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:11'),
(206942, 29, NULL, '41.220.42.131', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:11'),
(206943, 29, NULL, '41.220.42.131', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:30:11'),
(206944, 29, NULL, '41.220.42.131', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:30:11'),
(206945, 29, NULL, '41.220.42.131', 'amp-api-search-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:30:11'),
(206946, 29, NULL, '41.220.42.131', 'amp-api-search-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 52, '2026-10-17 14:30:11'),
(206947, 29, NULL, '41.220.42.131', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:30:11'),
(206948, 29, NULL, '41.220.42.131', 'entitlements.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 47, '2026-10-17 14:30:11'),
(206949, 29, NULL, '41.220.42.131', 'entitlements-itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:30:11'),
(206950, 29, NULL, '41.220.42.131', 'fpinit.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:12'),
(206951, 29, NULL, '41.220.42.131', 'fpinit.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:12'),
(206952, 29, NULL, '41.220.42.131', 'pd.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:12'),
(206953, 29, NULL, '41.220.42.131', 'pd.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:12'),
(206954, 29, NULL, '41.220.42.131', 'e673.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:30:12'),
(206955, 29, NULL, '41.220.42.131', 'apps.mzstatic.com.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:14'),
(206956, 29, NULL, '41.220.42.131', 'apps.mzstatic.com.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:14'),
(206957, 29, NULL, '41.220.42.131', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:16'),
(206958, 29, NULL, '41.220.42.131', 'feedbackws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:16'),
(206959, 29, NULL, '41.220.42.131', 'amp-api.media.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:16'),
(206960, 29, NULL, '41.220.42.131', 'amp-api.media.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:16'),
(206961, 29, NULL, '41.220.42.131', 'cdn-h3.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:30:17'),
(206962, 29, NULL, '41.220.42.131', 'xp.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:30:18'),
(206963, 29, NULL, '41.220.42.131', 'experiments.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:19'),
(206964, 29, NULL, '41.220.42.131', 'experiments.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:19'),
(206965, 29, NULL, '41.220.42.131', 'e3925.dscg.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:30:19'),
(206966, 29, NULL, '41.220.42.131', 'assets-mercury.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:24'),
(206967, 29, NULL, '41.220.42.131', 'assets-mercury.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:24'),
(206968, 29, NULL, '41.220.42.131', 'assets-mercury.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:24'),
(206969, 29, NULL, '41.220.42.131', 'idmsa.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:30:29'),
(206970, 29, NULL, '41.220.42.131', 'idmsa.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:30:29'),
(206971, 29, NULL, '41.220.42.131', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:30:30'),
(206972, 29, NULL, '41.220.42.131', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:30:30'),
(206973, 29, NULL, '41.220.42.131', 'cvws.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:30:31'),
(206974, 29, NULL, '41.220.42.131', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:30:31'),
(206975, 29, NULL, '41.220.42.131', 'sf-api-token-service.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 55, '2026-10-17 14:30:32'),
(206976, 29, NULL, '41.220.42.131', 'sf-api-token-service.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 55, '2026-10-17 14:30:32'),
(206977, 29, NULL, '41.220.42.131', 'query.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:32'),
(206978, 29, NULL, '41.220.42.131', 'query.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:32'),
(206979, 29, NULL, '41.220.42.131', 'sf-api-token-service.itunes.apple.com.edgekey.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 67, '2026-10-17 14:30:32'),
(206980, 29, NULL, '41.220.42.131', 'query-ess.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:32'),
(206981, 29, NULL, '41.220.42.131', 'amp-api-edge.music.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:32'),
(206982, 29, NULL, '41.220.42.131', 'amp-api-edge.music.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:32'),
(206983, 29, NULL, '41.220.42.131', 'apps.mzstatic.com.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:38'),
(206984, 29, NULL, '41.220.42.131', 'apps.mzstatic.com.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:38'),
(206985, 29, NULL, '41.220.42.131', 'idmsa.idms-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:41'),
(206986, 29, NULL, '41.220.42.131', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:42'),
(206987, 29, NULL, '41.220.42.131', 'eip-terr-eu.cdp1.digicert.com.akahost.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 59, '2026-10-17 14:30:42'),
(206988, 29, NULL, '41.220.42.131', 'a642.dscd.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:30:43'),
(206989, 29, NULL, '41.220.42.131', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:30:45'),
(206990, 29, NULL, '41.220.42.131', 'p189-docws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:46'),
(206991, 29, NULL, '41.220.42.131', 'p189-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:46'),
(206992, 29, NULL, '41.220.42.131', 'p189-docws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:46'),
(206993, 29, NULL, '41.220.42.131', 'p189-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:46'),
(206994, 29, NULL, '41.220.42.131', 'p189-keyvalueservice.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:46'),
(206995, 29, NULL, '41.220.42.131', 'p189-keyvalueservice.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 49, '2026-10-17 14:30:46'),
(206996, 29, NULL, '41.220.42.131', 'p189-mccgateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:46'),
(206997, 29, NULL, '41.220.42.131', 'p189-mccgateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:46'),
(206998, 29, NULL, '41.220.42.131', 'docws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:30:46'),
(206999, 29, NULL, '41.220.42.131', 'mccgateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:46'),
(207000, 29, NULL, '41.220.42.131', 'keyvalueservice.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:30:46'),
(207001, 29, NULL, '41.220.42.131', 'p189-contactsws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:47'),
(207002, 29, NULL, '41.220.42.131', 'p189-setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:47'),
(207003, 29, NULL, '41.220.42.131', 'p189-setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:47'),
(207004, 29, NULL, '41.220.42.131', 'p189-contactsws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:47'),
(207005, 29, NULL, '41.220.42.131', 'websocket.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:30:47'),
(207006, 29, NULL, '41.220.42.131', 'websocket.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:30:47'),
(207007, 29, NULL, '41.220.42.131', 'contactsws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:47'),
(207008, 29, NULL, '41.220.42.131', 'p189-calendarws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:48'),
(207009, 29, NULL, '41.220.42.131', 'p189-calendarws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 44, '2026-10-17 14:30:48'),
(207010, 29, NULL, '41.220.42.131', 'gatewayws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:30:48'),
(207011, 29, NULL, '41.220.42.131', 'gatewayws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:30:48'),
(207012, 29, NULL, '41.220.42.131', 'p189-mcc.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:48'),
(207013, 29, NULL, '41.220.42.131', 'p189-mcc.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 37, '2026-10-17 14:30:48'),
(207014, 29, NULL, '41.220.42.131', 'calendarws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:48'),
(207015, 29, NULL, '41.220.42.131', 'p189-remindersws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:54'),
(207016, 29, NULL, '41.220.42.131', 'p189-remindersws.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:54'),
(207017, 29, NULL, '41.220.42.131', 'remindersws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:30:56'),
(207018, 29, NULL, '41.220.42.131', 'h3.apis.apple.map.fastly.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:30:58'),
(207019, 29, NULL, '41.220.42.131', 'fpinit-itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:58'),
(207020, 29, NULL, '41.220.42.131', 'fpinit-itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:30:58'),
(207021, 29, NULL, '41.220.42.131', 'amp-api-apps-akam.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 63, '2026-10-17 14:30:59'),
(207022, 29, NULL, '41.220.42.131', 'amp-api-apps-akam.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 63, '2026-10-17 14:30:59'),
(207023, 29, NULL, '41.220.42.131', 'pancake.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:30:59'),
(207024, 29, NULL, '41.220.42.131', 'is1-ssl.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:31:00'),
(207025, 29, NULL, '41.220.42.131', 'is1-ssl.mzstatic.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:31:00'),
(207026, 29, NULL, '41.220.42.131', 'metrics.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:01'),
(207027, 29, NULL, '41.220.42.131', 'metrics.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:01'),
(207028, 28, NULL, '216.234.211.78', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:31:01'),
(207029, 28, NULL, '216.234.211.78', 'gspe1-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:31:01'),
(207030, 29, NULL, '41.220.42.131', 'emea-mask.wrr.me.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 48, '2026-10-17 14:31:01'),
(207031, 29, NULL, '41.220.42.131', 's.mzstatic.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:31:02'),
(207032, 29, NULL, '41.220.42.131', 'sync.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:31:04'),
(207033, 29, NULL, '41.220.42.131', 'sync.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:31:04'),
(207034, 29, NULL, '41.220.42.131', 'clients.l.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:31:05'),
(207035, 29, NULL, '41.220.42.131', 'eip-terr-eu.cdp1.digicert.com.akahost.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 59, '2026-10-17 14:31:06'),
(207036, 29, NULL, '41.220.42.131', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:06'),
(207037, 29, NULL, '41.220.42.131', 'sf-api-token-service.itunes.apple.com.edgekey.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 67, '2026-10-17 14:31:06'),
(207038, 29, NULL, '41.220.42.131', 'xp.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:31:06'),
(207039, 29, NULL, '41.220.42.131', 'robotoffs.click', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:38'),
(207040, 29, NULL, '41.220.42.131', 'robotoffs.click', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:38'),
(207041, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:31:42'),
(207042, 29, NULL, '41.220.42.131', 'xp.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:31:42'),
(207043, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:31:42'),
(207044, 29, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:31:43'),
(207045, 29, NULL, '41.220.42.131', 'gsa.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 31, '2026-10-17 14:31:43'),
(207046, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:31:43'),
(207047, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:31:43'),
(207048, 28, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:31:43'),
(207049, 28, NULL, '216.234.211.78', 'wps.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 31, '2026-10-17 14:31:43'),
(207050, 28, NULL, '216.234.211.78', 'euc1-wps-prod.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:31:43'),
(207051, 28, NULL, '216.234.211.78', 'mesu-cdn.apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:31:43'),
(207052, 28, NULL, '216.234.211.78', 'mesu-cdn.apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 47, '2026-10-17 14:31:43'),
(207053, 29, NULL, '41.220.42.131', 'amp-api-edge-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 65, '2026-10-17 14:31:44'),
(207054, 29, NULL, '41.220.42.131', 'amp-api-edge-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 65, '2026-10-17 14:31:44'),
(207055, 29, NULL, '41.220.42.131', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:31:44'),
(207056, 29, NULL, '41.220.42.131', 'amp-api-search-edge-apps-akam.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 75, '2026-10-17 14:31:44'),
(207057, 29, NULL, '41.220.42.131', 'amp-api.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 40, '2026-10-17 14:31:44'),
(207058, 29, NULL, '41.220.42.131', 'amp-api-search-edge-apps-akam.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 75, '2026-10-17 14:31:44'),
(207059, 28, NULL, '216.234.211.78', 'ssl.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207060, 28, NULL, '216.234.211.78', 'ssl.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207061, 28, NULL, '216.234.211.78', 'a97.gi3.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:44'),
(207062, 28, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:31:44'),
(207063, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207064, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207065, 28, NULL, '216.234.211.78', 'www.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:31:44'),
(207066, 28, NULL, '216.234.211.78', 'itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:31:44'),
(207067, 28, NULL, '216.234.211.78', 'itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:31:44'),
(207068, 28, NULL, '216.234.211.78', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207069, 28, NULL, '216.234.211.78', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:44'),
(207070, 28, NULL, '216.234.211.78', 'p197-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:31:44'),
(207071, 28, NULL, '216.234.211.78', 'p197-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:31:44'),
(207072, 28, NULL, '216.234.211.78', 'e673.dsce9.akamaiedge.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:31:44'),
(207073, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:44'),
(207074, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:44'),
(207075, 28, NULL, '216.234.211.78', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:44'),
(207076, 29, NULL, '41.220.42.131', 'push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:31:45'),
(207077, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:45'),
(207078, 28, NULL, '216.234.211.78', 'clients1.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:45'),
(207079, 28, NULL, '216.234.211.78', 'clients.l.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:31:45'),
(207080, 28, NULL, '216.234.211.78', 'api-glb-aaps1a.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 48, '2026-10-17 14:31:45'),
(207081, 28, NULL, '216.234.211.78', 'api-glb-aaps1a.smoot.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 48, '2026-10-17 14:31:45'),
(207082, 28, NULL, '216.234.211.78', 'bag-cdn.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 53, '2026-10-17 14:31:45'),
(207083, 28, NULL, '216.234.211.78', 'bag-cdn.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 53, '2026-10-17 14:31:45'),
(207084, 28, NULL, '216.234.211.78', 'robotoffs.click', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:46'),
(207085, 28, NULL, '216.234.211.78', 'robotoffs.click', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:31:46'),
(207086, 28, NULL, '216.234.211.78', 'smoot-searchv2-aaps1a.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 53, '2026-10-17 14:31:46'),
(207087, 28, NULL, '216.234.211.78', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:46'),
(207088, 28, NULL, '216.234.211.78', 'mask-api.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:31:46'),
(207089, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:46'),
(207090, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:46'),
(207091, 28, NULL, '216.234.211.78', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:47'),
(207092, 28, NULL, '216.234.211.78', 'init.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:47'),
(207093, 28, NULL, '216.234.211.78', 'init.ess.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:31:47'),
(207094, 28, NULL, '216.234.211.78', 'bag.itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:31:47'),
(207095, 29, NULL, '41.220.42.131', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:31:52'),
(207096, 28, NULL, '216.234.211.78', 'bmos.app', NULL, 'forwarded', NULL, NULL, 'iPhone', 26, '2026-10-17 14:31:59'),
(207097, 28, NULL, '216.234.211.78', 'bmos.app', NULL, 'forwarded', NULL, NULL, 'iPhone', 26, '2026-10-17 14:31:59'),
(207098, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:59'),
(207099, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:31:59'),
(207100, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:31:59'),
(207101, 28, NULL, '216.234.211.78', 'fonts.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:00'),
(207102, 28, NULL, '216.234.211.78', 'fonts.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:00'),
(207103, 28, NULL, '216.234.211.78', 'fazoffs.site', NULL, 'forwarded', NULL, NULL, 'iPhone', 30, '2026-10-17 14:32:02'),
(207104, 28, NULL, '216.234.211.78', 'fazoff.app', NULL, 'forwarded', NULL, NULL, 'iPhone', 28, '2026-10-17 14:32:02'),
(207105, 28, NULL, '216.234.211.78', 'fonts.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:02'),
(207106, 28, NULL, '216.234.211.78', 'fazoff.app', NULL, 'forwarded', NULL, NULL, 'iPhone', 28, '2026-10-17 14:32:02'),
(207107, 28, NULL, '216.234.211.78', 'fazoffs.site', NULL, 'forwarded', NULL, NULL, 'iPhone', 30, '2026-10-17 14:32:02'),
(207108, 28, NULL, '216.234.211.78', 'fonts.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:02'),
(207109, 28, NULL, '216.234.211.78', 'fazoffs.site', NULL, 'forwarded', NULL, NULL, 'iPhone', 30, '2026-10-17 14:32:02'),
(207110, 28, NULL, '216.234.211.78', 'fazoffs.site', NULL, 'forwarded', NULL, NULL, 'iPhone', 30, '2026-10-17 14:32:02'),
(207111, 28, NULL, '216.234.211.78', 'fonts.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:02'),
(207112, 28, NULL, '216.234.211.78', 'fonts.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:02'),
(207113, 28, NULL, '216.234.211.78', 'cdn.jsdelivr.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:32:04'),
(207114, 28, NULL, '216.234.211.78', 'cdnjs.cloudflare.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:04'),
(207115, 28, NULL, '216.234.211.78', 'cdnjs.cloudflare.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:04'),
(207116, 28, NULL, '216.234.211.78', 'cdn.jsdelivr.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:32:04'),
(207117, 28, NULL, '216.234.211.78', 'cdn.jsdelivr.net.cdn.cloudflare.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 53, '2026-10-17 14:32:04'),
(207118, 28, NULL, '216.234.211.78', 'translate.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:05'),
(207119, 28, NULL, '216.234.211.78', 'translate.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:05'),
(207120, 28, NULL, '216.234.211.78', '3-courier2.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:32:05'),
(207121, 28, NULL, '216.234.211.78', 'www.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:32:10'),
(207122, 28, NULL, '216.234.211.78', 'translate.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:32:10'),
(207123, 28, NULL, '216.234.211.78', 'www.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:32:10'),
(207124, 28, NULL, '216.234.211.78', 'translate.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:32:10'),
(207125, 28, NULL, '216.234.211.78', 'translate-pa.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:32:11'),
(207126, 28, NULL, '216.234.211.78', 'translate-pa.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:32:11'),
(207127, 28, NULL, '216.234.211.78', 'identity.bitwarden.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:32:15'),
(207128, 28, NULL, '216.234.211.78', 'identity.bitwarden.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:32:15'),
(207129, 28, NULL, '216.234.211.78', 'api.bitwarden.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:16'),
(207130, 28, NULL, '216.234.211.78', 'api.bitwarden.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:32:16'),
(207131, 28, NULL, '216.234.211.78', 'dualstack.n.sni.us-eu.fastly.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 50, '2026-10-17 14:32:16'),
(207132, 29, NULL, '41.220.42.131', 'setup.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:19'),
(207133, 29, NULL, '41.220.42.131', 'cvws.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:32:19'),
(207134, 29, NULL, '41.220.42.131', 'ckdatabasews.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 48, '2026-10-17 14:32:19'),
(207135, 29, NULL, '41.220.42.131', 'cvws.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:32:19'),
(207136, 29, NULL, '41.220.42.131', 'a1317.dscb.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:32:19'),
(207137, 29, NULL, '41.220.42.131', 'a1317.dscb.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:32:19'),
(207138, 29, NULL, '41.220.42.131', 'contactsws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:32:20'),
(207139, 29, NULL, '41.220.42.131', 'docws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:21'),
(207140, 29, NULL, '41.220.42.131', 'p189-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:32:22'),
(207141, 29, NULL, '41.220.42.131', 'p189-ckdatabasews.icloud.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:32:22'),
(207142, 29, NULL, '41.220.42.131', 'mccgateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:32:26'),
(207143, 29, NULL, '41.220.42.131', 'feedbackws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:32:26'),
(207144, 29, NULL, '41.220.42.131', 'provision.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:35'),
(207145, 29, NULL, '41.220.42.131', 'provision.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:35'),
(207146, 29, NULL, '41.220.42.131', 'provision.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:35'),
(207147, 28, NULL, '216.234.211.78', 'i.ibb.co', NULL, 'forwarded', NULL, NULL, 'iPhone', 26, '2026-10-17 14:32:46'),
(207148, 28, NULL, '216.234.211.78', 'i.ibb.co', NULL, 'forwarded', NULL, NULL, 'iPhone', 26, '2026-10-17 14:32:46'),
(207149, 28, NULL, '216.234.211.78', 'maps.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:32:50'),
(207150, 28, NULL, '216.234.211.78', 'maps.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:32:50'),
(207151, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:51'),
(207152, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:32:51'),
(207153, 29, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:32:56'),
(207154, 29, NULL, '41.220.42.131', 'gdmf.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:32:56'),
(207155, 29, NULL, '41.220.42.131', 'gdmf.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:32:56'),
(207156, 29, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:57'),
(207157, 29, NULL, '41.220.42.131', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:32:57'),
(207158, 28, NULL, '216.234.211.78', 'bag.itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:33:06'),
(207159, 28, NULL, '216.234.211.78', 'bag.itunes.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:33:06'),
(207160, 28, NULL, '216.234.211.78', 'gsp-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:06'),
(207161, 28, NULL, '216.234.211.78', 'gsp-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:06'),
(207162, 28, NULL, '216.234.211.78', 'fpinit.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:33:07'),
(207163, 28, NULL, '216.234.211.78', 'fpinit.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:33:07'),
(207164, 28, NULL, '216.234.211.78', 'cdn-h3.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:07'),
(207165, 28, NULL, '216.234.211.78', 'code.jquery.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:33:22'),
(207166, 28, NULL, '216.234.211.78', 'code.jquery.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:33:22'),
(207167, 28, NULL, '216.234.211.78', 'imap.mail.me.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 34, '2026-10-17 14:33:29'),
(207168, 29, NULL, '41.220.42.131', 'wps.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:33:42'),
(207169, 29, NULL, '41.220.42.131', 'wps.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:33:42'),
(207170, 28, NULL, '216.234.211.78', 'sandbox.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 42, '2026-10-17 14:33:44'),
(207171, 28, NULL, '216.234.211.78', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:33:44'),
(207172, 28, NULL, '216.234.211.78', 'sandbox.itunes.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 42, '2026-10-17 14:33:44'),
(207173, 28, NULL, '216.234.211.78', 'amp-api-edge.apps.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 45, '2026-10-17 14:33:44'),
(207174, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:33:44'),
(207175, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:33:44'),
(207176, 28, NULL, '216.234.211.78', 'a708.dsct.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:44'),
(207177, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:50'),
(207178, 28, NULL, '216.234.211.78', 'p197-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:33:50'),
(207179, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:33:54'),
(207180, 28, NULL, '216.234.211.78', 'query.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:33:57'),
(207181, 28, NULL, '216.234.211.78', 'query.ess.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:33:57'),
(207182, 28, NULL, '216.234.211.78', 'query-ess.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:33:57'),
(207183, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:33:58'),
(207184, 28, NULL, '216.234.211.78', '28-courier2.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:15'),
(207185, 29, NULL, '41.220.42.131', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:34:17'),
(207186, 29, NULL, '41.220.42.131', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:34:17'),
(207187, 29, NULL, '41.220.42.131', 'smp-device-content.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:17'),
(207188, 29, NULL, '41.220.42.131', 'smp-device-content.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:17'),
(207189, 29, NULL, '41.220.42.131', 'docws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:34:18'),
(207190, 29, NULL, '41.220.42.131', 'docws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:34:18');
INSERT INTO `dns_log` (`id`, `device_id`, `code_id`, `client_ip`, `domain`, `qtype`, `status`, `reason`, `latency_ms`, `device_type`, `bytes_transferred`, `created_at`) VALUES
(207191, 29, NULL, '41.220.42.131', 'bag-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 56, '2026-10-17 14:34:19'),
(207192, 29, NULL, '41.220.42.131', 'bag-cdn-lb.itunes-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 56, '2026-10-17 14:34:19'),
(207193, 29, NULL, '41.220.42.131', 'cdsassets-apple-com.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:34:24'),
(207194, 29, NULL, '41.220.42.131', 'cdsassets-apple-com.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:34:24'),
(207195, 29, NULL, '41.220.42.131', 'itunes.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 28, '2026-10-17 14:34:24'),
(207196, 29, NULL, '41.220.42.131', 'itunes.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 28, '2026-10-17 14:34:24'),
(207197, 29, NULL, '41.220.42.131', 's.mzstatic.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:34:24'),
(207198, 29, NULL, '41.220.42.131', 'humb.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:34:26'),
(207199, 29, NULL, '41.220.42.131', 'humb.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:34:26'),
(207200, 29, NULL, '41.220.42.131', 'feedbackws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:26'),
(207201, 29, NULL, '41.220.42.131', 'feedbackws.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:26'),
(207202, 29, NULL, '41.220.42.131', 'humb.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:34:26'),
(207203, 29, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:34:27'),
(207204, 29, NULL, '41.220.42.131', 'ocsp2.apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:34:27'),
(207205, 29, NULL, '41.220.42.131', 'ocsp2.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 37, '2026-10-17 14:34:27'),
(207206, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:34:28'),
(207207, 28, NULL, '216.234.211.78', 'mesu-cdn.origin-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 54, '2026-10-17 14:34:28'),
(207208, 28, NULL, '216.234.211.78', 'mesu-cdn.origin-apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 54, '2026-10-17 14:34:28'),
(207209, 28, NULL, '216.234.211.78', 'mesu.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 36, '2026-10-17 14:34:28'),
(207210, 29, NULL, '41.220.42.131', 'sse-ws-p189.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:34:29'),
(207211, 29, NULL, '41.220.42.131', 'sse-ws-p189.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 39, '2026-10-17 14:34:29'),
(207212, 28, NULL, '216.234.211.78', 'gspe79-ssl-96.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:29'),
(207213, 28, NULL, '216.234.211.78', 'gspe79-ssl-96.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:29'),
(207214, 29, NULL, '41.220.42.131', 'sse-ws-p189.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:34:29'),
(207215, 28, NULL, '216.234.211.78', 'gspe79-ssl-96.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:30'),
(207216, 28, NULL, '216.234.211.78', 'gspe79-ssl-96.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:30'),
(207217, 28, NULL, '216.234.211.78', 'gspe79-ssl-96.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:34:31'),
(207218, 28, NULL, '216.234.211.78', 'gsp57-ssl-locus.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:32'),
(207219, 28, NULL, '216.234.211.78', 'gsp57-ssl-locus.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:34:32'),
(207220, 29, NULL, '41.220.42.131', 'smp-device-content.g.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 50, '2026-10-17 14:34:32'),
(207221, 29, NULL, '41.220.42.131', 'wps.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:34:32'),
(207222, 29, NULL, '41.220.42.131', 'wps.v.aaplimg.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 35, '2026-10-17 14:34:32'),
(207223, 28, NULL, '216.234.211.78', 'gsp-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:34:32'),
(207224, 28, NULL, '216.234.211.78', 'gsp-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:34:32'),
(207225, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:34:52'),
(207226, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:34:52'),
(207227, 28, NULL, '216.234.211.78', 'a708.dsct.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:34:52'),
(207228, 28, NULL, '216.234.211.78', 'apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 27, '2026-10-17 14:34:52'),
(207229, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:34:52'),
(207230, 28, NULL, '216.234.211.78', 'ssl.gstatic.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 33, '2026-10-17 14:34:52'),
(207231, 28, NULL, '216.234.211.78', 'clients.l.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 38, '2026-10-17 14:34:52'),
(207232, 28, NULL, '216.234.211.78', 'sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:34:52'),
(207233, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:35:14'),
(207234, 29, NULL, '41.220.42.131', 'init.push.apple.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 37, '2026-10-17 14:35:14'),
(207235, 29, NULL, '41.220.42.131', 'push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 32, '2026-10-17 14:35:14'),
(207236, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:35:20'),
(207237, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:35:20'),
(207238, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:35:21'),
(207239, 29, NULL, '41.220.42.131', 'p189-fmip.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 38, '2026-10-17 14:35:21'),
(207240, 29, NULL, '41.220.42.131', 'lb._dns-sd._udp.0.8.168.192.in-addr.arpa', NULL, 'forwarded', NULL, NULL, 'iPhone', 58, '2026-10-17 14:35:27'),
(207241, 28, NULL, '216.234.211.78', 'sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:35:56'),
(207242, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:36:07'),
(207243, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:36:07'),
(207244, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:37:11'),
(207245, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:37:11'),
(207246, 28, NULL, '216.234.211.78', 'gspe35-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:37:12'),
(207247, 28, NULL, '216.234.211.78', 'gspe35-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:37:12'),
(207248, 28, NULL, '216.234.211.78', 'graph.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:37:12'),
(207249, 28, NULL, '216.234.211.78', 'gateway.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:37:12'),
(207250, 28, NULL, '216.234.211.78', 'www.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:37:14'),
(207251, 28, NULL, '216.234.211.78', 'www.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:37:14'),
(207252, 28, NULL, '216.234.211.78', 'star-mini.fallback.c10r.facebook.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 54, '2026-10-17 14:37:14'),
(207253, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:37:20'),
(207254, 28, NULL, '216.234.211.78', 'p197-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:37:22'),
(207255, 28, NULL, '216.234.211.78', 'p197-quota.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:37:22'),
(207256, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:37:23'),
(207257, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:37:55'),
(207258, 28, NULL, '216.234.211.78', 'meta-ohttp-relay-prod.fastly-edge.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 55, '2026-10-17 14:38:08'),
(207259, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:39:03'),
(207260, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:39:03'),
(207261, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:39:03'),
(207262, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:39:12'),
(207263, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:39:14'),
(207264, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:42:44'),
(207265, 28, NULL, '216.234.211.78', 'configuration.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:42:46'),
(207266, 28, NULL, '216.234.211.78', 'configuration.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:42:46'),
(207267, 28, NULL, '216.234.211.78', 'configuration.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:42:47'),
(207268, 28, NULL, '216.234.211.78', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:44:24'),
(207269, 28, NULL, '216.234.211.78', 'gspe79-ssl.ls.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 41, '2026-10-17 14:44:24'),
(207270, 28, NULL, '216.234.211.78', 'chat.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 39, '2026-10-17 14:44:29'),
(207271, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:44:29'),
(207272, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:44:29'),
(207273, 28, NULL, '216.234.211.78', 'mmx-ds.cdn.whatsapp.net', NULL, 'safe_override', NULL, NULL, 'iPhone', 41, '2026-10-17 14:44:29'),
(207274, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:44:34'),
(207275, 28, NULL, '216.234.211.78', '21-courier2.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:44:34'),
(207276, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:44:34'),
(207277, 28, NULL, '216.234.211.78', 'sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:44:34'),
(207278, 28, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:44:47'),
(207279, 28, NULL, '216.234.211.78', 'setup.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 34, '2026-10-17 14:44:47'),
(207280, 28, NULL, '216.234.211.78', 'serverstatus.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:44:49'),
(207281, 28, NULL, '216.234.211.78', 'serverstatus.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:44:49'),
(207282, 28, NULL, '216.234.211.78', 'serverstatus.apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:44:49'),
(207283, 28, NULL, '216.234.211.78', 'lcdn-locator.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:44:51'),
(207284, 28, NULL, '216.234.211.78', 'lcdn-locator.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:44:51'),
(207285, 28, NULL, '216.234.211.78', 'lcdn-locator-usuqo.apple.com.akadns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 57, '2026-10-17 14:44:51'),
(207286, 28, NULL, '216.234.211.78', 'www.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 32, '2026-10-17 14:44:55'),
(207287, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:55'),
(207288, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:55'),
(207289, 28, NULL, '216.234.211.78', 'netcts.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:44:55'),
(207290, 28, NULL, '216.234.211.78', 'netcts.cdn-apple.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 38, '2026-10-17 14:44:55'),
(207291, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:55'),
(207292, 28, NULL, '216.234.211.78', 'mask.icloud.com', NULL, 'always_blocked', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:55'),
(207293, 28, NULL, '216.234.211.78', 'a1744.dscw154.akamai.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:44:56'),
(207294, 28, NULL, '216.234.211.78', 'translate.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:44:57'),
(207295, 28, NULL, '216.234.211.78', 'translate.googleapis.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 42, '2026-10-17 14:44:57'),
(207296, 28, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:44:57'),
(207297, 28, NULL, '216.234.211.78', 'ogads-pa.clients6.google.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 46, '2026-10-17 14:44:57'),
(207298, 28, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:58'),
(207299, 28, NULL, '216.234.211.78', 'play.google.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 33, '2026-10-17 14:44:58'),
(207300, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:44:59'),
(207301, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:44:59'),
(207302, 28, NULL, '216.234.211.78', 'gateway.fe2.apple-dns.net', NULL, 'forwarded', NULL, NULL, 'iPhone', 43, '2026-10-17 14:45:00'),
(207303, 28, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:46:29'),
(207304, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:46:29'),
(207305, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:46:29'),
(207306, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:46:29'),
(207307, 28, NULL, '216.234.211.78', 'gateway.icloud.com', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:46:29'),
(207308, 28, NULL, '216.234.211.78', '_dns.resolver.arpa', NULL, 'safe_override', NULL, NULL, 'iPhone', 36, '2026-10-17 14:46:29'),
(207309, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:46:29'),
(207310, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:46:29'),
(207311, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:46:29'),
(207312, 28, NULL, '216.234.211.78', 'dns.google', NULL, 'safe_override', NULL, NULL, 'iPhone', 28, '2026-10-17 14:46:29'),
(207313, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:46:31'),
(207314, 28, NULL, '216.234.211.78', 'captive.apple.com', NULL, 'captive', NULL, NULL, 'iPhone', 35, '2026-10-17 14:46:31'),
(207315, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:46:31'),
(207316, 28, NULL, '216.234.211.78', 'init.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 45, '2026-10-17 14:46:31'),
(207317, 28, NULL, '216.234.211.78', '18-courier2.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 44, '2026-10-17 14:46:31'),
(207318, 28, NULL, '216.234.211.78', 'sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 40, '2026-10-17 14:46:32'),
(207319, 28, NULL, '216.234.211.78', '3-courier.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 50, '2026-10-17 14:46:33'),
(207320, 28, NULL, '216.234.211.78', '8-courier2.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:46:34'),
(207321, 28, NULL, '216.234.211.78', '8-courier2.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:46:34'),
(207322, 28, NULL, '216.234.211.78', '0-courier2.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:46:34'),
(207323, 28, NULL, '216.234.211.78', '0-courier2.sandbox.push.apple.com', NULL, 'forwarded', NULL, NULL, 'iPhone', 51, '2026-10-17 14:46:34');

-- --------------------------------------------------------

--
-- Table structure for table `ip_whitelist`
--

CREATE TABLE `ip_whitelist` (
  `id` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `safe_domains`
--

CREATE TABLE `safe_domains` (
  `id` int(11) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `safe_domains`
--

INSERT INTO `safe_domains` (`id`, `domain`, `active`) VALUES
(1, 'gateway.icloud.com', 1),
(2, 'gateway2.icloud.com', 1),
(3, 'metrics.icloud.com', 1),
(5, 'www.apple.com', 1),
(6, 'captive.apple.com', 1),
(7, 'configuration.apple.com', 1),
(8, 'gsa.apple.com', 1),
(9, 'gsas.apple.com', 1),
(10, 'xp.apple.com', 1),
(11, 'store.apple.com', 1),
(12, 'apps.apple.com', 1),
(13, 'itunes.apple.com', 1),
(14, 'ocsp.apple.com', 1),
(15, 'ocsp2.apple.com', 1),
(16, 'valid.apple.com', 1),
(17, 'account.samsung.com', 1),
(18, 'www.samsung.com', 1),
(19, 'account.xiaomi.com', 1),
(20, 'www.xiaomi.com', 1),
(21, 'accounts.google.com', 1),
(22, 'www.google.com', 1),
(23, 'play.google.com', 1),
(24, 'connectivitycheck.gstatic.com', 1),
(25, 'clients3.google.com', 1),
(26, 'dns.google', 1),
(27, 'cvws.icloud-content.com', 1),
(28, 'iphone-ld.apple.com', 1),
(29, 'ckdatabasews.icloud.com', 1),
(31, 'ipv4only.arpa', 1),
(32, '_dns.resolver.arpa', 1),
(34, 'setup.icloud.com', 1),
(36, 'icloud.com', 1),
(37, 'bag.itunes.apple.com', 1),
(38, 'mesu.apple.com', 1),
(39, 'ckdatabase.icloud.com', 1),
(40, 'keyvalueservice.icloud.com', 1),
(41, 'cl.apple.com', 1),
(42, 'cdn-apple.com', 1),
(43, 'mzstatic.com', 1),
(44, 'icloud-content.com', 1),
(45, 'apple-cloudkit.com', 1),
(46, 'feedbackws.icloud.com', 1),
(47, 'docws.icloud.com', 1),
(48, 'quota.icloud.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `description` varchar(255) DEFAULT '',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `description`, `updated_at`) VALUES
(1, 'vps_ip', '186.240.154.217', 'VPS public IP address', '2026-10-17 14:09:10'),
(2, 'site_name', 'iBlockv', 'Panel display name', '2026-05-10 05:39:05'),
(3, 'telegram_bot_token', '8864077923:AAHf6edb3sdIttRyK9LdMg5FjbsVy34WKWo', 'Telegram bot token for notifications', '2026-10-17 11:17:26'),
(4, 'telegram_chat_id', '589374157', 'Telegram chat ID for notifications', '2026-10-17 11:18:01'),
(5, 'panel_url', 'https://ivblocker.site', 'Panel web URL', '2026-10-17 11:03:46'),
(6, 'telegram_alert_unauthorized', '1', 'Alert on unauthorized IP', '2026-03-31 10:22:16'),
(7, 'telegram_alert_device', '1', 'Alert on new device connected', '2026-03-31 10:22:16'),
(8, 'telegram_alert_device_created', '1', 'Alert on device created', '2026-03-31 10:22:16'),
(9, 'telegram_alert_device_expired', '1', 'Alert on device expired', '2026-03-31 10:22:16'),
(10, 'credit_system_enabled', '1', 'Enable credit system for device creation', '2026-03-31 10:22:16'),
(11, 'free_device_for_admin', '1', 'Admin creates devices for free', '2026-03-31 10:22:16'),
(12, 'allow_standard_renew', '1', 'Allow standard users to renew with credits', '2026-03-31 10:22:16'),
(13, 'accent_color', '#10b981', 'Accent color for the template', '2026-03-31 10:22:16'),
(14, 'telegram_webhook_url', 'https://ivblocker.site/api/telegram_webhook.php', 'Telegram webhook URL (empty = polling)', '2026-10-17 11:21:57'),
(15, 'telegram_alert_template', '🚨 <b>Unauthorized IP</b>\r\n📡 IP: <code>{ip}</code>\r\n🌍 País: {country}\r\n🏙 Ciudad: {city}, {region}\r\n🏢 ISP: {isp}\r\n📱 Dispositivo: {device}\r\n🔌 Puerto: {port}\r\n🔑 Token: <code>{token}</code>\r\n⏰ {time}', 'Custom alert template (empty=default)', '2026-04-01 05:24:08'),
(16, 'panel_theme', 'oled', 'Panel color theme (dark/oled/midnight/carbon/slate/graphite/forest/rose)', '2026-10-17 13:08:37'),
(17, 'sidebar_compact', '0', 'Compact sidebar mode — icons only (0=off, 1=on)', '2026-03-31 13:51:19'),
(31, 'custom_accent_hex', '', '', '2026-04-01 05:24:09'),
(63, 'doh_public_url', 'https://dns.iblocker.dev/dns-query', '', '2026-05-10 05:39:05'),
(64, 'doh_vps_port', '443', '', '2026-05-10 05:39:05');

-- --------------------------------------------------------

--
-- Table structure for table `telegram_updates`
--

CREATE TABLE `telegram_updates` (
  `id` int(11) NOT NULL,
  `update_id` bigint(20) NOT NULL,
  `data` longtext NOT NULL,
  `processed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `traffic_flows`
--

CREATE TABLE `traffic_flows` (
  `id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  `code_id` int(11) DEFAULT NULL,
  `client_ip` varchar(45) NOT NULL,
  `domain` varchar(253) NOT NULL,
  `window_start` datetime NOT NULL,
  `window_end` datetime NOT NULL,
  `queries` int(11) NOT NULL DEFAULT 0,
  `blocked` int(11) NOT NULL DEFAULT 0,
  `bytes_in` bigint(20) NOT NULL DEFAULT 0,
  `bytes_out` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `unauthorized_attempts`
--

CREATE TABLE `unauthorized_attempts` (
  `id` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `code` varchar(6) NOT NULL DEFAULT '' COMMENT 'Device activation code attempted',
  `device_type` varchar(50) DEFAULT 'Unknown',
  `attempts` int(11) DEFAULT 1,
  `first_seen` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_seen` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','reseller','standard') NOT NULL DEFAULT 'standard',
  `credits` decimal(10,2) NOT NULL DEFAULT 0.00,
  `max_slots` int(11) NOT NULL DEFAULT 0 COMMENT '0=unlimited for admin',
  `parent_id` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL,
  `telegram_chat_id` varchar(50) DEFAULT NULL,
  `telegram_bot_token` varchar(100) DEFAULT NULL COMMENT 'If empty, uses global bot token',
  `last_login_ip` varchar(45) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `api_key` varchar(64) DEFAULT NULL COMMENT 'Dhru Fusion API key'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `credits`, `max_slots`, `parent_id`, `email`, `notes`, `active`, `created_at`, `last_login`, `telegram_chat_id`, `telegram_bot_token`, `last_login_ip`, `ip_address`, `api_key`) VALUES
(1, 'admin', '$2y$10$jPTVdTwBX4awzyJvsJ4FiOmYPNP38pFKdGG0hesLNNYLonAddJGiy', 'admin', 99999.00, 0, NULL, NULL, NULL, 1, '2026-03-31 10:22:16', '2026-04-03 14:31:22', NULL, NULL, '38.25.80.115', '216.24.219.120', '3af50bd66b21ea0ff8c01bfab8afe1090a09906a07f2c2d3'),
(3, 'admindev', '$2y$10$I0VFRbz8K4bw9PuaviGumucG3KDXF.RRYOrgxfD7YubyiM1jG.SXS', 'admin', 99999.00, 0, NULL, NULL, NULL, 1, '2026-03-31 10:22:16', '2026-04-03 14:31:22', NULL, NULL, '38.25.80.115', '216.24.219.120', '3af50bd66b21ea0ff8c01bfab8afe1090a09906a07f2c2d4'),
(10, 'Xdevers', '$2y$10$AoN0v2UFT6ly.2Pz93DvuOGUaOEc.zQGVfRYkGOLd8ek3B/PwzXWK', 'admin', 99999.00, 0, NULL, 'Xdevers@proton.me', NULL, 1, '2026-06-23 21:36:17', NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blocked_domains`
--
ALTER TABLE `blocked_domains`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `domain` (`domain`) USING BTREE,
  ADD KEY `idx_category_active` (`category`,`active`);

--
-- Indexes for table `codes`
--
ALTER TABLE `codes`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `uq_code` (`code`) USING BTREE,
  ADD KEY `idx_owner` (`owner_id`) USING BTREE,
  ADD KEY `idx_status` (`status`) USING BTREE,
  ADD KEY `idx_expires` (`expires_at`) USING BTREE;

--
-- Indexes for table `credit_history`
--
ALTER TABLE `credit_history`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_user` (`user_id`,`created_at`) USING BTREE,
  ADD KEY `idx_device` (`related_device_id`) USING BTREE;

--
-- Indexes for table `daemon_status`
--
ALTER TABLE `daemon_status`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `vps_ip` (`vps_ip`) USING BTREE;

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `uk_code` (`code`) USING BTREE,
  ADD KEY `idx_ip` (`ip`) USING BTREE,
  ADD KEY `idx_status` (`status`) USING BTREE,
  ADD KEY `idx_owner` (`owner_id`) USING BTREE,
  ADD KEY `idx_assigned` (`assigned_to`) USING BTREE,
  ADD KEY `idx_expires` (`expires_at`) USING BTREE,
  ADD KEY `idx_active_status` (`active`,`status`) USING BTREE,
  ADD KEY `idx_code_id` (`code_id`) USING BTREE;

--
-- Indexes for table `device_events`
--
ALTER TABLE `device_events`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_pending` (`processed`,`created_at`) USING BTREE;

--
-- Indexes for table `device_live_stats`
--
ALTER TABLE `device_live_stats`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `device_id` (`device_id`) USING BTREE;

--
-- Indexes for table `device_logs`
--
ALTER TABLE `device_logs`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_device_id` (`device_id`) USING BTREE,
  ADD KEY `idx_created_at` (`created_at`) USING BTREE;

--
-- Indexes for table `device_pricing`
--
ALTER TABLE `device_pricing`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `dhru_api_keys`
--
ALTER TABLE `dhru_api_keys`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `api_key` (`api_key`) USING BTREE,
  ADD KEY `idx_user` (`user_id`) USING BTREE,
  ADD KEY `idx_key` (`api_key`) USING BTREE;

--
-- Indexes for table `dhru_orders`
--
ALTER TABLE `dhru_orders`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_username` (`username`) USING BTREE,
  ADD KEY `idx_device_id` (`device_id`) USING BTREE;

--
-- Indexes for table `dns_log`
--
ALTER TABLE `dns_log`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_device_id` (`device_id`) USING BTREE,
  ADD KEY `idx_created_at` (`created_at`) USING BTREE,
  ADD KEY `idx_status` (`status`) USING BTREE,
  ADD KEY `idx_dns_log_created` (`created_at`) USING BTREE,
  ADD KEY `idx_dns_log_client_ts` (`client_ip`,`created_at`) USING BTREE,
  ADD KEY `idx_dns_log_code_id` (`code_id`) USING BTREE;

--
-- Indexes for table `ip_whitelist`
--
ALTER TABLE `ip_whitelist`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `ip` (`ip`) USING BTREE;

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_ip_time` (`ip_address`,`attempted_at`) USING BTREE;

--
-- Indexes for table `safe_domains`
--
ALTER TABLE `safe_domains`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `domain` (`domain`) USING BTREE,
  ADD KEY `idx_active` (`active`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `setting_key` (`setting_key`) USING BTREE;

--
-- Indexes for table `telegram_updates`
--
ALTER TABLE `telegram_updates`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `update_id` (`update_id`) USING BTREE,
  ADD KEY `idx_pending` (`processed`,`created_at`) USING BTREE;

--
-- Indexes for table `traffic_flows`
--
ALTER TABLE `traffic_flows`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `idx_device_window` (`device_id`,`window_start`) USING BTREE,
  ADD KEY `idx_code_window` (`code_id`,`window_start`) USING BTREE,
  ADD KEY `idx_domain_window` (`domain`,`window_start`) USING BTREE,
  ADD KEY `idx_window_start` (`window_start`) USING BTREE;

--
-- Indexes for table `unauthorized_attempts`
--
ALTER TABLE `unauthorized_attempts`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `uq_ip_code` (`ip`,`code`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `username` (`username`) USING BTREE,
  ADD UNIQUE KEY `idx_api_key` (`api_key`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blocked_domains`
--
ALTER TABLE `blocked_domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `codes`
--
ALTER TABLE `codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `credit_history`
--
ALTER TABLE `credit_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `daemon_status`
--
ALTER TABLE `daemon_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `device_events`
--
ALTER TABLE `device_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=578;

--
-- AUTO_INCREMENT for table `device_live_stats`
--
ALTER TABLE `device_live_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25198;

--
-- AUTO_INCREMENT for table `device_logs`
--
ALTER TABLE `device_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `device_pricing`
--
ALTER TABLE `device_pricing`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `dhru_api_keys`
--
ALTER TABLE `dhru_api_keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dhru_orders`
--
ALTER TABLE `dhru_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dns_log`
--
ALTER TABLE `dns_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207324;

--
-- AUTO_INCREMENT for table `ip_whitelist`
--
ALTER TABLE `ip_whitelist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `safe_domains`
--
ALTER TABLE `safe_domains`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;

--
-- AUTO_INCREMENT for table `telegram_updates`
--
ALTER TABLE `telegram_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `traffic_flows`
--
ALTER TABLE `traffic_flows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `unauthorized_attempts`
--
ALTER TABLE `unauthorized_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dhru_api_keys`
--
ALTER TABLE `dhru_api_keys`
  ADD CONSTRAINT `dhru_api_keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
