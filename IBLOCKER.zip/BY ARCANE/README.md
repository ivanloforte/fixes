# iBlockerPack — Windows VPS + Remote MySQL (cPanel) Installation Guide

This pack contains everything needed to run **iBlocker** (a DNS captive-portal
device-blocker) with a two-machine layout:

| Component | Where it runs | What it does |
|-----------|--------------|--------------|
| `iblocker.dev.zip` — PHP web panel | Shared hosting / cPanel (PHP + MySQL) | Admin panel, activation codes, device management, DNS-profile installer |
| `python.zip` — Python daemon (`daemon.py` + modules) | **Windows VPS** | DNS blocker (:53), captive portal (:80/:443), DoH server, web dashboard (:8080). Talks to the same remote MySQL as the panel |
| `lnoiduaq_db_proxy.sql` — Database dump | Imported into the **remote MySQL** (via phpMyAdmin on cPanel) | Schema + seed data (blocked domains, categories, settings, etc.) |

Both the PHP panel and the Python daemon connect to the **same MySQL database**
on cPanel. The daemon polls a `device_events` table so any change in the panel
is picked up in real time.

---

## 1. Prerequisites

### 1.1 A Windows VPS
You need a VPS running **Windows Server** with public IPv4 and full firewall
control (this pack was built for Windows Server 2019/2022; Windows 11 Pro also
works).

Recommended provider (used by the project author for testing):
<https://eniyisunucum.com/>

Minimum specs:
- 2 vCPU
- 4 GB RAM
- 20 GB disk
- 1 public static IPv4 (kept for the whole lifetime of the deployment — the
  IP is embedded in DNS profiles installed on client devices)

### 1.2 A cPanel hosting account (or any Apache + MySQL host)
- **Apache** with `mod_rewrite` (the panel ships an `.htaccess`).
- **PHP ≥ 7.4** (PHP 8.x recommended) with `pdo_mysql`.
- **MariaDB / MySQL** with **remote connections enabled**.
- A **domain** (e.g. `iblockermenu.click`) pointing at the hosting.

### 1.3 A domain for the DoH (DNS-over-HTTPS) endpoint
Apple / Google devices **only accept DoH over HTTPS with a valid TLS cert**.
Two options:
- **Best:** a real domain you own, e.g. `dns.iblockermenu.click`, with a
  Let's Encrypt cert.
- **No domain? Use sslip.io** — any `<ip-with-dashes>.sslip.io` resolves to the
  matching IP and Let's Encrypt issues certs for it. Example for VPS
  `92.60.70.240` → `92-60-70-240.sslip.io`.

---

## 2. Install Python and Node.js on the Windows VPS

Log in to the VPS with **RDP as an Administrator** and install:

1. **Python 3.11 or 3.12** — <https://www.python.org/downloads/windows/>
   During setup tick **“Add Python to PATH”** and **“Install for all users”**.
2. **Node.js LTS** — <https://nodejs.org/en/download>
   (used by some auxiliary tooling; the daemon itself is pure Python.)

Verify from a **new** PowerShell / CMD window:

```bash
python --version
pip --version
node --version
npm --version
```

---

## 3. Open the required firewall ports on the VPS

Open **CMD as Administrator** and run this single command (copy/paste as one
line). It opens every port the pack needs (DNS, HTTP/S, captive portal, web
dashboard, MySQL, RDP, etc.):

```bash
netsh advfirewall firewall add rule name="Puertos TCP" dir=in action=allow protocol=TCP localport=80,443,8080,8443,3000,5000,8000,8888,3306,5432,6379,27017,21,22,25,53,3389 & netsh advfirewall firewall add rule name="Puertos UDP" dir=in action=allow protocol=UDP localport=80,443,8080,8443,3000,5000,8000,8888,53,3389
```

Ports that the daemon actually uses:

| Port | Proto | Purpose |
|-----:|-------|---------|
| 53   | UDP/TCP | DNS blocker (upstream 8.8.8.8) |
| 80   | TCP  | Captive portal (iOS/Android CNA HTTP probe) |
| 443  | TCP  | DoH (`https://dns.<yourdomain>/dns-query`) + captive HTTPS |
| 8080 | TCP  | Web dashboard |
| 3306 | TCP  | Outbound to remote MySQL (must be open outbound; opened inbound here just in case) |

> **Also check your VPS provider's network firewall / security group.**
> The Windows firewall rule is not enough if the cloud provider blocks ports.

If your provider blocks port **25** or **53** by default (many do), open a
support ticket to have them unblocked.

---

## 4. Set up the remote MySQL database (cPanel side)

1. Log in to **cPanel → MySQL Databases**.
2. **Create** a database (e.g. `lnoiduaq_db_proxy`) and a user (e.g.
   `lnoiduaq_user_proxy`) with a strong password. Assign the user to the
   database with **ALL PRIVILEGES**.
3. Go to **cPanel → Remote MySQL** and **whitelist the VPS public IP**
   (e.g. `92.60.70.240`). Without this the daemon on the VPS cannot connect.
4. Open **phpMyAdmin** → select the new database → **Import** →
   upload `lnoiduaq_db_proxy.sql` from this pack → **Go**.
5. Verify tables were created — you should see `devices`, `codes`,
   `blocked_domains`, `settings`, `device_events`, etc.

---

## 5. Deploy the PHP web panel (cPanel side)

1. In cPanel **File Manager**, upload `iblocker.dev.zip` into
   `public_html/` (or a subdomain document root such as
   `public_html/iblocker.dev/`).
2. **Extract** it in place. Ensure the extracted files (e.g. `index.php`,
   `.htaccess`, `includes/`) live at the web root, not inside a nested
   `iblocker.dev/iblocker.dev/` folder.
3. Edit `includes/db.php` and replace the credentials with your own:

   ```php
   if (!defined('DB_HOST')) {
       define('DB_HOST', '127.0.0.1');            // localhost from cPanel's PHP
       define('DB_USER', 'YOUR_DB_USER');         // e.g. lnoiduaq_user_proxy
       define('DB_PASS', 'YOUR_DB_PASSWORD');
       define('DB_NAME', 'YOUR_DB_NAME');         // e.g. lnoiduaq_db_proxy
   }
   ```

   Also set the correct timezone if you're not in Bogotá.

4. Once the panel loads, sign in and open **Settings** → set:
   - **Site name**
   - **VPS IP** (`vps_ip` in `settings` table) → the public IP of the Windows VPS
   - **DoH public URL** (`doh_public_url`) → e.g. `https://dns.iblockermenu.click/dns-query`

5. Test the panel:
   - `https://yourdomain/login` — admin login page
   - `https://yourdomain/install?code=ABCD1234` — public DNS-profile installer

---

## 6. Deploy the Python daemon (Windows VPS side)

1. Copy `python.zip` to the VPS (RDP file transfer, or download from the
   cPanel domain).
2. Extract to a stable path, e.g. `C:\iblocker\python\`.
3. Open **PowerShell as Administrator**, `cd` into that folder and install
   Python dependencies:

   ```bash
   python -m pip install --upgrade pip
   python -m pip install rich pymysql requests cryptography
   ```

4. Edit `config.py` — **this is the only file you need to change**.

   ```python
   SITES = [
       {
           'id':        'iBlockv',
           'name':      'iBlockv',
           'panel_url': 'https://iblockermenu.click',   # ← your panel domain
           'db': {
               'host':     'REMOTE_MYSQL_HOST',         # e.g. iblockermenu.click or the cPanel MySQL host
               'user':     'YOUR_DB_USER',
               'password': 'YOUR_DB_PASSWORD',
               'database': 'YOUR_DB_NAME',
           },
       },
   ]

   SERVER_NAME = "Server 1"
   VPS_IP      = "YOUR_VPS_PUBLIC_IP"                   # e.g. 92.60.70.240

   DOH_PUBLIC_URL = "https://dns.iblockermenu.click/dns-query"
   DOH_TLS_CERT   = r"C:\certs\fullchain.pem"           # or leave None for HTTP fallback
   DOH_TLS_KEY    = r"C:\certs\privkey.pem"
   ```

   Notes:
   - `db.host` must be the **public MySQL host of the cPanel server**, and the
     VPS IP must already be whitelisted in **cPanel → Remote MySQL** (Section 4).
   - `VPS_IP` must match the value you set in the panel's **Settings** page
     (`vps_ip`) or activation codes will fail.
   - You can add more sites to `SITES = [...]`; the daemon runs them in parallel.

5. Make sure nothing else is listening on port **53** or **80** on the VPS
   (Windows sometimes has the built-in DNS Client / IIS bound to these).
   Disable IIS if present:

   ```bash
   sc stop W3SVC & sc config W3SVC start= disabled
   ```

---

## 7. Run the daemon

From the folder that contains `daemon.py`:

```bash
python daemon.py
```

You should see a colored Rich-based startup panel, the DNS blocker binding to
`:53`, the captive server binding to `:80`, and the web dashboard on `:8080`.

Useful runtime keys inside the daemon console:

| Key | Action |
|-----|--------|
| `r` | Reload all sites (re-read DB) |
| `s` | Show live stats |
| `q` | Quit |

Additional flag:

```bash
python daemon.py -d
```

Dumps the current DB state and exits — useful for troubleshooting.

---

## 8. Run the daemon as a background service (recommended)

Running under an interactive RDP session means the daemon dies when you log
off. Use **NSSM** (Non-Sucking Service Manager) to install it as a Windows
service:

1. Download NSSM from <https://nssm.cc/download> and unzip
   `nssm.exe` to `C:\Windows\System32\`.
2. From an **Administrator** shell:

   ```bash
   nssm install iBlockerDaemon "C:\Python312\python.exe" "C:\iblocker\python\daemon.py"
   nssm set    iBlockerDaemon AppDirectory "C:\iblocker\python"
   nssm set    iBlockerDaemon AppStdout    "C:\iblocker\logs\daemon.log"
   nssm set    iBlockerDaemon AppStderr    "C:\iblocker\logs\daemon.err.log"
   nssm start  iBlockerDaemon
   ```

3. Verify:

   ```bash
   sc query iBlockerDaemon
   ```

The service will restart automatically on VPS reboot.

---

## 9. Verify the end-to-end flow

1. On any phone, set the Wi-Fi DNS to the **VPS IP** manually.
2. The captive-portal detection should trigger (a browser sheet pops up with
   an activation code).
3. In the panel, create/activate a code and assign the device.
4. The daemon picks up the `device_events` row within 1 second and starts
   applying that device's block rules.
5. Or install the DNS profile directly:
   - iOS/macOS: open `https://yourdomain/install?code=ABCD1234` in Safari,
     download the `.mobileconfig`, install it under
     **Settings → General → VPN & Device Management**.
   - Android: **Settings → Network → Private DNS** → enter your DoH hostname
     (e.g. `dns.iblockermenu.click`).

---

## 10. Troubleshooting

| Symptom | Fix |
|--------|-----|
| Daemon can't reach MySQL (`OperationalError 2003 / 1045`) | VPS IP is not whitelisted in **cPanel → Remote MySQL**, or credentials in `config.py` are wrong. |
| Port `:53` fails to bind | Another DNS server is running. Disable the Windows DNS Server role and check with `netstat -ano | findstr :53`. |
| Port `:80` fails to bind | IIS or Skype is holding it. Disable IIS (see §6) or change the app that owns the port. |
| Devices don't get the captive sheet | Confirm the VPS firewall opened UDP 53 and TCP 80, and that the phone is really using the VPS IP as its DNS. |
| DoH profile installs but doesn't work | The cert/domain in `DOH_PUBLIC_URL` must exactly match a Let's Encrypt cert on the VPS. Try the sslip.io fallback from §1.3. |
| Panel shows PHP errors | `includes/db.php` sets `display_errors = 1` for debugging; turn it off in production. |

---

## 11. File map (what's in this pack)

```
iBlockerPack/
├── README.md                     ← this file
├── iblocker.dev.zip              ← PHP panel (upload to cPanel)
│   └── iblocker.dev/
│       ├── includes/db.php       ← EDIT: DB credentials
│       ├── api/                  ← JSON endpoints (used by panel + daemon)
│       ├── activate.php          ← device activation flow
│       ├── install.php           ← public DNS-profile installer
│       ├── login.php / register.php
│       └── .htaccess             ← Apache rewrites (mod_rewrite required)
├── python.zip                    ← Python daemon (extract on the Windows VPS)
│   └── python/
│       ├── daemon.py             ← ENTRY POINT: `python daemon.py`
│       ├── config.py             ← EDIT: DB creds + VPS_IP + DoH URL
│       ├── dns_blocker.py        ← UDP/TCP :53
│       ├── captive_server.py     ← HTTP/HTTPS :80/:443 captive portal
│       ├── doh_server.py         ← DoH endpoint
│       ├── web_dashboard.py      ← :8080 dashboard
│       └── ...                   ← device detection, stats, telegram alerts…
└── lnoiduaq_db_proxy.sql         ← IMPORT via phpMyAdmin on cPanel
```

---

## 12. Quick-start checklist

- [ ] VPS provisioned, RDP working, Administrator account ready
- [ ] Python + Node.js installed on the VPS
- [ ] Firewall command (§3) executed as Administrator
- [ ] MySQL database + user created on cPanel
- [ ] VPS public IP whitelisted in **cPanel → Remote MySQL**
- [ ] `lnoiduaq_db_proxy.sql` imported via phpMyAdmin
- [ ] `iblocker.dev.zip` extracted to `public_html`, `includes/db.php` edited
- [ ] Panel loads over HTTPS, admin logged in, **Settings → vps_ip** set
- [ ] `python.zip` extracted on the VPS, `pip install` succeeded
- [ ] `config.py` edited (SITES → db, VPS_IP, panel_url, DoH URL)
- [ ] `python daemon.py` runs without errors
- [ ] (Optional) NSSM service `iBlockerDaemon` installed and started
- [ ] Test device installs the DNS profile and gets blocked/allowed as expected
