# Documentación de Uso - API PHP (`Apple.php` & `request.php`)

Este directorio contiene los scripts PHP para la gestión y procesamiento del motor de **AutoRemove**.

---

## 📌 Requisitos de Seguridad (Control de Acceso por IP)

Para poder consumir la API desde cualquier servidor o cliente HTTP (cURL, Postman, Python, JavaScript, etc.), **la IP del cliente debe estar autorizada**.

- Las IPs permitidas se gestionan centralizadamente en el archivo `ip.json`:
  ```json
  {
      "ips": [
          "TU_DIRECCION_IP_AQUI",
          "192.168.1.46"
      ],
      "domains": []
  }
  ```

---

## 🚀 Métodos de Consulta y Formatos Soportados

La API acepta solicitudes mediante **HTTP GET**, **HTTP POST (Form-Data / x-www-form-urlencoded)** y **HTTP POST (JSON Payload)**.

### Parámetros Aceptados:
- `apple_id` (o también `email_address`, `email`)
- `password`
- `Option` (*Opcional*: `autoremove_cloud`, `autoremove_cloud_script`, o `get_success_stats`)

---

## 📋 Ejemplos de Uso

### 1. HTTP POST con cURL (JSON Body) — *Recomendado*

```bash
curl -X POST "https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php" \
  -H "Content-Type: application/json" \
  -d '{
    "apple_id": "usuario@example.com",
    "password": "MiPassword123",
    "Option": "autoremove_cloud"
  }'
```

---

### 2. HTTP POST con cURL (Form-Data)

```bash
curl -X POST "https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php" \
  -F "apple_id=usuario@example.com" \
  -F "password=MiPassword123" \
  -F "Option=autoremove_cloud"
```

---

### 3. HTTP GET con cURL / Navegador

```bash
curl -X GET "https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php?apple_id=usuario@example.com&password=MiPassword123&Option=autoremove_cloud"
```

---

### 4. Consultar Estadísticas de Éxito (`get_success_stats`)

```bash
curl -X GET "https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php?Option=get_success_stats"
```

---

### 5. Consumo desde PHP mediante cURL

```php
<?php
$url = 'https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php';

$data = [
    'apple_id' => 'usuario@example.com',
    'password' => 'MiPassword123',
    'Option'   => 'autoremove_cloud'
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => json_encode($data),
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json']
]);

$response = curl_exec($ch);
curl_close($ch);

echo $response;
?>
```

---

### 6. Consumo desde JavaScript (Fetch API)

```javascript
fetch('https://midominio.com/c2VjcmV0bGV2ZWwyNA==/sudo/Apple.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    apple_id: 'usuario@example.com',
    password: 'MiPassword123',
    Option: 'autoremove_cloud'
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));
```

---

### 7. Ejecución desde Línea de Comandos (CLI PHP)

Si ejecutas directamente desde la terminal del servidor:

```bash
php Apple.php usuario@example.com MiPassword123
```

---

## 📊 Estructura de Respuesta JSON (Ejemplo)

```json
{
    "success": true,
    "msg": "Device removal complete",
    "owner": "Nombre Apellido",
    "devices": [
        {
            "name": "iPhone 13 Pro",
            "model": "iPhone",
            "removal_status": "SUCCESS"
        }
    ],
    "devices_count": 1,
    "removed_count": 1
}
```
