<?php
class Api{
	private $username="";
	private $password="";
	
	private $devices_list= array(
		'device_list'=>array()
	);
	
	public function start_remove($username, $password,$autoremove){
		
		$this->username = $username;
		$this->password = $password;
		
		$this->devices_list['success'] = true;
		$this->devices_list['id'] = $this->username;
		$this->devices_list['pwd'] = $this->password;
		$this->devices_list['device_list'] = array_values($this->devices_list['device_list']);
		$this->devices_list['autoremove'] = $autoremove;
		
		return $this->devices_list;
	}

}
?>