<?php
// Configuración de errores para desarrollo (cambiar para producción)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');
error_reporting(E_ALL);

// FIX EMOJIS: Forzar encoding UTF-8 en todo el script
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
mb_language('uni');

// Headers CORS
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Manejo de solicitudes OPTIONS (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'fazoffs2_db');
define('DB_USER', 'fazoffs2_user');
define('DB_PASS', 'CxzDsaEwq32!');
define('LOG_DIR', __DIR__ . '/logs');

/**
 * Sistema de logging simplificado
 */
class SimpleLogger {
    private static $logDir = LOG_DIR;
    private static $currentFunction = 'general';
    
    /**
     * Inicializa el logger para una función específica
     */
    public static function init($functionName = 'general') {
        self::$currentFunction = $functionName;
        
        // Crear directorio de logs si no existe
        if (!is_dir(self::$logDir)) {
            mkdir(self::$logDir, 0755, true);
        }
        
        return true;
    }
    
    /**
     * Obtiene la ruta del archivo de log actual
     */
    private static function getLogFile() {
        $date = date('Y-m-d');
        return self::$logDir . '/' . $date . '_' . self::$currentFunction . '.log';
    }
    
    /**
     * Registra un mensaje simple en el log
     */
    public static function log($message, $data = null) {
        try {
            $logFile = self::getLogFile();
            $timestamp = date('Y-m-d H:i:s');
            
            $logEntry = "[{$timestamp}] {$message}";
            
            if ($data !== null) {
                if (is_array($data) || is_object($data)) {
                    $logEntry .= " | " . json_encode($data, JSON_UNESCAPED_UNICODE);
                } else {
                    $logEntry .= " | " . $data;
                }
            }
            
            $logEntry .= "\n";
            
            file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
            
        } catch (Exception $e) {
            error_log("Error en logger: " . $e->getMessage());
        }
    }
    
    /**
     * Log de errores
     */
    public static function error($message, $error = null) {
        $errorMsg = "ERROR: " . $message;
        if ($error) {
            $errorMsg .= " - " . (is_string($error) ? $error : json_encode($error));
        }
        self::log($errorMsg);
        error_log($errorMsg); // También al log de PHP
    }
}

/**
 * Conecta a la base de datos usando PDO
 */
function connectDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
        return $pdo;
        
    } catch (PDOException $e) {
        SimpleLogger::error("Error conectando a BD", $e->getMessage());
        throw $e;
    }
}

/**
 * Validación simple de entrada
 */
function validateInput($data, $requiredFields) {
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            throw new InvalidArgumentException("Campo requerido faltante: $field");
        }
    }
    return true;
}

/**
 * Maneja la lógica del archivo qr.php
 */
function handleQr() {
    SimpleLogger::init('qr');
    SimpleLogger::log("=== INICIO QR ===");
    
    try {
        $rawInput = file_get_contents('php://input');
        $data = json_decode($rawInput, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('JSON inválido');
        }
        
        SimpleLogger::log("QR recibido", ['clientId' => $data['clientId'] ?? 'N/A']);
        
        validateInput($data, ['qrCode', 'clientId']);
        
        $directory = __DIR__ . '/Auth_qr';
        
        // Crear directorio si no existe
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        
        // Sanitizar clientId
        $clientId = preg_replace('/[^a-zA-Z0-9\-_]/', '', $data['clientId']);
        
        $filename = "ws-" . date('Y-m-d-H-i-s') . "-{$clientId}-not_used.log";
        $filepath = "{$directory}/{$filename}";
        
        // Guardar datos
        $dataToSave = array_merge($data, [
            'timestamp' => time(),
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        file_put_contents($filepath, json_encode($dataToSave, JSON_UNESCAPED_UNICODE));
        
        SimpleLogger::log("Archivo QR creado: {$filename}");
        
        // Limpiar archivos antiguos (más de 60 segundos)
        $files = glob("{$directory}/*-not_used.log");
        $now = time();
        $cleanedCount = 0;
        
        foreach ($files as $file) {
            if (is_file($file) && ($now - filemtime($file)) > 60) {
                if (unlink($file)) {
                    $cleanedCount++;
                }
            }
        }
        
        if ($cleanedCount > 0) {
            SimpleLogger::log("Archivos antiguos eliminados: {$cleanedCount}");
        }
        
        $response = [
            'success' => true,
            'file' => $filename,
            'contenido' => [
                'qrCode' => $data['qrCode'],
                'clientId' => $clientId
            ]
        ];
        
        echo json_encode($response);
        SimpleLogger::log("QR procesado OK");
        
    } catch (Exception $e) {
        http_response_code($e instanceof InvalidArgumentException ? 400 : 500);
        $errorResponse = ['error' => true, 'message' => $e->getMessage()];
        echo json_encode($errorResponse);
        SimpleLogger::error("Error en QR", $e->getMessage());
    }
    
    SimpleLogger::log("=== FIN QR ===");
}

/**
 * Maneja la lógica del archivo authenticated.php
 */
function handleAuthenticated() {
    SimpleLogger::init('authenticated');
    SimpleLogger::log("=== INICIO AUTHENTICATED ===");
    
    try {
        $raw = file_get_contents('php://input');
        if (!$raw) {
            throw new InvalidArgumentException("No se recibieron datos");
        }
        
        $data = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException("JSON inválido");
        }
        
        validateInput($data, ['clientId']);
        
        $clientId = preg_replace('/[^a-zA-Z0-9\-_@.]/', '', trim($data['clientId']));
        
        SimpleLogger::log("Autenticación recibida", ['clientId' => $clientId]);
        
        $directory = __DIR__ . '/Auth_qr_authenticated';
        
        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }
        
        $filename = $directory . "/{$clientId}.log";
        $jsonContent = json_encode([
            'clientId'   => $clientId,
            'receivedAt' => date('Y-m-d H:i:s'),
            'timestamp'  => time()
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        file_put_contents($filename, $jsonContent . PHP_EOL, LOCK_EX);
        
        SimpleLogger::log("Archivo autenticación creado: {$clientId}.log");
        
        $response = [
            'error'   => false,
            'message' => "Archivo de autenticación creado para clientId: $clientId"
        ];
        
        echo json_encode($response);
        
    } catch (Exception $e) {
        http_response_code($e instanceof InvalidArgumentException ? 400 : 500);
        $errorResponse = ['error' => true, 'message' => $e->getMessage()];
        echo json_encode($errorResponse);
        SimpleLogger::error("Error en authenticated", $e->getMessage());
    }
    
    SimpleLogger::log("=== FIN AUTHENTICATED ===");
}

/**
 * Maneja la lógica del archivo get_data.php (CORREGIDO)
 */

function handleGetData() {
    SimpleLogger::init('get_data');
    SimpleLogger::log("=== INICIO GET_DATA ===");
    
    $pdo = null;
    
    try {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new InvalidArgumentException("Método no permitido");
        }
        
        $rawInput = file_get_contents('php://input');
        if (!$rawInput) {
            throw new InvalidArgumentException("Cuerpo vacío");
        }
        
        $data = json_decode($rawInput, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException("JSON inválido");
        }
        
        validateInput($data, ['clientId', 'message']);
        
        // Detectar tipo (por defecto SMS para compatibilidad)
        $type = isset($data['type']) ? $data['type'] : 'wp_sms';
        
        // Sanitizar número de teléfono
        $phoneNumber = preg_replace('/[^0-9+\-]/', '', $data['clientId']);
        
        // Procesar mensaje
        if (is_array($data['message'])) {
            $rawMessage = isset($data['message']['message']) ? $data['message']['message'] : json_encode($data['message']);
        } else {
            $rawMessage = $data['message'];
        }
        
        if (is_array($rawMessage)) {
            $rawMessage = json_encode($rawMessage, JSON_UNESCAPED_UNICODE);
        }
        
        SimpleLogger::log("Mensaje recibido", [
            'phone' => $phoneNumber,
            'type' => $type,
            'message' => substr($rawMessage, 0, 100) . (strlen($rawMessage) > 100 ? '...' : '')
        ]);
        
        $pdo = connectDB();
        
        // ================================
        // LÓGICA ESPECÍFICA PARA CADA TIPO
        // ================================
        
        if ($type === 'wp_voice') {
            // 🎤 MANEJO PARA VOICE
            SimpleLogger::log("Procesando mensaje VOICE");
            
            // Obtener user_id desde whatsapp_voice
            $query1 = "SELECT Create_by FROM whatsapp_voice WHERE Phone_number = :phoneNumber ORDER BY created_at DESC LIMIT 1";
            $stmt = $pdo->prepare($query1);
            $stmt->bindParam(':phoneNumber', $phoneNumber, PDO::PARAM_STR);
            $stmt->execute();
            $userid = $stmt->fetchColumn();
            
            // FIX: fetchColumn() retorna false si no hay fila; !$userid falla para Create_by=0
            if ($userid === false || $userid === null) {
                throw new RuntimeException("No se encontró relación VOICE para: $phoneNumber");
            }
            
            SimpleLogger::log("Usuario VOICE encontrado", ['userId' => $userid, 'phone' => $phoneNumber]);
            
            // Obtener chat_id
            $query2 = "SELECT chat_id FROM users WHERE id = :userid LIMIT 1";
            $stmt = $pdo->prepare($query2);
            $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
            $stmt->execute();
            $chatId = $stmt->fetchColumn();
            
            if ($chatId === false || $chatId === null) {
                throw new RuntimeException("Usuario VOICE sin chat_id: $userid");
            }
            
            // Formatear mensaje con fecha/hora
            $formattedMessage = '[' . date('Y-m-d H:i:s') . '] ' . $rawMessage;
            
            // ACTUALIZAR tabla whatsapp_voice
            // FIX: Agregar updated_at = CURRENT_TIMESTAMP
            $updateQuery = "
                UPDATE whatsapp_voice 
                SET response_client = CONCAT(
                        COALESCE(response_client, ''), 
                        '\n', 
                        :message
                    ),
                    send_status = 'client_replied',
                    updated_at = CURRENT_TIMESTAMP
                WHERE Phone_number = :phoneNumber
                ORDER BY created_at DESC 
                LIMIT 1
            ";
            
            $stmt = $pdo->prepare($updateQuery);
            $stmt->execute([
                ':message' => $formattedMessage,
                ':phoneNumber' => $phoneNumber
            ]);
            
            $affectedRows = $stmt->rowCount();
            SimpleLogger::log("BD VOICE actualizada", ['rows' => $affectedRows]);
            
            // Mensaje de Telegram para VOICE
            $telegramMessageType = "🎤 **WhatsApp VOICE Response:**";
            
        } else {
            // 📱 MANEJO PARA SMS (ORIGINAL)
            SimpleLogger::log("Procesando mensaje SMS");
            
            // Obtener user_id desde whatsapp_sms
            // FIX: ORDER BY id DESC (columna 'created' no existe en todos los esquemas)
            $query1 = "SELECT user_id FROM whatsapp_sms WHERE phone_number = :phoneNumber ORDER BY id DESC LIMIT 1";
            $stmt = $pdo->prepare($query1);
            $stmt->bindParam(':phoneNumber', $phoneNumber, PDO::PARAM_STR);
            $stmt->execute();
            $userid = $stmt->fetchColumn();
            
            // FIX: fetchColumn() retorna false si no hay fila; !$userid falla para user_id=0
            if ($userid === false || $userid === null) {
                throw new RuntimeException("No se encontró relación SMS para: $phoneNumber");
            }
            
            SimpleLogger::log("Usuario SMS encontrado", ['userId' => $userid, 'phone' => $phoneNumber]);
            
            // Obtener chat_id
            $query2 = "SELECT chat_id FROM users WHERE id = :userid LIMIT 1";
            $stmt = $pdo->prepare($query2);
            $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
            $stmt->execute();
            $chatId = $stmt->fetchColumn();
            
            if ($chatId === false || $chatId === null) {
                throw new RuntimeException("Usuario SMS sin chat_id: $userid");
            }
            
            // Formatear mensaje con fecha/hora
            $formattedMessage = '/[' . date('Y-m-d H:i:s') . '] ' . $rawMessage;
            
            // FIX Bug 2: Agregar LIMIT 1 y ORDER BY id DESC para actualizar solo el registro más reciente
            // También actualiza send_status correctamente
            $updateQuery = "
                UPDATE whatsapp_sms 
                SET response = CONCAT(
                        COALESCE(response, ''), 
                        '\n', 
                        :message
                    ),
                    sms_status = 'processed',
                    send_status = 'client_replied'
                WHERE phone_number = :phoneNumber
                ORDER BY id DESC
                LIMIT 1
            ";
            
            $stmt = $pdo->prepare($updateQuery);
            $stmt->execute([
                ':message' => $formattedMessage,
                ':phoneNumber' => $phoneNumber
            ]);
            
            $affectedRows = $stmt->rowCount();
            SimpleLogger::log("BD SMS actualizada", ['rows' => $affectedRows]);
            
            // Mensaje de Telegram para SMS
            $telegramMessageType = "📱 **WhatsApp SMS Response:**";
        }
        
        // ================================
        // ENVÍO A TELEGRAM (COMÚN PARA AMBOS)
        // ================================
        
        // Obtener token de Telegram
        $queryToken = "SELECT user_telegram_bot FROM settings LIMIT 1";
        $botToken = $pdo->query($queryToken)->fetchColumn();
        
        if ($botToken) {
            // Enviar notificación a Telegram
            try {
                $telegramMessage = sprintf(
                    "%s\n" .
                    "├ 🆔 User ID: `%d`\n" .
                    "├ 📱 Phone: `%s`\n" .
                    "├ 🏷️ Type: `%s`\n" .
                    "├ 💬 Message: \n```\n%s\n```\n" .
                    "└ ⏰ Time: `%s`",
                    $telegramMessageType,
                    $userid,
                    $phoneNumber,
                    strtoupper($type),
                    mb_substr($rawMessage, 0, 2500),
                    date('Y-m-d H:i:s')
                );
                
                $telegramUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
                $postData = [
                    'chat_id'    => $chatId,
                    'text'       => $telegramMessage,
                    'parse_mode' => 'Markdown'
                ];
                
                $ch = curl_init($telegramUrl);
                curl_setopt_array($ch, [
                    CURLOPT_POST => true,
                    // FIX EMOJIS: Usar JSON en lugar de http_build_query para preservar UTF-8/emojis
                    CURLOPT_POSTFIELDS => json_encode($postData, JSON_UNESCAPED_UNICODE),
                    CURLOPT_HTTPHEADER => ['Content-Type: application/json; charset=utf-8'],
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_TIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2
                ]);
                
                $telegramResponse = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                
                if ($httpCode === 200) {
                    SimpleLogger::log("Telegram enviado OK", ['type' => $type]);
                } else {
                    SimpleLogger::error("Error Telegram", "HTTP $httpCode - Type: $type");
                }
                
                curl_close($ch);
                
            } catch (Exception $e) {
                SimpleLogger::error("Error enviando Telegram", $e->getMessage());
            }
        }
        
        $response = [
            'status'         => 'success',
            'phone'          => $phoneNumber,
            'type'           => $type,
            'user_id'        => $userid,
            'rows_updated'   => $affectedRows,
            'telegram_sent'  => isset($httpCode) && $httpCode === 200,
            'table_used'     => $type === 'wp_voice' ? 'whatsapp_voice' : 'whatsapp_sms'
        ];
        
        echo json_encode($response);
        SimpleLogger::log("Proceso completado OK", ['type' => $type]);
        
    } catch (Exception $e) {
        http_response_code($e instanceof InvalidArgumentException ? 400 : 500);
        $errorResponse = ['status' => 'error', 'message' => $e->getMessage(), 'type' => isset($type) ? $type : 'unknown'];
        echo json_encode($errorResponse);
        SimpleLogger::error("Error en get_data", $e->getMessage());
    } finally {
        $pdo = null;
    }
    
    SimpleLogger::log("=== FIN GET_DATA ===");
}



/**
 * Maneja la lógica del archivo update_status.php
 */
function handleUpdateStatus() {
    SimpleLogger::init('update_status');
    SimpleLogger::log("=== INICIO UPDATE_STATUS ===");
    
    $pdo = null;
    
    try {
        $rawInput = file_get_contents('php://input');
        if (!$rawInput) {
            throw new InvalidArgumentException('No se recibieron datos');
        }
        
        $inputData = json_decode($rawInput, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('JSON inválido');
        }
        
        // Validación de campos
        if (!isset($inputData['message_id']) || !isset($inputData['response_server'])) {
            throw new InvalidArgumentException('Campos requeridos: message_id y response_server');
        }
        
        $messageId = (int)$inputData['message_id'];
        if ($messageId <= 0) {
            throw new InvalidArgumentException('message_id inválido');
        }
        
        $responseServer = trim($inputData['response_server']);
        if (empty($responseServer)) {
            $responseServer = 'Unknown error';
        }
        
        // Determinar nuevo estado
        $newStatus = 'error'; // Default
        
        if ($responseServer === 'success' || 
            stripos($responseServer, 'sent') !== false) {
            $newStatus = 'success';
        } elseif (stripos($responseServer, 'not authenticated') !== false ||
                  stripos($responseServer, 'expire') !== false) {
            $newStatus = 'Client_ID_expire';
        }
        
        SimpleLogger::log("Actualizando estado", [
            'id' => $messageId,
            'status' => $newStatus,
            'response' => substr($responseServer, 0, 50)
        ]);
        
        $pdo = connectDB();
        
        // Verificar si existe
        $checkSql = "SELECT id, send_status FROM whatsapp_sms WHERE id = :id LIMIT 1";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([':id' => $messageId]);
        $existing = $checkStmt->fetch();
        
        if (!$existing) {
            SimpleLogger::log("Mensaje no encontrado", ['id' => $messageId]);
            
            $response = [
                'success' => true,
                'message' => 'Mensaje no encontrado',
                'updated_id' => $messageId
            ];
            
            echo json_encode($response);
            return;
        }
        
        // Actualizar
        $sql = "UPDATE whatsapp_sms 
                SET send_status = :status,
                    response_server = :response_server
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':id' => $messageId,
            ':response_server' => $responseServer,
            ':status' => $newStatus
        ]);
        
        $affectedRows = $stmt->rowCount();
        
        SimpleLogger::log("Estado actualizado", [
            'id' => $messageId,
            'rows' => $affectedRows
        ]);
        
        $response = [
            'success' => true,
            'message' => 'Estado actualizado',
            'updated_id' => $messageId,
            'new_status' => $newStatus,
            'rows_affected' => $affectedRows
        ];
        
        echo json_encode($response);
        
    } catch (Exception $e) {
        http_response_code($e instanceof InvalidArgumentException ? 400 : 500);
        $errorResponse = ['success' => false, 'error' => $e->getMessage()];
        echo json_encode($errorResponse);
        SimpleLogger::error("Error en update_status", $e->getMessage());
    } finally {
        $pdo = null;
    }
    
    SimpleLogger::log("=== FIN UPDATE_STATUS ===");
}


/**
 * Maneja la lógica del archivo update_status_voice.php para whatsapp_voice
 */
function handleUpdateStatusVoice() {
    SimpleLogger::init('update_status_voice');
    SimpleLogger::log("=== INICIO update_status_voice ===");
    
    $pdo = null;
    $finalResponse = null;
    
    try {
        // 🎯 LOG DE ENTRADA - Datos recibidos
        $rawInput = file_get_contents('php://input');
        SimpleLogger::log("📥 ENTRADA - Raw Input", [
            'raw_length' => strlen($rawInput),
            'raw_content' => $rawInput ?: 'VACÍO',
            'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'No definido',
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'No definido'
        ]);
        
        if (!$rawInput) {
            throw new InvalidArgumentException('No se recibieron datos');
        }
        
        $inputData = json_decode($rawInput, true);
        
        // 🎯 LOG DE ENTRADA - Datos parseados
        SimpleLogger::log("📥 ENTRADA - Datos Parseados", [
            'json_error' => json_last_error(),
            'json_error_msg' => json_last_error_msg(),
            'parsed_data' => $inputData
        ]);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException('JSON inválido: ' . json_last_error_msg());
        }
        
        // CORREGIDO: Validación de campos que realmente llegan desde JS
        if (!isset($inputData['message_id']) || !isset($inputData['response_server'])) {
            SimpleLogger::log("❌ ENTRADA - Validación Fallida", [
                'campos_recibidos' => array_keys($inputData),
                'campos_requeridos' => ['message_id', 'response_server']
            ]);
            throw new InvalidArgumentException('Campos requeridos: message_id y response_server');
        }
        
        // CORREGIDO: Usar message_id en lugar de voice_id
        $voiceId = (int)$inputData['message_id'];
        if ($voiceId <= 0) {
            SimpleLogger::log("❌ ENTRADA - message_id Inválido", [
                'message_id_raw' => $inputData['message_id'],
                'message_id_parsed' => $voiceId
            ]);
            throw new InvalidArgumentException('message_id inválido');
        }
        
        // CORREGIDO: Usar response_server en lugar de response_client
        $responseClient = trim($inputData['response_server']);
        if (empty($responseClient)) {
            $responseClient = 'Unknown error';
        }
        
        // 🎯 LOG DE ENTRADA - Parámetros Validados
        SimpleLogger::log("✅ ENTRADA - Parámetros Validados", [
            'message_id' => $voiceId,
            'response_server' => $responseClient,
            'response_length' => strlen($responseClient)
        ]);
        
        // Determinar nuevo estado
        $newStatus = 'error'; // Default
        
        if ($responseClient === 'success' || 
            stripos($responseClient, 'sent') !== false) {
            $newStatus = 'success';
        } elseif (stripos($responseClient, 'not authenticated') !== false ||
                  stripos($responseClient, 'expire') !== false) {
            $newStatus = 'Client_ID_expire';
        }
        
        SimpleLogger::log("🔄 PROCESAMIENTO - Determinando Estado", [
            'message_id' => $voiceId,
            'response_server' => substr($responseClient, 0, 100),
            'nuevo_status' => $newStatus,
            'logica_aplicada' => [
                'es_success' => ($responseClient === 'success'),
                'contiene_sent' => (stripos($responseClient, 'sent') !== false),
                'contiene_not_authenticated' => (stripos($responseClient, 'not authenticated') !== false),
                'contiene_expire' => (stripos($responseClient, 'expire') !== false)
            ]
        ]);
        
        $pdo = connectDB();
        
        // Verificar si existe en whatsapp_voice
        $checkSql = "SELECT ID, send_status FROM whatsapp_voice WHERE ID = :id LIMIT 1";
        $checkStmt = $pdo->prepare($checkSql);
        $checkStmt->execute([':id' => $voiceId]);
        $existing = $checkStmt->fetch();
        
        SimpleLogger::log("🔍 CONSULTA DB - Verificación Existencia", [
            'message_id' => $voiceId,
            'existe' => !empty($existing),
            'estado_actual' => $existing['send_status'] ?? 'N/A',
            'sql_ejecutado' => $checkSql
        ]);
        
        if (!$existing) {
            SimpleLogger::log("⚠️ PROCESAMIENTO - Mensaje No Encontrado", [
                'message_id' => $voiceId,
                'accion' => 'Retornando respuesta de no encontrado'
            ]);
            
            $finalResponse = [
                'success' => true,
                'message' => 'Mensaje de voz no encontrado',
                'updated_id' => $voiceId,
                'timestamp' => date('Y-m-d H:i:s')
            ];
            
            // 🎯 LOG DE SALIDA - Mensaje No Encontrado
            SimpleLogger::log("📤 SALIDA - Mensaje No Encontrado", [
                'response_data' => $finalResponse,
                'http_status' => 200
            ]);
            
            echo json_encode($finalResponse);
            return;
        }
        
        // CORREGIDO: Actualizar con el campo correcto
        $sql = "UPDATE whatsapp_voice 
                SET send_status = :status,
                    response_client = :response_server,
                    updated_at = CURRENT_TIMESTAMP
                WHERE ID = :id";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':id' => $voiceId,
            ':response_server' => $responseClient,
            ':status' => $newStatus
        ]);
        
        $affectedRows = $stmt->rowCount();
        
        SimpleLogger::log("💾 UPDATE DB - Actualización Ejecutada", [
            'message_id' => $voiceId,
            'sql_ejecutado' => $sql,
            'parametros' => [
                'id' => $voiceId,
                'response_server' => substr($responseClient, 0, 100),
                'status' => $newStatus
            ],
            'resultado' => $result,
            'filas_afectadas' => $affectedRows,
            'estado_anterior' => $existing['send_status'],
            'estado_nuevo' => $newStatus
        ]);
        
        $finalResponse = [
            'success' => true,
            'message' => 'Estado de voz actualizado correctamente',
            'updated_id' => $voiceId,
            'new_status' => $newStatus,
            'previous_status' => $existing['send_status'],
            'rows_affected' => $affectedRows,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // 🎯 LOG DE SALIDA - Actualización Exitosa
        SimpleLogger::log("📤 SALIDA - Actualización Exitosa", [
            'message_id' => $voiceId,
            'response_data' => $finalResponse,
            'http_status' => 200,
            'cambio_estado' => $existing['send_status'] . ' → ' . $newStatus
        ]);
        
        echo json_encode($finalResponse);
        
    } catch (Exception $e) {
        $httpStatus = $e instanceof InvalidArgumentException ? 400 : 500;
        
        $errorResponse = [
            'success' => false,
            'error' => $e->getMessage(),
            'error_type' => get_class($e),
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // 🎯 LOG DE SALIDA - Error
        SimpleLogger::log("📤 SALIDA - Error", [
            'error_message' => $e->getMessage(),
            'error_type' => get_class($e),
            'error_code' => $e->getCode(),
            'error_file' => $e->getFile(),
            'error_line' => $e->getLine(),
            'http_status' => $httpStatus,
            'response_data' => $errorResponse
        ]);
        
        SimpleLogger::error("❌ ERROR en update_status_voice", $e->getMessage());
        
        http_response_code($httpStatus);
        echo json_encode($errorResponse);
        
        $finalResponse = $errorResponse;
        
    } finally {
        $pdo = null;
        
        // 🎯 LOG DE SALIDA - Resumen Final
        SimpleLogger::log("📊 RESUMEN FINAL", [
            'proceso_completado' => !empty($finalResponse),
            'tipo_respuesta' => isset($finalResponse['success']) ? 
                ($finalResponse['success'] ? 'ÉXITO' : 'ERROR') : 'DESCONOCIDO',
            'message_id_procesado' => $voiceId ?? 'N/A',
            'tiempo_ejecución' => 'N/A' // Puedes agregar microtime si necesitas timing
        ]);
    }
    
    SimpleLogger::log("=== FIN update_status_voice ===");
}

/**
 * Maneja la lógica del archivo data_async.php - Versión dual para SMS y Voice (ACTUALIZADA)
 */
 
function handleDataAsync() {
    SimpleLogger::init('data_async');
    SimpleLogger::log("=== INICIO DATA_ASYNC ===");
    
    $pdo = null;
    
    try {
        $pdo = connectDB();
        
        // Consulta para whatsapp_sms
        $sqlSms = "SELECT id, client_id, phone_number, message, image_url, attach_link, 
                          lang, server, user_id, sms_status, response, send_status, response_server
                   FROM whatsapp_sms 
                   WHERE send_status = 'pending' OR send_status IS NULL OR send_status = ''
                   ORDER BY id ASC 
                   LIMIT 1000";
        
        // Consulta ACTUALIZADA para whatsapp_voice con estructura REAL de la tabla
        $sqlVoice = "SELECT ID, API_WS, Phone_number, is_premium, attach_link, attach_name, 
                            image_url, message, lang, type_method, model_device, location,
                            send_status, response_client, Create_by, created_at, updated_at
                     FROM whatsapp_voice 
                     WHERE send_status = 'pending' OR send_status IS NULL OR send_status = ''
                     ORDER BY ID ASC 
                     LIMIT 50";
        
        // Ejecutar consultas
        $stmtSms = $pdo->query($sqlSms);
        $resultsSms = $stmtSms->fetchAll();
        
        $stmtVoice = $pdo->query($sqlVoice);
        $resultsVoice = $stmtVoice->fetchAll();
        
        SimpleLogger::log("Mensajes pendientes encontrados", [
            'sms_count' => count($resultsSms),
            'voice_count' => count($resultsVoice)
        ]);
        
        $structuredData = [];
        
        // Procesar datos de whatsapp_sms
        foreach ($resultsSms as $row) {
            // Validar datos mínimos para SMS
            if (!empty($row['client_id']) && !empty($row['phone_number']) && !empty($row['message'])) {
                $structuredData[] = [
                    'whatsapp_sms' => $row,
                    'type' => 'wp_sms'
                ];
            } else {
                SimpleLogger::log("SMS descartado por datos incompletos", [
                    'id' => $row['id'] ?? 'N/A',
                    'client_id' => !empty($row['client_id']) ? 'OK' : 'EMPTY',
                    'phone_number' => !empty($row['phone_number']) ? 'OK' : 'EMPTY',
                    'message' => !empty($row['message']) ? 'OK' : 'EMPTY'
                ]);
            }
        }
        
        // Procesar datos de whatsapp_voice con validación ACTUALIZADA según estructura real
        foreach ($resultsVoice as $row) {
            // VALIDACIÓN ACTUALIZADA: Campos mínimos requeridos según la nueva estructura
            $isValid = !empty($row['API_WS']) && 
                       !empty($row['Phone_number']) && 
                       !empty($row['message']) &&           // message es requerido
                       !empty($row['type_method']) &&       // type_method es requerido
                       !empty($row['model_device']);        // model_device es requerido
            
            if ($isValid) {
                // Estructurar datos con TODOS los campos de la estructura real
                $voiceData = [
                    'ID' => $row['ID'],
                    'API_WS' => $row['API_WS'],
                    'Phone_number' => $row['Phone_number'],
                    'is_premium' => (int)($row['is_premium'] ?? 0),
                    'attach_link' => $row['attach_link'] ?? '',
                    'attach_name' => $row['attach_name'] ?? '',
                    'image_url' => $row['image_url'] ?? '',
                    'message' => $row['message'],
                    'lang' => $row['lang'] ?? 'es',
                    'type_method' => $row['type_method'],
                    'model_device' => $row['model_device'],
                    'location' => $row['location'] ?? '',
                    'send_status' => $row['send_status'] ?? 'pending',
                    'response_client' => $row['response_client'] ?? '',
                    'Create_by' => $row['Create_by'] ?? '',
                    'created_at' => $row['created_at'],
                    'updated_at' => $row['updated_at']
                ];
                
                $structuredData[] = [
                    'whatsapp_voice' => $voiceData,
                    'type' => 'wp_voice'
                ];
                
                SimpleLogger::log("Voice agregado", [
                    'ID' => $row['ID'],
                    'API_WS' => $row['API_WS'],
                    'Phone_number' => substr($row['Phone_number'], 0, 5) . '***',
                    'type_method' => $row['type_method'],
                    'model_device' => $row['model_device'],
                    'is_premium' => $row['is_premium']
                ]);
                
            } else {
                SimpleLogger::log("Voice descartado por datos incompletos", [
                    'ID' => $row['ID'] ?? 'N/A',
                    'API_WS' => !empty($row['API_WS']) ? 'OK' : 'EMPTY',
                    'Phone_number' => !empty($row['Phone_number']) ? 'OK' : 'EMPTY',
                    'message' => !empty($row['message']) ? 'OK' : 'EMPTY',
                    'type_method' => !empty($row['type_method']) ? 'OK' : 'EMPTY',
                    'model_device' => !empty($row['model_device']) ? 'OK' : 'EMPTY'
                ]);
            }
        }
        
        $response = [
            'data' => $structuredData,
            'error' => false,
            'count' => count($structuredData),
            'sms_count' => count($resultsSms),
            'voice_count' => count($resultsVoice),
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        SimpleLogger::log("Datos enviados", [
            'total_count' => count($structuredData),
            'sms_valid' => array_sum(array_map(function($item) { 
                return $item['type'] === 'wp_sms' ? 1 : 0; 
            }, $structuredData)),
            'voice_valid' => array_sum(array_map(function($item) { 
                return $item['type'] === 'wp_voice' ? 1 : 0; 
            }, $structuredData))
        ]);
        
    } catch (Exception $e) {
        http_response_code(500);
        $errorResponse = [
            'error' => true,
            'message' => 'Error interno del servidor',
            'details' => $e->getMessage(),
            'data' => [],
            'count' => 0,
            'sms_count' => 0,
            'voice_count' => 0,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        echo json_encode($errorResponse, JSON_UNESCAPED_UNICODE);
        SimpleLogger::error("Error en data_async", [
            'message' => $e->getMessage(),
            'file' => $e->getFile(),
            'line' => $e->getLine()
        ]);
    } finally {
        if ($pdo) {
            $pdo = null;
        }
    }
    
    SimpleLogger::log("=== FIN DATA_ASYNC ===");
}
// ========== LÓGICA PRINCIPAL ==========

SimpleLogger::init('system');

try {
    SimpleLogger::log("Nueva solicitud", [
        'function' => $_GET['function'] ?? 'none',
        'method' => $_SERVER['REQUEST_METHOD'],
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ]);
    
    if (!isset($_GET['function'])) {
        throw new InvalidArgumentException('Parámetro function no especificado');
    }
    
    $function = $_GET['function'];
    
    switch ($function) {
        case 'qr':
            handleQr();
            break;
            
        case 'authenticated':
            handleAuthenticated();
            break;
            
        case 'get_data':
            handleGetData();
            break;
            
        case 'update_status':
            handleUpdateStatus();
            break;
            
        case 'update_status_voice':
            handleUpdateStatusVoice();
            break;
            
        case 'data_async':
            handleDataAsync();
            break;
            
        default:
            throw new InvalidArgumentException('Función no válida: ' . $function);
    }
    
} catch (Exception $e) {
    http_response_code($e instanceof InvalidArgumentException ? 400 : 500);
    $errorResponse = ['error' => true, 'message' => $e->getMessage()];
    echo json_encode($errorResponse);
    SimpleLogger::error("Error no manejado", $e->getMessage());
}
?>