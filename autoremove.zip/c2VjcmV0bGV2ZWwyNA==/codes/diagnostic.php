<?php
/**
 * Script de diagnóstico para verificar la integración WhatsApp Bot
 */

// Configuración
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'fazoffs2_db');
define('DB_USER', 'fazoffs2_user');
define('DB_PASS', 'CxzDsaEwq32!');

$diagnostics = [];

// 1. Verificar conexión a BD
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $diagnostics['database_connection'] = ['status' => 'OK', 'message' => 'Conexión exitosa'];
} catch (Exception $e) {
    $diagnostics['database_connection'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
    die(json_encode($diagnostics, JSON_PRETTY_PRINT));
}

// 2. Verificar estructura de tabla whatsapp_sms
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM whatsapp_sms");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $requiredColumns = ['id', 'client_id', 'phone_number', 'message', 'send_status', 'response_server'];
    $missingColumns = array_diff($requiredColumns, $columns);
    
    if (empty($missingColumns)) {
        $diagnostics['table_structure'] = [
            'status' => 'OK', 
            'message' => 'Todas las columnas requeridas existen',
            'columns' => $columns
        ];
    } else {
        $diagnostics['table_structure'] = [
            'status' => 'WARNING', 
            'message' => 'Faltan columnas requeridas',
            'missing' => $missingColumns,
            'existing' => $columns
        ];
        
        // Intentar agregar columnas faltantes
        foreach ($missingColumns as $column) {
            try {
                if ($column === 'send_status') {
                    $pdo->exec("ALTER TABLE whatsapp_sms ADD COLUMN send_status VARCHAR(50) DEFAULT 'pending'");
                    $diagnostics['table_structure']['added'][] = 'send_status';
                } elseif ($column === 'response_server') {
                    $pdo->exec("ALTER TABLE whatsapp_sms ADD COLUMN response_server TEXT");
                    $diagnostics['table_structure']['added'][] = 'response_server';
                }
            } catch (Exception $e) {
                $diagnostics['table_structure']['add_error'][$column] = $e->getMessage();
            }
        }
    }
} catch (Exception $e) {
    $diagnostics['table_structure'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
}

// 3. Verificar permisos de archivo
$directories = [
    'app.log' => __DIR__ . '/app.log',
    'Auth_qr' => __DIR__ . '/Auth_qr',
    'Auth_qr_authenticated' => __DIR__ . '/Auth_qr_authenticated'
];

foreach ($directories as $name => $path) {
    if (is_dir($path)) {
        $diagnostics['permissions'][$name] = [
            'exists' => true,
            'writable' => is_writable($path),
            'path' => $path
        ];
    } elseif (is_file($path)) {
        $diagnostics['permissions'][$name] = [
            'exists' => true,
            'writable' => is_writable($path),
            'size' => filesize($path),
            'path' => $path
        ];
    } else {
        // Intentar crear
        if (strpos($name, '.') === false) { // Es directorio
            if (@mkdir($path, 0755, true)) {
                $diagnostics['permissions'][$name] = [
                    'exists' => true,
                    'writable' => true,
                    'created' => true,
                    'path' => $path
                ];
            } else {
                $diagnostics['permissions'][$name] = [
                    'exists' => false,
                    'error' => 'No se pudo crear el directorio'
                ];
            }
        } else { // Es archivo
            if (@touch($path)) {
                $diagnostics['permissions'][$name] = [
                    'exists' => true,
                    'writable' => is_writable($path),
                    'created' => true,
                    'path' => $path
                ];
            } else {
                $diagnostics['permissions'][$name] = [
                    'exists' => false,
                    'error' => 'No se pudo crear el archivo'
                ];
            }
        }
    }
}

// 4. Verificar mensajes pendientes
try {
    // Verificar si existe la columna send_status
    $checkColumn = $pdo->query("SHOW COLUMNS FROM whatsapp_sms LIKE 'send_status'");
    
    if ($checkColumn->rowCount() > 0) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM whatsapp_sms WHERE send_status = 'pending'");
        $pendingCount = $stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT COUNT(*) FROM whatsapp_sms WHERE send_status = 'success'");
        $successCount = $stmt->fetchColumn();
        
        $stmt = $pdo->query("SELECT COUNT(*) FROM whatsapp_sms WHERE send_status = 'error'");
        $errorCount = $stmt->fetchColumn();
        
        $diagnostics['message_stats'] = [
            'status' => 'OK',
            'pending' => $pendingCount,
            'success' => $successCount,
            'error' => $errorCount
        ];
    } else {
        $stmt = $pdo->query("SELECT COUNT(*) FROM whatsapp_sms");
        $totalCount = $stmt->fetchColumn();
        
        $diagnostics['message_stats'] = [
            'status' => 'WARNING',
            'message' => 'Columna send_status no existe',
            'total_messages' => $totalCount
        ];
    }
} catch (Exception $e) {
    $diagnostics['message_stats'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
}

// 5. Verificar últimos mensajes
try {
    $sql = "SELECT id, client_id, phone_number, created";
    
    if (in_array('send_status', $columns ?? [])) {
        $sql .= ", send_status";
    }
    if (in_array('response_server', $columns ?? [])) {
        $sql .= ", response_server";
    }
    
    $sql .= " FROM whatsapp_sms ORDER BY id DESC LIMIT 5";
    
    $stmt = $pdo->query($sql);
    $lastMessages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $diagnostics['last_messages'] = [
        'status' => 'OK',
        'messages' => $lastMessages
    ];
} catch (Exception $e) {
    $diagnostics['last_messages'] = ['status' => 'ERROR', 'message' => $e->getMessage()];
}

// 6. Probar endpoints
$endpoints = [
    'qr' => 'https://fazoffs.site/c2VjcmV0bGV2ZWwyNA==/codes/master_ws.php?function=qr',
    'authenticated' => 'https://fazoffs.site/c2VjcmV0bGV2ZWwyNA==/codes/master_ws.php?function=authenticated',
    'get_data' => 'https://fazoffs.site/c2VjcmV0bGV2ZWwyNA==/codes/master_ws.php?function=get_data',
    'update_status' => 'https://fazoffs.site/c2VjcmV0bGV2ZWwyNA==/codes/master_ws.php?function=update_status',
    'data_async' => 'https://fazoffs.site/c2VjcmV0bGV2ZWwyNA==/codes/master_ws.php?function=data_async'
];

foreach ($endpoints as $name => $url) {
    try {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        if ($name !== 'data_async') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, '{}');
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $diagnostics['endpoints'][$name] = [
            'status' => ($httpCode >= 200 && $httpCode < 500) ? 'OK' : 'ERROR',
            'http_code' => $httpCode,
            'url' => $url
        ];
        
        if ($httpCode >= 200 && $httpCode < 500 && $response) {
            $decoded = json_decode($response, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $diagnostics['endpoints'][$name]['response_valid'] = true;
            }
        }
        
    } catch (Exception $e) {
        $diagnostics['endpoints'][$name] = [
            'status' => 'ERROR',
            'message' => $e->getMessage()
        ];
    }
}

// 7. Información del sistema
$diagnostics['system_info'] = [
    'php_version' => phpversion(),
    'max_execution_time' => ini_get('max_execution_time'),
    'memory_limit' => ini_get('memory_limit'),
    'post_max_size' => ini_get('post_max_size'),
    'server_time' => date('Y-m-d H:i:s'),
    'timezone' => date_default_timezone_get()
];

// Resumen
$hasErrors = false;
$hasWarnings = false;

foreach ($diagnostics as $section => $data) {
    if (is_array($data) && isset($data['status'])) {
        if ($data['status'] === 'ERROR') $hasErrors = true;
        if ($data['status'] === 'WARNING') $hasWarnings = true;
    }
}

$diagnostics['summary'] = [
    'overall_status' => $hasErrors ? 'ERROR' : ($hasWarnings ? 'WARNING' : 'OK'),
    'has_errors' => $hasErrors,
    'has_warnings' => $hasWarnings,
    'diagnostic_time' => date('Y-m-d H:i:s')
];

// Salida
header('Content-Type: application/json');
echo json_encode($diagnostics, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>