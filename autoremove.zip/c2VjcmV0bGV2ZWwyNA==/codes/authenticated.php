<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

function writeLog($message) {
    // Guarda un log con fecha y hora en app.log
    file_put_contents('app.log', date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

try {
    writeLog("====== INICIO authenticated.php ======");

    // Leemos el cuerpo de la petición (JSON) y lo decodificamos
    $raw = file_get_contents('php://input');
    if (!$raw) {
        throw new Exception("No se recibieron datos en el body");
    }

    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception("JSON inválido: " . json_last_error_msg());
    }

    // Validamos que venga clientId
    if (empty($data['clientId'])) {
        throw new Exception("Faltan campos obligatorios: clientId");
    }

    // Limpiamos espacios en clientId
    $clientId = trim($data['clientId']);

    writeLog("Datos recibidos: clientId=$clientId");

    // ------ Crear carpeta y archivo de log personalizado ------

    // Nombre de la carpeta donde guardaremos los .log
    $directory = __DIR__ . '/Auth_qr_authenticated';
    if (!is_dir($directory)) {
        // La carpeta no existe: la creamos con permisos 0755
        if (!mkdir($directory, 0755, true)) {
            writeLog("Error al crear directorio: $directory");
            // Continuamos el flujo, pero queda registrado
        } else {
            writeLog("Directorio creado: $directory");
        }
    }

    // Nombre del archivo de log basado en clientId
    $filename = $directory . "/{$clientId}.log";

    // Contenido JSON a escribir: solo los datos recibidos
    $jsonContent = json_encode([
        'clientId'   => $clientId,
        'receivedAt' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);

    // Guardamos el JSON dentro del archivo .log
    if (file_put_contents($filename, $jsonContent . PHP_EOL) === false) {
        writeLog("Error al escribir en archivo: $filename");
    } else {
        writeLog("Archivo .log escrito correctamente: $filename");
    }
    // ----------------------------------------------------------

    // Devolvemos respuesta de éxito (sin lógica de base de datos)
    echo json_encode([
        'error'   => false,
        'message' => "Archivo de autenticación creado para clientId: $clientId"
    ]);

} catch (Exception $e) {
    writeLog("Error en authenticated.php: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'error'   => true,
        'message' => $e->getMessage()
    ]);
}

writeLog("====== FIN authenticated.php ======");
