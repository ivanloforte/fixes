<?php
header('Content-Type: application/json');
$directory = 'Auth_qr';
$files = glob("$directory/ws-*-not_used.log");

// Borrar archivos con más de 90 segundos de antigüedad
$currentTime = time();
foreach ($files as $file) {
    if (filemtime($file) < ($currentTime - 90)) { // 90 segundos
        unlink($file);
    }
}

// Actualizar lista de archivos luego de eliminar los viejos
$files = glob("$directory/ws-*-not_used.log");
if (empty($files)) {
    http_response_code(404);
    echo json_encode(['error' => 'No QR codes available', 'retry' => true]);
    exit;
}

// Ordenar archivos por fecha más reciente usando la fecha de modificación del archivo
usort($files, function($a, $b) {
    return filemtime($b) - filemtime($a); // Más reciente primero
});

$latestFile = $files[0];
$fileContent = file_get_contents($latestFile);
$data = json_decode($fileContent, true);

if (!$data || !isset($data['qrCode']) || !isset($data['clientId'])) {
    http_response_code(500);
    echo json_encode(['error' => 'Invalid QR file format']);
    exit;
}

// Renombrar el archivo para marcarlo como procesado
$newFilename = str_replace('-not_used', '-processing', $latestFile);
rename($latestFile, $newFilename);

echo json_encode([
    'success' => true,
    'qrCode' => $data['qrCode'],
    'clientId' => $data['clientId']
]);
?>