<?php
header('Content-Type: application/json');

// Obtener datos del POST
$data = json_decode(file_get_contents('php://input'), true);

// Validar datos recibidos
if (!isset($data['qrCode']) || !isset($data['clientId'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Datos incompletos']);
    exit;
}

// Configuración de directorio
$directory = 'Auth_qr';
$maxAgeSeconds = 60;

// Crear directorio con verificación de errores
if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
    http_response_code(500);
    echo json_encode(['error' => 'Error creando directorio']);
    exit;
}

// Generar nombre de archivo
$clientId = preg_replace('/[^a-zA-Z0-9\-]/', '', $data['clientId']);
$filename = "ws-" . date('Y-m-d-H-i') . "-{$clientId}-not_used.log";
$filepath = "{$directory}/{$filename}";

try {
    // Escribir archivo
    if (file_put_contents($filepath, json_encode($data)) === false) {
        throw new Exception('Error escribiendo archivo');
    }

    // Limpieza de archivos antiguos
    $files = glob("{$directory}/*-not_used.log");
    $now = time();
    
    foreach ($files as $file) {
        if (!is_file($file)) continue;
        
        $fileTime = @filemtime($file);
        if (!$fileTime) continue;
        
        if (($now - $fileTime) > $maxAgeSeconds) {
            @unlink($file) or error_log("Error eliminando: $file");
        }
    }

    // Respuesta con contenido
    echo json_encode([
        'success' => true,
        'file' => $filename,
        'contenido' => [
            'qrCode' => $data['qrCode'],
            'clientId' => $data['clientId']
        ]
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>