<?php
header('Content-Type: application/json');

// Obtener datos del POST
$data = json_decode(file_get_contents('php://input'), true);

// Validar datos recibidos
if (!isset($data['clientId'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Datos incompletos']);
    exit;
}

// Limpiar clientId
$clientId = preg_replace('/[^a-zA-Z0-9\-]/', '', $data['clientId']);

// Buscar archivo original con patrón más flexible
// Busca cualquier archivo del clientId que termine en "not_used.log"
$searchPattern = "Auth_qr/ws-*-{$clientId}-not_used.log";

// Buscar archivo original
$files = glob($searchPattern);

if (empty($files)) {
    // Si no encuentra, intentar buscar en las últimas 2 horas
    $foundFile = null;
    $currentTime = time();
    
    // Buscar archivos de las últimas 2 horas
    for ($i = 0; $i < 120; $i++) { // 120 minutos
        $checkTime = $currentTime - ($i * 60);
        $checkDate = date('Y-m-d-H-i', $checkTime);
        $checkPattern = "Auth_qr/ws-{$checkDate}-{$clientId}-not_used.log";
        
        if (file_exists($checkPattern)) {
            $foundFile = $checkPattern;
            break;
        }
    }
    
    if (!$foundFile) {
        http_response_code(404);
        echo json_encode([
            'error' => 'Archivo no encontrado',
            'searchPattern' => $searchPattern,
            'clientId' => $clientId
        ]);
        exit;
    }
    
    $files = [$foundFile];
}

// Generar nuevo nombre con fecha actual
$fechaActual = date('Y-m-d-H-i');
$newFilename = "ws-{$fechaActual}-{$clientId}-processing.log";

// Renombrar archivo y actualizar contenido
try {
    $originalFile = $files[0];
    $newFilepath = "Auth_qr/{$newFilename}";
    
    // Verificar que el archivo original existe
    if (!file_exists($originalFile)) {
        http_response_code(404);
        echo json_encode([
            'error' => 'Archivo original no existe',
            'file' => $originalFile
        ]);
        exit;
    }
    
    // Renombrar archivo
    if (!rename($originalFile, $newFilepath)) {
        throw new Exception('No se pudo renombrar el archivo');
    }
    
    // Actualizar contenido con los datos recibidos
    if (!file_put_contents($newFilepath, json_encode($data, JSON_PRETTY_PRINT))) {
        throw new Exception('No se pudo actualizar el contenido');
    }
    
    // Respuesta exitosa
    echo json_encode([
        'success' => true,
        'original' => basename($originalFile),
        'renamed' => $newFilename,
        'clientId' => $clientId,
        'timestamp' => $fechaActual
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Error al procesar el archivo: ' . $e->getMessage(),
        'clientId' => $clientId
    ]);
}
?>