<?php
// c2VjcmV0bGV2ZWwyNA==/codes/search_users.php
header('Content-Type: application/json; charset=utf-8');
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';

try {
    $con = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                   $username, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Optimizaciones de conexión
    $con->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
    $con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['results'=>[], 'error'=>'Connection failed']);
    exit;
}

$q = isset($_GET['q']) ? trim($_GET['q']) : '';

// Validación básica para evitar consultas muy cortas que devuelvan demasiados resultados
if ($q !== '' && strlen($q) < 2) {
    echo json_encode(['results'=>[], 'message'=>'Mínimo 2 caracteres para buscar']);
    exit;
}

// Construcción de consulta optimizada
if ($q !== '') {
    // Usar FULLTEXT si está disponible, sino usar LIKE optimizado
    $sql = "
        SELECT id, email AS text
        FROM users
        WHERE (email LIKE :term_start OR full_name LIKE :term_start)
           OR (email LIKE :term_any OR full_name LIKE :term_any)
        ORDER BY 
            CASE 
                WHEN email LIKE :term_start THEN 1
                WHEN full_name LIKE :term_start THEN 2
                WHEN email LIKE :term_any THEN 3
                ELSE 4
            END,
            email
    ";
    
    $stmt = $con->prepare($sql);
    
    // Patrones de búsqueda optimizados
    $termStart = $q . '%';      // Coincidencias que empiecen con el término (más rápido)
    $termAny = '%' . $q . '%';  // Coincidencias en cualquier parte
    
    $stmt->bindParam(':term_start', $termStart, PDO::PARAM_STR);
    $stmt->bindParam(':term_any', $termAny, PDO::PARAM_STR);
} else {
    // Sin filtro, obtener todos ordenados
    $sql = "
        SELECT id, email AS text
        FROM users
        ORDER BY email
    ";
    $stmt = $con->prepare($sql);
}

try {
    $stmt->execute();
    
    // Usar fetchAll solo para conjuntos pequeños, sino usar fetch iterativo
    $results = [];
    $count = 0;
    
    // Streaming de resultados para mejor rendimiento en memoria
    while ($row = $stmt->fetch()) {
        $results[] = $row;
        $count++;
        
        // Opcional: Límite de seguridad para evitar timeouts (ajustar según necesidades)
        if ($count >= 10000) {
            break;
        }
    }
    
    echo json_encode([
        'results' => $results,
        'count' => $count,
        'has_more' => $count >= 10000
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['results'=>[], 'error'=>'Query failed']);
}

$stmt = null;
$con = null;
exit;