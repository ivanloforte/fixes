<?php
// c2VjcmV0bGV2ZWwyNA==/codes/get_user_info.php
header('Content-Type: application/json; charset=utf-8');
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';

try {
    $con = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4",
                   $username, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error'=>'Connection failed']);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $con->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id'=>$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['error'=>'User not found']);
    exit;
}

// Normaliza booleanos a 0/1
foreach ($user as $k=>$v) {
    if ($v===null) $user[$k] = '';
    if ($v==='0' || $v==='1') $user[$k] = (int)$v;
}

echo json_encode($user);
exit;
