<?php
/*---------------------------------------------------------------
 # c2VjcmV0bGV2ZWwyNA==/codes/user_save.php
 # Guarda (inserta/actualiza) la información del usuario
 # 15‑May‑2025
 ----------------------------------------------------------------*/
header('Content-Type: application/json; charset=utf-8');

/*---------------------------------------------------------------
 | 0. Conexión a la base de datos
 *--------------------------------------------------------------*/
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$dbuser   = 'fazoffs2_user';
$dbpass   = 'CxzDsaEwq32!';

try {
    $con = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser,
        $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'msg'=>'DB connection failed']);
    exit;
}

/*---------------------------------------------------------------
 | 1. Campos recibidos y configuraciones
 *--------------------------------------------------------------*/
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

/* Campos permitidos (deben existir en la tabla) */
$allFields = [
    // Generales
    'first_name','last_name','full_name','email','phone','telegram_username',
    'username','role',
    // Créditos
    'link_credits','sms_credits','whatsapp_credits','domain_credits',
    'voice_credits','email_credits','credit_services',
    // Seguridad
    'apiaccess','chat_id','custom_bot',
    // Flags
    'status','email_verified','two_factor_enabled',
    // Auditoría
    'last_seen','last_login','verification_expiration','forgot_key_expiration'
];

$boolFields      = ['status','email_verified','two_factor_enabled'];
$datetimeFields  = ['last_seen','last_login','verification_expiration','forgot_key_expiration'];
$decimalFields   = [
    'link_credits','sms_credits','whatsapp_credits','domain_credits',
    'voice_credits','email_credits','credit_services'
];

/*---------------------------------------------------------------
 | 2. Limpia y normaliza los datos del formulario
 *--------------------------------------------------------------*/
$data = [];
foreach ($allFields as $f) {
    if (!array_key_exists($f, $_POST)) continue;   // campo no enviado

    if (in_array($f, $boolFields, true)) {
        $data[$f] = $_POST[$f] ? 1 : 0;
    } elseif (in_array($f, $datetimeFields, true)) {
        $data[$f] = ($_POST[$f] === '') ? null
                  : date('Y-m-d H:i:s', strtotime($_POST[$f]));
    } elseif (in_array($f, $decimalFields, true)) {
        $data[$f] = ($_POST[$f] === '') ? 0 : (float)$_POST[$f];
    } else {
        $trim = trim($_POST[$f]);
        $data[$f] = ($trim === '') ? null : $trim;
    }
}


/*---------------------------------------------------------------
 | 4. Foto de perfil
 *--------------------------------------------------------------*/
if (!empty($_FILES['profile_picture']['name'])
    && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {

    $folder = realpath(__DIR__ . '/../../uploads/profile_pictures');
    if ($folder === false) {
        $folder = __DIR__ . '/../../uploads/profile_pictures';
        @mkdir($folder, 0775, true);
    }

    $ext       = strtolower(pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION));
    $fileName  = uniqid('pp_', true) . '.' . $ext;
    $fullPath  = $folder . DIRECTORY_SEPARATOR . $fileName;

    if (!move_uploaded_file($_FILES['profile_picture']['tmp_name'], $fullPath)) {
        echo json_encode(['success' => false, 'msg' => 'No se pudo subir la imagen']);
        exit;
    }
    // Ruta relativa que se guarda en la BD
    $data['profile_picture'] = 'uploads/profile_pictures/' . $fileName;
}

/*---------------------------------------------------------------
 | 5. SQL dinámico: UPDATE o INSERT
 *--------------------------------------------------------------*/
try {
    if ($id) {
        /*------------------------ UPDATE -----------------------*/
        if (empty($data)) {
            echo json_encode(['success'=>false,'msg'=>'Sin cambios por guardar']);
            exit;
        }

        // genera "campo = :campo"
        $set = implode(', ', array_map(fn($c)=>"$c = :$c", array_keys($data)));
        $sql = "UPDATE users SET $set, modified = NOW() WHERE id = :id";
        $stmt = $con->prepare($sql);
        $data['id'] = $id;                    // para el WHERE
        $stmt->execute($data);

        echo json_encode([
            'success' => true,
            'msg'     => 'Datos del usuario actualizados',
            'id'      => $id
        ]);

    } else {
        /*------------------------ INSERT -----------------------*/
        if (empty($data)) {
            echo json_encode(['success'=>false,'msg'=>'Datos insuficientes para crear el usuario']);
            exit;
        }

        $cols   = implode(',', array_keys($data)) . ',created';
        $places = implode(',', array_map(fn($c)=>":$c", array_keys($data))) . ',NOW()';

        $sql = "INSERT INTO users ($cols) VALUES ($places)";
        $stmt = $con->prepare($sql);
        $stmt->execute($data);

        echo json_encode([
            'success' => true,
            'msg'     => 'Usuario creado',
            'id'      => $con->lastInsertId()
        ]);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'msg'     => 'Error al guardar',
        'error'   => $e->getMessage()
    ]);
}
exit;
