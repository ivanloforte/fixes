<?php
// File: add_sender_template.php

// CORS headers — ajusta el origen si necesitas restringirlo
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Manejo de preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Allow GET or POST
$method = $_SERVER['REQUEST_METHOD'];
if (!in_array($method, ['POST','GET'])) {
    http_response_code(405);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Método no permitido'
    ]);
    exit;
}

// Get request data (supports both GET and POST arrays)
$requestData = $_REQUEST['data']['SendersPlantillas'] ?? null;
if (!is_array($requestData)) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'No se recibieron datos en data[SendersPlantillas]'
    ]);
    exit;
}

// Extract & sanitize
$sender_id     = trim($requestData['sender_id']     ?? '');
$template_name = trim($requestData['template_name'] ?? '');
$carrier_name  = trim($requestData['carrier_name']  ?? '');
$template      = trim($requestData['template']      ?? '');
$status        = isset($requestData['status'])
                   ? (int)$requestData['status']
                   : 0;
// Por defecto 'Admin' si no viene en la petición
$created_by    = trim($requestData['created_by'] ?? 'Admin');

// Validate required fields (except created_by)
$errors = [];
if ($sender_id === '')     $errors[] = 'sender_id es obligatorio';
if ($template_name === '') $errors[] = 'template_name es obligatorio';
if ($carrier_name === '')  $errors[] = 'carrier_name es obligatorio';
if ($template === '')      $errors[] = 'template es obligatorio';

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Errores de validación',
        'errors'  => $errors
    ]);
    exit;
}

// Database connection
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';

try {
    $con = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error de conexión a la base de datos'
    ]);
    exit;
}

// Insert into senders_plantillas
try {
    $stmt = $con->prepare("
        INSERT INTO senders_plantillas
          (sender_id, template_name, carrier_name, template, status, created, created_by)
        VALUES
          (:sender_id, :template_name, :carrier_name, :template, :status, NOW(), :created_by)
    ");
    $stmt->execute([
        ':sender_id'     => $sender_id,
        ':template_name' => $template_name,
        ':carrier_name'  => $carrier_name,
        ':template'      => $template,
        ':status'        => $status,
        ':created_by'    => $created_by
    ]);
    $newId = $con->lastInsertId();

    echo json_encode([
        'status'      => 'success',
        'message'     => "Template '{$template_name}' Succesfully!",
        'template_id' => $newId
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error al guardar la plantilla: ' . $e->getMessage()
    ]);
}
