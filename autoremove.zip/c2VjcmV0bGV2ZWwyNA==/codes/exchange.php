<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

function writeLog($message) {
    file_put_contents('app_exchange.log', date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

try {
    writeLog("====== EXCHANGE PROCESS START ======");

    // Validar los parámetros obligatorios POST
    if (!isset($_POST['user_id'], $_POST['target_credit'], $_POST['credit_amount'])) {
        throw new Exception("Missing required parameters: user_id, target_credit or credit_amount.");
    }
    
    $userId = $_POST['user_id'];
    $targetCredit = $_POST['target_credit'];
    $creditAmountInput = $_POST['credit_amount'];

    // Allowed credit fields that can be exchanged
    $allowedCredits = ['link_credits', 'sms_credits', 'voice_credits', 'email_credits', 'whatsapp_credits', 'domain_credits'];
    if (!in_array($targetCredit, $allowedCredits)) {
        throw new Exception("Invalid target credit type provided.");
    }

    // Database configuration
    $dbHost = "localhost";
    $dbName = "fazoffs2_db";
    $dbUser = "fazoffs2_user";
    $dbPass = "CxzDsaEwq32!";

    // Conectar a la base de datos usando PDO
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    // Inicia la transacción
    $pdo->beginTransaction();

    // Obtener el registro del usuario por su ID, incluyendo credit_services y el campo destino
    $query = "SELECT id, credit_services, {$targetCredit} FROM users WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("User not found.");
    }
    
    // Convertir los valores a float para manipular campos DECIMAL(20,2)
    $currentCreditServices = (float)$user['credit_services'];
    
    // Se requiere tener al menos 5 créditos en credit_services
    if ($currentCreditServices < 5) {
        throw new Exception("Insufficient credit services available for exchange. Minimum 5 required.");
    }
    
    // Validar y establecer el monto a intercambiar a partir del valor enviado vía POST
    $conversionAmount = (float)$creditAmountInput;
    if ($conversionAmount <= 0) {
        throw new Exception("The credit amount must be greater than zero.");
    }
    if ($conversionAmount < 1) {
        throw new Exception("The minimum exchange amount is 1 credit.");
    }
    if ($conversionAmount > $currentCreditServices) {
        throw new Exception("Insufficient credit_services balance for the requested exchange amount.");
    }
    if ($conversionAmount > 10000.00) {
        throw new Exception("The maximum amount per exchange is 10,000 credits.");
    }
    
    // Calcular nuevos saldos con conversión a ratio 1:1
    $newCreditServices = $currentCreditServices - $conversionAmount;
    $currentTarget = (float)$user[$targetCredit];
    $newTargetValue = $currentTarget + $conversionAmount;
    
    // Actualizar el registro del usuario: deducir de credit_services y sumar al campo de créditos destino.
    $updateQuery = "UPDATE users SET credit_services = ?, {$targetCredit} = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateQuery);
    $updateStmt->execute([
        number_format($newCreditServices, 2, '.', ''),
        number_format($newTargetValue, 2, '.', ''),
        $userId
    ]);
    
    // Confirmar la transacción
    $pdo->commit();

    writeLog("Exchange completed for user ID {$userId}: Deducted \${$conversionAmount} from credit_services. New credit_services balance: \$" . number_format($newCreditServices, 2) . ". Updated {$targetCredit} balance: \$" . number_format($newTargetValue, 2) . ".");
    
    // Retornar respuesta detallada en JSON con propiedad success
    echo json_encode([
        'success' => true,
        'message' => 'Exchange completed successfully.',
        'details' => [
            'exchanged_amount'      => number_format($conversionAmount, 2, '.', ''),
            'new_credit_services'   => number_format($newCreditServices, 2, '.', ''),
            $targetCredit           => number_format($newTargetValue, 2, '.', '')
        ]
    ]);

} catch (PDOException $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    writeLog("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error.',
        'details' => $e->getMessage()
    ]);
} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    writeLog("General error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Exchange failed.',
        'details' => $e->getMessage()
    ]);
}
?>
