<?php
// Conexión a la base de datos
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión: ' . $e->getMessage()], JSON_PRETTY_PRINT);
    exit;
}

// Verificar si se pasa un id_sender y una acción
if (isset($_GET['id_sender']) && isset($_GET['action'])) {
    $id_sender = $_GET['id_sender'];
    $action = $_GET['action'];

    // Procesar la acción de Disable
    if ($action == 'disable') {
        // Actualizar el estado a "deshabilitado"
        $stmt = $pdo->prepare("UPDATE senders_status SET status = 0 WHERE id_sender = :id_sender");
        $stmt->execute(['id_sender' => $id_sender]);
        echo json_encode(['status' => 'success', 'message' => 'Sender disabled successfully'], JSON_PRETTY_PRINT);
        exit;
    } 
    // Procesar la acción de Enable
    elseif ($action == 'enable') {
        // Actualizar el estado a "habilitado"
        $stmt = $pdo->prepare("UPDATE senders_status SET status = 1 WHERE id_sender = :id_sender");
        $stmt->execute(['id_sender' => $id_sender]);
        echo json_encode(['status' => 'success', 'message' => 'Sender enabled successfully'], JSON_PRETTY_PRINT);
        exit;
    } 
    // Procesar la acción de Delete
    elseif ($action == 'delete') {
        // Eliminar el sender
        $stmt = $pdo->prepare("DELETE FROM senders_status WHERE id_sender = :id_sender");
        $stmt->execute(['id_sender' => $id_sender]);
        echo json_encode(['status' => 'success', 'message' => 'Sender deleted successfully'], JSON_PRETTY_PRINT);
        exit;
    }
}

// Obtener los detalles del sender
if (isset($_GET['id_sender'])) {
    $id_sender = $_GET['id_sender'];
    $stmt = $pdo->prepare("SELECT * FROM senders_status WHERE id_sender = :id_sender");
    $stmt->execute(['id_sender' => $id_sender]);
    $sender = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'sender' => $sender], JSON_PRETTY_PRINT);
    exit;
}

// Si no se pasa ningún id_sender o acción, devolver un error
echo json_encode(['status' => 'error', 'message' => 'Invalid request'], JSON_PRETTY_PRINT);
exit;
?>
