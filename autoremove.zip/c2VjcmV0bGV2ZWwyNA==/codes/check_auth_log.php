<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Ruta donde se guardan los .log generados por authenticated.php
$baseDir = __DIR__ . '/Auth_qr_authenticated';

try {
    if (!isset($_GET['clientId'])) {
        throw new Exception("Falta parámetro clientId");
    }
    $clientId = trim($_GET['clientId']);
    if ($clientId === '') {
        throw new Exception("clientId vacío");
    }

    // Si la carpeta no existe, devolvemos exists=false
    if (!is_dir($baseDir)) {
        echo json_encode(['exists' => false]);
        exit;
    }

    // Verificamos directamente si existe el archivo exacto clientId.log
    $filename = $baseDir . "/{$clientId}.log";
    $found = is_file($filename);

    echo json_encode(['exists' => $found]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'exists' => false,
        'error'  => true,
        'msg'    => $e->getMessage()
    ]);
}
