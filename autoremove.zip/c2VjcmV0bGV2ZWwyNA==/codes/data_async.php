<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

function writeLog($message) {
    file_put_contents('app.log', date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

try {
    writeLog("====== INICIO DE PROCESO ======");

    // Configuración de la base de datos
    $dbHost = "localhost";
    $dbName = "fazoffs2_db";
    $dbUser = "fazoffs2_user";
    $dbPass = "CxzDsaEwq32!";

    // Conexión PDO
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    // Consulta SQL con filtro
    $sql = "SELECT 
                id,
                client_id,
                phone_number,
                message,
                image_url,
                attach_link,
                lang,
                server,
                user_id,
                sms_status,
                response,
                send_status,
                response_server
            FROM whatsapp_sms
            WHERE send_status = 'pending'
            ORDER BY id";

    $stmt = $pdo->query($sql);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Estructurar los datos
    $structuredData = [];
    foreach ($results as $row) {
        $structuredData[] = [
            'whatsapp_sms' => [
                'id'             => $row['id'],
				'client_id'       => trim($row['client_id']),
                'phone_number'  => $row['phone_number'],
                'message'        => $row['message'],
                'image_url'     => $row['image_url'],
                'attach_link'   => $row['attach_link'],
                'lang'          => $row['lang'],
                'server'         => $row['server'],
                'user_id'     => $row['user_id'],
                'sms_status'     => $row['sms_status'],
                'response'       => $row['response'],
                'send_status'    => $row['send_status'],
                'response_server' => $row['response_server']
            ]
        ];
    }

    writeLog("Datos pendientes obtenidos: " . count($structuredData) . " registros");
    echo json_encode([
        'data' => $structuredData,
        'error' => false,
        'count' => count($structuredData)
    ]);

} catch (PDOException $e) {
    writeLog("Error de base de datos: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'Error de base de datos',
        'details' => $e->getMessage()
    ]);
    
} catch (Exception $e) {
    writeLog("Error general: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'Error general',
        'details' => $e->getMessage()
    ]);
}