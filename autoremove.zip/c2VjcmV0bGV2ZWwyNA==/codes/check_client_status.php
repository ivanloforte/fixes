<?php
header('Content-Type: application/json');

$clientId = isset($_GET['clientId']) ? $_GET['clientId'] : '';
$directory = 'Auth_qr';

$status = 'not_found';
$files = glob("$directory/ws-*-{$clientId}-*.log");

foreach ($files as $file) {
    if (strpos($file, '-AuthOnline.log')) {
        $status = 'authenticated';
        break;
    } elseif (strpos($file, '-processing.log')) {
        $status = 'processing';
        break;
    } elseif (strpos($file, '-not_used.log')) {
        $status = 'pending';
        break;
    }
}

echo json_encode([
    'clientId' => $clientId,
    'status' => $status,
    'files' => $files
]);
?>