<?php
// File: add_sender_status.php

// CORS headers — ajusta el origen si necesitas restringirlo
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Manejo de preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Allow GET or POST
$method = $_SERVER['REQUEST_METHOD'];
if (!in_array($method, ['POST', 'GET'])) {
    http_response_code(405);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Método no permitido'
    ]);
    exit;
}

// Obtener datos de la petición (soporta GET y POST)
$requestData = $_REQUEST['data']['SendersStatus'] ?? null;
if (!is_array($requestData)) {
    http_response_code(400);
    echo json_encode([
        'status'  => 'error',
        'message' => 'No se recibieron datos en data[SendersStatus]'
    ]);
    exit;
}

// Extraer y sanitizar
$sender        = trim($requestData['sender']        ?? '');
$price         = trim($requestData['price']         ?? '');
$sender_search = trim($requestData['sender_search'] ?? '');
$status        = isset($requestData['status'])
                 ? (int)$requestData['status']
                 : 0;

// Validar campos obligatorios
$errors = [];
if ($sender === '')        $errors[] = 'El campo sender es obligatorio';
if ($price === '' || !is_numeric($price)) {
    $errors[] = 'El campo price es obligatorio y debe ser numérico';
}
if ($sender_search === '') $errors[] = 'El campo sender_search es obligatorio';

if (!empty($errors)) {
    http_response_code(422);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Errores de validación',
        'errors'  => $errors
    ]);
    exit;
}

// Conexión a la base de datos
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';

try {
    $con = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error de conexión a la base de datos'
    ]);
    exit;
}

// Insertar en senders_status
try {
    $stmt = $con->prepare("INSERT INTO senders_status
        (sender, price, status, sender_search)
        VALUES
        (:sender, :price, :status, :sender_search)");
    $stmt->execute([
        ':sender'        => $sender,
        ':price'         => $price,
        ':status'        => $status,
        ':sender_search' => $sender_search
    ]);
    $newId = $con->lastInsertId();

    echo json_encode([
        'status'     => 'success',
        'message'    => "Sender '{$sender}' Add Succesfully!",
        'id_sender'  => $newId
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error al guardar el sender: ' . $e->getMessage()
    ]);
}
