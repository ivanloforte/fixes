<?php
// cache.php
header('Content-Type: application/json');

// Ruta absoluta del directorio de caché a limpiar.
// Asegúrate de que esta ruta es la correcta para tu entorno.
$folderPath = __DIR__ . "/Auth_qr";

// Verificar si el directorio existe
if (!is_dir($folderPath)) {
    echo json_encode([
        'success' => false,
        'message' => 'El directorio de caché no existe.'
    ]);
    exit;
}

// Obtener todos los archivos del directorio
$files = glob($folderPath . '/*');
$deletedCount = 0;
$errorFiles   = [];

foreach ($files as $file) {
    if (is_file($file)) {
        if (unlink($file)) {
            $deletedCount++;
        } else {
            $errorFiles[] = basename($file);
        }
    }
}

// Preparar respuesta final
if (count($errorFiles) > 0) {
    $errorMessage = "Error al borrar los siguientes archivos: " . implode(", ", $errorFiles);
    echo json_encode([
        'success' => false,
        'message' => $errorMessage,
        'deleted' => $deletedCount
    ]);
} else {
    echo json_encode([
        'success' => true,
        'message' => "Caché limpiada exitosamente. Archivos eliminados: $deletedCount",
        'deleted' => $deletedCount
    ]);
}
?>
