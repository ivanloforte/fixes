<?php
// File: config_sender_status.php

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Connect to the database
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';

try {
    $con = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'Error de conexión a la base de datos'
    ]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET' && isset($_GET['action'], $_GET['id_sender'])) {
    // enable / disable / delete actions
    $action    = $_GET['action'];
    $id_sender = (int) $_GET['id_sender'];

    try {
        switch ($action) {
            case 'enable':
                $stmt = $con->prepare("UPDATE senders_status SET status = 1 WHERE id_sender = :id");
                $stmt->execute([':id' => $id_sender]);
                $message = "Sender #{$id_sender} habilitado correctamente";
                break;

            case 'disable':
                $stmt = $con->prepare("UPDATE senders_status SET status = 0 WHERE id_sender = :id");
                $stmt->execute([':id' => $id_sender]);
                $message = "Sender #{$id_sender} deshabilitado correctamente";
                break;

            case 'delete':
                $stmt = $con->prepare("DELETE FROM senders_status WHERE id_sender = :id");
                $stmt->execute([':id' => $id_sender]);
                $message = "Sender #{$id_sender} eliminado correctamente";
                break;

            default:
                http_response_code(400);
                echo json_encode([
                    'status'  => 'error',
                    'message' => "Acción inválida: {$action}"
                ]);
                exit;
        }

        echo json_encode([
            'status'  => 'success',
            'message' => $message
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'status'  => 'error',
            'message' => 'Error al procesar la acción: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Insert a new sender status (same as before)
if (in_array($method, ['POST', 'GET']) && isset($_REQUEST['data']['SendersStatus'])) {
    $requestData = $_REQUEST['data']['SendersStatus'];
    if (!is_array($requestData)) {
        http_response_code(400);
        echo json_encode([
            'status'  => 'error',
            'message' => 'No se recibieron datos en data[SendersStatus]'
        ]);
        exit;
    }

    // Sanitize and validate
    $sender        = trim($requestData['sender']        ?? '');
    $price         = trim($requestData['price']         ?? '');
    $sender_search = trim($requestData['sender_search'] ?? '');
    $status        = isset($requestData['status'])
                     ? (int)$requestData['status']
                     : 0;

    $errors = [];
    if ($sender === '')        $errors[] = 'El campo sender es obligatorio';
    if ($price === '' || !is_numeric($price)) {
        $errors[] = 'El campo price es obligatorio y debe ser numérico';
    }
    if ($sender_search === '') $errors[] = 'El campo sender_search es obligatorio';

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode([
            'status'  => 'error',
            'message' => 'Errores de validación',
            'errors'  => $errors
        ]);
        exit;
    }

    try {
        $stmt = $con->prepare("INSERT INTO senders_status
            (sender, price, status, sender_search)
            VALUES
            (:sender, :price, :status, :sender_search)");
        $stmt->execute([
            ':sender'        => $sender,
            ':price'         => $price,
            ':status'        => $status,
            ':sender_search' => $sender_search
        ]);
        $newId = $con->lastInsertId();

        echo json_encode([
            'status'     => 'success',
            'message'    => "Sender '{$sender}' agregado correctamente",
            'id_sender'  => $newId
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode([
            'status'  => 'error',
            'message' => 'Error al guardar el sender: ' . $e->getMessage()
        ]);
    }
    exit;
}

// If we reach here, the request was invalid
http_response_code(400);
echo json_encode([
    'status'  => 'error',
    'message' => 'Solicitud no válida'
]);
