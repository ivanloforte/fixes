<?php
// Conexión a la base de datos
$host     = 'localhost';
$dbname   = 'fazoffs2_db';
$username = 'fazoffs2_user';
$password = 'CxzDsaEwq32!';
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión: ' . $e->getMessage()], JSON_PRETTY_PRINT);
    exit;
}

// Verificar si se pasa un id y una acción
if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    // Procesar la acción de Disable (deshabilitar)
    if ($action == 'disable') {
        // Actualizar el estado a "deshabilitado"
        $stmt = $pdo->prepare("UPDATE senders_plantillas SET status = 0 WHERE id = :id");
        $stmt->execute(['id' => $id]);
        echo json_encode(['status' => 'success', 'message' => 'Template disabled successfully'], JSON_PRETTY_PRINT);
        exit;
    } 
    // Procesar la acción de Enable (habilitar)
    elseif ($action == 'enable') {
        // Actualizar el estado a "habilitado"
        $stmt = $pdo->prepare("UPDATE senders_plantillas SET status = 1 WHERE id = :id");
        $stmt->execute(['id' => $id]);
        echo json_encode(['status' => 'success', 'message' => 'Template enabled successfully'], JSON_PRETTY_PRINT);
        exit;
    } 
    // Procesar la acción de Delete (eliminar)
    elseif ($action == 'delete') {
        // Eliminar la plantilla
        $stmt = $pdo->prepare("DELETE FROM senders_plantillas WHERE id = :id");
        $stmt->execute(['id' => $id]);
        echo json_encode(['status' => 'success', 'message' => 'Template deleted successfully'], JSON_PRETTY_PRINT);
        exit;
    }
}

// Obtener los detalles de la plantilla
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM senders_plantillas WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $template = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'template' => $template], JSON_PRETTY_PRINT);
    exit;
}

// Si no se pasa ningún id o acción, devolver un error
echo json_encode(['status' => 'error', 'message' => 'Invalid request'], JSON_PRETTY_PRINT);
exit;
?>
