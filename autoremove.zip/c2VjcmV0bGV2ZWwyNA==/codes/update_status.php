<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

function writeLog($message) {
    file_put_contents('app.log', date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

try {
    writeLog("====== INICIO DE ACTUALIZACIÓN DE ESTADO ======");

    // Configuración de la base de datos
    $dbHost = "localhost";
    $dbName = "fazoffs2_db";
    $dbUser = "fazoffs2_user";
    $dbPass = "CxzDsaEwq32!";

    // Conexión PDO
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    // Leer datos del cuerpo de la solicitud
    $inputData = json_decode(file_get_contents('php://input'), true);
    
    if (!$inputData) {
        throw new Exception('Datos de entrada inválidos');
    }

    // Validar campos obligatorios
    $requiredFields = ['message_id', 'response_server'];
    foreach ($requiredFields as $field) {
        if (!isset($inputData[$field])) {
            throw new Exception("Campo requerido faltante: {$field}");
        }
    }

    // Determinar el estado basado en el contenido de response_server
    // Si llega exactamente "Error: Client is not authenticated", se asigna 'success'
    // Si llega exactamente "Client_ID_expire", se asigna 'pending'
    // Si empieza con "error:" se asigna 'pending', de lo contrario 'success'
    if ($inputData['response_server'] === 'Error: Client is not authenticated') {
        $newStatus = 'Client_ID_expire';
    } elseif ($inputData['response_server'] === 'Client_ID_expire') {
        $newStatus = 'Client_ID_expire';
    } elseif (stripos($inputData['response_server'], 'error:') === 0) {
        $newStatus = 'error';
    } else {
        $newStatus = 'success';
    }

    // Preparar consulta de actualización
    $sql = "UPDATE whatsapp_sms 
            SET send_status = :status,
                response_server = :response_server
            WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    
    // Ejecutar consulta
    $result = $stmt->execute([
        ':id'              => $inputData['message_id'],
        ':response_server' => $inputData['response_server'],
        ':status'          => $newStatus
    ]);

    // Verificar si se actualizó algún registro
    $updated = $stmt->rowCount() > 0;

    writeLog("Actualización estado ID {$inputData['message_id']}: " . 
             ($updated ? "Éxito" : "Ningún registro afectado") . 
             " - Nuevo estado: {$newStatus}");

    echo json_encode([
        'success'         => $updated,
        'message'         => $updated ? 'Estado actualizado correctamente' : 'No se encontró el mensaje',
        'updated_id'      => $inputData['message_id'],
        'new_status'      => $newStatus,
        'response_server' => $inputData['response_server']
    ]);

} catch (PDOException $e) {
    writeLog("Error de base de datos: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Error de base de datos',
        'details' => $e->getMessage()
    ]);
    
} catch (Exception $e) {
    writeLog("Error general: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error'   => $e->getMessage()
    ]);
}
?>
