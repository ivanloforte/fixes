<?php exit; /* log interno do autoremove - nao acessivel via HTTP */
// [2026-10-22 16:09:18] [52ecefe4] REQUEST {"ip":"153.56.168.61","web":"apple","view":"json","autoremove":"1","apple_id":"stelaodj@icloud.com","ua":"iBypasser Agent"}
// [2026-10-22 16:09:18] [52ecefe4] PROVIDER {"auto_executou_no_include":"0","resultado_reaproveitado":"0","incluiu_em":"11ms"}
// [2026-10-22 16:09:22] [52ecefe4] RESULT {"success":"1","msg":"Process completed successfully","error_code":"","devices":1,"removed":0,"pending":1,"failed":0,"motivos":[],"tempo":"4.01s"}
// [2026-10-22 16:10:53] [58d6d247] REQUEST {"ip":"153.56.168.61","web":"apple","view":"json","autoremove":"1","apple_id":"stelaodj@icloud.com","ua":"iBypasser Agent"}
// [2026-10-22 16:10:53] [58d6d247] PROVIDER {"auto_executou_no_include":"0","resultado_reaproveitado":"0","incluiu_em":"17ms"}
// [2026-10-22 16:10:57] [58d6d247] RESULT {"success":"1","msg":"Process completed successfully","error_code":"","devices":1,"removed":0,"pending":1,"failed":0,"motivos":[],"tempo":"3.59s"}
// [2026-10-22 17:05:22] [2529cffa] REQUEST {"ip":"153.56.168.61","web":"apple","view":"json","autoremove":"1","apple_id":"xdevers@proton.me","ua":"iBypasser Agent"}
// [2026-10-22 17:05:22] [2529cffa] PROVIDER {"auto_executou_no_include":"0","resultado_reaproveitado":"0","incluiu_em":"17ms"}
// [2026-10-22 17:05:29] [2529cffa] RESULT {"success":"1","msg":"Process completed successfully","error_code":"","devices":2,"removed":0,"pending":0,"failed":2,"motivos":["Ivan’s MacBook Pro: Apple não devolveu authToken na fase de autorização","iPhone 13PMax: Apple não devolveu authToken na fase de autorização"],"tempo":"6.87s"}
// [2026-10-22 17:15:57] [4cd77071] REQUEST {"ip":"153.56.168.61","web":"apple","view":"json","autoremove":"1","apple_id":"xdevers@proton.me","ua":"iBypasser Agent"}
// [2026-10-22 17:15:57] [4cd77071] PROVIDER {"auto_executou_no_include":"0","resultado_reaproveitado":"0","incluiu_em":"15ms"}
// [2026-10-22 17:16:03] [4cd77071] RESULT {"success":"1","msg":"Process completed successfully","error_code":"","devices":2,"removed":0,"pending":0,"failed":2,"motivos":["Ivan’s MacBook Pro: Apple não devolveu authToken na fase de autorização","iPhone 13PMax: Apple não devolveu authToken na fase de autorização"],"tempo":"6.38s"}
